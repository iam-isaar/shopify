import {getDotEnvFileName} from './loader.js'
import {ExtensionInstance} from '../extensions/extension-instance.js'
import {patchEnvFile} from '@shopify/cli-kit/node/dot-env'
import {constantize} from '@shopify/cli-kit/common/string'
import {joinPath} from '@shopify/cli-kit/node/path'
import {fileExists, readFile, writeFile} from '@shopify/cli-kit/node/fs'
import type {AppInterface} from './app.js'

export interface ExtensionUuidsByLocalIdentifier {
  [localIdentifier: string]: string
}

export interface DeployIdentifiers {
  appModuleUuids: ExtensionUuidsByLocalIdentifier
  appModuleRegistrationIds: ExtensionUuidsByLocalIdentifier
}

type UpdateAppIdentifiersCommand = 'dev' | 'deploy' | 'release' | 'import-extensions'
interface UpdateAppIdentifiersOptions {
  app: AppInterface
  appApiKey: string
  extensionUuids: ExtensionUuidsByLocalIdentifier
  command: UpdateAppIdentifiersCommand
}

/**
 * Given an app and a set of identifiers, it persists the identifiers in the .env files.
 * @param options - Options.
 * @returns An copy of the app with the environment updated to reflect the updated identifiers.
 */
export async function updateAppIdentifiers(
  {app, appApiKey, extensionUuids, command}: UpdateAppIdentifiersOptions,
  systemEnvironment = process.env,
): Promise<AppInterface> {
  let dotenvFile = app.dotenv

  dotenvFile ??= {
    path: joinPath(app.directory, getDotEnvFileName(app.configPath)),
    variables: {},
  }
  const updatedVariables: {[key: string]: string} = {...(app.dotenv?.variables ?? {})}
  if (!systemEnvironment[app.idEnvironmentVariableName]) {
    updatedVariables[app.idEnvironmentVariableName] = appApiKey
  }
  Object.keys(extensionUuids).forEach((identifier) => {
    const envVariable = `SHOPIFY_${constantize(identifier)}_ID`
    if (!systemEnvironment[envVariable]) {
      updatedVariables[envVariable] = extensionUuids[identifier]!
    }
  })

  const writeToFile = command === 'import-extensions'

  dotenvFile.variables = updatedVariables

  if (writeToFile) {
    const dotEnvFileExists = await fileExists(dotenvFile.path)
    const envFileContent = dotEnvFileExists ? await readFile(dotenvFile.path) : ''
    const updatedEnvFileContent = patchEnvFile(envFileContent, updatedVariables)
    await writeFile(dotenvFile.path, updatedEnvFileContent)

    // eslint-disable-next-line require-atomic-updates
    app.dotenv = dotenvFile
  }

  return app
}

interface GetAppIdentifiersOptions {
  app: AppInterface
}
/**
 * Given an app and a environment, it fetches the ids from the environment
 * and returns them.
 */
export function getAppIdentifiers(
  {app}: GetAppIdentifiersOptions,
  systemEnvironment = process.env,
): ExtensionUuidsByLocalIdentifier {
  const envVariables = {
    ...app.dotenv?.variables,
    ...(systemEnvironment as {[variable: string]: string}),
  }
  const extensionsIdentifiers: {[key: string]: string} = {}
  const processExtension = (extension: ExtensionInstance) => {
    if (Object.keys(envVariables).includes(extension.idEnvironmentVariableName)) {
      extensionsIdentifiers[extension.localIdentifier] = envVariables[extension.idEnvironmentVariableName]!
    }
  }
  app.allExtensions.forEach(processExtension)

  return extensionsIdentifiers
}
