import {AppErrors, isWebType} from './loader.js'
import {ensurePathStartsWithSlash} from './validation/common.js'
import {ExtensionUuidsByLocalIdentifier} from './identifiers.js'
import {ExtensionInstance} from '../extensions/extension-instance.js'
import {FunctionConfigType} from '../extensions/specifications/function.js'
import {ExtensionSpecification, RemoteAwareExtensionSpecification} from '../extensions/specification.js'
import {AppConfigurationUsedByCli} from '../extensions/specifications/types/app_config.js'
import {EditorExtensionCollectionType} from '../extensions/specifications/editor_extension_collection.js'
import {UIExtensionSchema} from '../extensions/specifications/ui_extension.js'
import {EventsSpecIdentifier} from '../extensions/specifications/app_config_events.js'
import {CreateAppOptions, Flag} from '../../utilities/developer-platform-client.js'
import {configurationFileNames} from '../../constants.js'
import {ApplicationURLs} from '../../services/dev/urls.js'
import {patchAppHiddenConfigFile} from '../../services/app/patch-app-configuration-file.js'
import {WebhookSubscription} from '../extensions/specifications/types/app_config_webhook.js'
import {joinPath} from '@shopify/cli-kit/node/path'
import {ZodObjectOf, zod} from '@shopify/cli-kit/node/schema'
import {DotEnvFile} from '@shopify/cli-kit/node/dot-env'
import {readAndParsePackageJson} from '@shopify/cli-kit/node/node-package-manager'
import {
  fileExistsSync,
  fileRealPath,
  findPathUp,
  readFileSync,
  removeFileSync,
  writeFileSync,
} from '@shopify/cli-kit/node/fs'
import {AbortError} from '@shopify/cli-kit/node/error'
import {JsonMapType} from '@shopify/cli-kit/node/toml'
import {getArrayRejectingUndefined} from '@shopify/cli-kit/common/array'
import {deepMergeObjects, getPathValue} from '@shopify/cli-kit/common/object'

// Schemas for loading app configuration

const ExtensionDirectoriesSchema = zod
  .array(zod.string())
  .optional()
  .transform(removeTrailingPathSeparator)
  .transform(fixSingleWildcards)

function removeTrailingPathSeparator(value: string[] | undefined) {
  // eslint-disable-next-line no-useless-escape
  return value?.map((dir) => dir.replace(/[\/\\]+$/, ''))
}

// If a path ends with a single asterisk, modify it to end with a double asterisk.
// This is to support the glob pattern used by chokidar and watch for changes in subfolders.
function fixSingleWildcards(value: string[] | undefined) {
  // eslint-disable-next-line no-useless-escape
  return value?.map((dir) => dir.replace(/([^\*])\*$/, '$1**'))
}

/**
 * Schema for a normal, linked app. Properties from modules are not validated.
 */
export const AppSchema = zod
  .object({
    client_id: zod.string(),
    build: zod
      .object({
        automatically_update_urls_on_dev: zod.boolean().optional(),
        dev_store_url: zod.string().optional(),
        include_config_on_deploy: zod.boolean().optional(),
      })
      .optional(),
    extension_directories: ExtensionDirectoriesSchema,
    web_directories: zod.array(zod.string()).optional(),
  })
  .passthrough()

/**
 * Hidden configuration for an app. Stored inside ./shopify/project.json
 * This is a set of values that are needed by the CLI that are not part of the app configuration.
 * These are not meant to be git tracked and the user doesn't need to know about their existence.
 */
export interface AppHiddenConfig {
  dev_store_url?: string
}

// Types representing post-validated app configurations

/**
 * App configuration for something validated as either a freshly minted app template or a normal, linked, app.
 *
 * Try to avoid using this: generally you should be working with a more specific type.
 */
export type AppConfiguration = zod.infer<typeof AppSchema>

/**
 * App configuration for a normal, linked, app. Doesn't include properties that are module derived.
 */
type BasicAppConfigurationWithoutModules = zod.infer<typeof AppSchema>

/**
 * The build section for a normal, linked app. The options here tweak the CLI's behavior when working with the app.
 */
export type CliBuildPreferences = BasicAppConfigurationWithoutModules['build']

/**
 * App configuration for a normal, linked, app -- including properties that are module derived, such as scopes etc.
 */
export type CurrentAppConfiguration = BasicAppConfigurationWithoutModules & AppConfigurationUsedByCli

/** Validation schema that produces a provided app configuration type */
export type SchemaForConfig<TConfig> = ZodObjectOf<TConfig>

export function getAppVersionedSchema(
  specs: ExtensionSpecification[],
  allowDynamicallySpecifiedConfigs = true,
): ZodObjectOf<CurrentAppConfiguration> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const schema = specs.reduce<any>((schema, spec) => spec.contributeToAppConfigurationSchema(schema), AppSchema)

  if (allowDynamicallySpecifiedConfigs) {
    return schema.passthrough()
  } else {
    return specs.length > 0 ? schema.strict() : schema
  }
}

/**
 * Get scopes from a given app.toml config file.
 * @param config - a configuration file
 */
export function getAppScopes(config: CurrentAppConfiguration): string {
  return config.access_scopes?.scopes ?? ''
}

/**
 * Get scopes as an array from a given app.toml config file.
 * @param config - a configuration file
 */
export function getAppScopesArray(config: CurrentAppConfiguration) {
  const scopes = getAppScopes(config)
  return scopes.length ? scopes.split(',').map((scope) => scope.trim()) : []
}

export function appHiddenConfigPath(appDirectory: string) {
  return joinPath(appDirectory, configurationFileNames.hiddenFolder, configurationFileNames.hiddenConfig)
}

/**
 * Get the field names from the configuration that aren't found in the basic built-in app configuration schema.
 */
export function filterNonVersionedAppFields(configuration: object): string[] {
  const builtInFieldNames = Object.keys(AppSchema.shape).concat('organization_id')
  return Object.keys(configuration).filter((fieldName) => {
    return !builtInFieldNames.includes(fieldName)
  })
}

export enum WebType {
  Frontend = 'frontend',
  Backend = 'backend',
  Background = 'background',
}

const WebConfigurationAuthCallbackPathSchema = zod.preprocess(ensurePathStartsWithSlash, zod.string())

const baseWebConfigurationSchema = zod.object({
  auth_callback_path: zod
    .union([WebConfigurationAuthCallbackPathSchema, WebConfigurationAuthCallbackPathSchema.array()])
    .optional(),
  webhooks_path: zod.preprocess(ensurePathStartsWithSlash, zod.string()).optional(),
  port: zod.number().max(65536).min(0).optional(),
  commands: zod.object({
    build: zod.string().optional(),
    predev: zod.string().optional(),
    dev: zod.string(),
  }),
  name: zod.string().optional(),
  hmr_server: zod.object({http_paths: zod.string().array()}).optional(),
})
const webTypes = zod.enum([WebType.Frontend, WebType.Backend, WebType.Background]).default(WebType.Frontend)
export const WebConfigurationSchema = zod.union([
  baseWebConfigurationSchema.extend({roles: zod.array(webTypes)}),
  baseWebConfigurationSchema.extend({type: webTypes}),
])
type WebConfiguration = zod.infer<typeof WebConfigurationSchema>
type ProcessedWebConfiguration = zod.infer<
  ReturnType<typeof baseWebConfigurationSchema.extend<{roles: zod.ZodArray<typeof webTypes>}>>
>
export type WebConfigurationCommands = keyof WebConfiguration['commands']

export interface Web {
  directory: string
  configuration: ProcessedWebConfiguration
  framework?: string
}

export interface AppConfigurationInterface<
  TConfig extends CurrentAppConfiguration = CurrentAppConfiguration,
  TModuleSpec extends ExtensionSpecification = ExtensionSpecification,
> {
  directory: string
  configPath: string
  configuration: TConfig
  /** The client ID provided by the command, preserved when the app reloads. */
  readonly clientIdOverride?: string
  configSchema: SchemaForConfig<TConfig>
  specifications: TModuleSpec[]
  remoteFlags: Flag[]
}

export type AppLinkedInterface = AppInterface<CurrentAppConfiguration, RemoteAwareExtensionSpecification>

export interface AppManifest extends JsonMapType {
  name: string
  handle: string
  modules: ManifestModule[]
}

interface ManifestModule extends JsonMapType {
  type: string
  handle: string
  uid: string
  assets: string
  target: string
  config: JsonMapType
}

export interface AppInterface<
  TConfig extends CurrentAppConfiguration = CurrentAppConfiguration,
  TModuleSpec extends ExtensionSpecification = ExtensionSpecification,
> extends AppConfigurationInterface<TConfig, TModuleSpec> {
  name: string
  idEnvironmentVariableName: 'SHOPIFY_API_KEY'
  webs: Web[]
  dotenv?: DotEnvFile
  allExtensions: ExtensionInstance[]
  realExtensions: ExtensionInstance[]
  nonConfigExtensions: ExtensionInstance[]
  errors: AppErrors
  hiddenConfig: AppHiddenConfig
  includeConfigOnDeploy: boolean | undefined
  readonly devApplicationURLs?: ApplicationURLs
  extensionsForType: (spec: {identifier: string; externalIdentifier: string}) => ExtensionInstance[]
  updateExtensionUUIDS: (uuids: {[key: string]: string}) => void
  preDeployValidation: () => Promise<void>
  /**
   * Checks if the app has any elements that means it can be "launched" -- can host its own app home section.
   *
   * @returns true if the app can be launched, false otherwise
   */
  appIsLaunchable: () => boolean

  /**
   * If creating an app on the platform based on this app and its configuration, what default options should the app take?
   */
  creationDefaultOptions(): CreateAppOptions
  manifest: (appModuleUuids: ExtensionUuidsByLocalIdentifier | undefined) => Promise<AppManifest>
  removeExtension: (extensionUid: string) => void
  updateHiddenConfig: (values: Partial<AppHiddenConfig>) => Promise<void>
  setDevApplicationURLs: (devApplicationURLs: ApplicationURLs) => void
  generateExtensionTypes(): Promise<void>
  getLogsDir(): string
}

type AppConstructor<
  TConfig extends CurrentAppConfiguration = CurrentAppConfiguration,
  TModuleSpec extends ExtensionSpecification = ExtensionSpecification,
> = AppConfigurationInterface<TConfig, TModuleSpec> & {
  name: string
  webs: Web[]
  modules: ExtensionInstance[]
  dotenv?: DotEnvFile
  errors: AppErrors
  specifications: ExtensionSpecification[]
  remoteFlags?: Flag[]
  hiddenConfig: AppHiddenConfig
  devApplicationURLs?: ApplicationURLs
}

export class App<
  TConfig extends CurrentAppConfiguration = CurrentAppConfiguration,
  TModuleSpec extends ExtensionSpecification = ExtensionSpecification,
> implements AppInterface<TConfig, TModuleSpec> {
  name: string
  idEnvironmentVariableName: 'SHOPIFY_API_KEY' = 'SHOPIFY_API_KEY' as const
  directory: string
  configPath: string
  configuration: TConfig
  readonly clientIdOverride?: string
  webs: Web[]
  dotenv?: DotEnvFile
  errors: AppErrors
  specifications: TModuleSpec[]
  configSchema: SchemaForConfig<TConfig>
  remoteFlags: Flag[]
  realExtensions: ExtensionInstance[]
  devApplicationURLs?: ApplicationURLs
  private _hiddenConfig: AppHiddenConfig

  constructor({
    name,
    directory,
    configPath,
    configuration,
    clientIdOverride,
    webs,
    modules,
    dotenv,
    errors,
    specifications,
    configSchema,
    remoteFlags,
    hiddenConfig,
    devApplicationURLs,
  }: AppConstructor<TConfig, TModuleSpec>) {
    this.name = name
    this.directory = directory
    this.configPath = configPath
    this.configuration = configuration
    this.clientIdOverride = clientIdOverride
    this.webs = webs
    this.dotenv = dotenv
    this.realExtensions = modules
    this.errors = errors ?? new AppErrors()
    this.specifications = specifications
    this.configSchema = configSchema ?? AppSchema
    this.remoteFlags = remoteFlags ?? []
    this._hiddenConfig = hiddenConfig
    if (devApplicationURLs) this.setDevApplicationURLs(devApplicationURLs)
  }

  get allExtensions() {
    if (this.includeConfigOnDeploy === false) return this.nonConfigExtensions
    return this.realExtensions
  }

  get nonConfigExtensions() {
    return this.realExtensions.filter((ext) => !ext.isAppConfigExtension)
  }

  setDevApplicationURLs(devApplicationURLs: ApplicationURLs) {
    this.patchAppConfiguration(devApplicationURLs)
    this.realExtensions.forEach((ext) => ext.patchWithAppDevURLs(devApplicationURLs))
  }

  async manifest(appModuleUuids: ExtensionUuidsByLocalIdentifier | undefined): Promise<AppManifest> {
    const modules = await Promise.all(
      this.realExtensions.map(async (module) => {
        const config = await module.deployConfig({
          apiKey: String(this.configuration.client_id ?? ''),
          appConfiguration: this.configuration,
        })
        return {
          type: module.externalType,
          handle: module.handle,
          uid: module.uid,
          uuid: appModuleUuids?.[module.localIdentifier],
          assets: module.uid,
          target: module.contextValue,
          config: (config ?? {}) as JsonMapType,
        }
      }),
    )

    return {
      name: this.name,
      handle: '',
      modules: getArrayRejectingUndefined(modules),
    }
  }

  get hiddenConfig() {
    return this._hiddenConfig
  }

  getLogsDir() {
    return joinPath(this.directory, '.shopify', 'logs')
  }

  async updateHiddenConfig(values: Partial<AppHiddenConfig>) {
    if (!this.configuration.client_id) return
    this._hiddenConfig = deepMergeObjects(this.hiddenConfig, values)
    const path = appHiddenConfigPath(this.directory)
    await patchAppHiddenConfigFile(path, String(this.configuration.client_id), this.hiddenConfig)
  }

  async preDeployValidation() {
    this.validateWebhookLegacyFlowCompatibility()
    this.validateEventsLegacyFlowCompatibility()

    const functionExtensionsWithUiHandle = this.allExtensions.filter(
      (ext) => ext.isFunctionExtension && (ext.configuration as unknown as FunctionConfigType).ui?.handle,
    ) as ExtensionInstance<FunctionConfigType>[]

    if (functionExtensionsWithUiHandle.length > 0) {
      const errors = validateFunctionExtensionsWithUiHandle(functionExtensionsWithUiHandle, this.allExtensions)
      if (errors) {
        throw new AbortError('Invalid function configuration', errors.join('\n'))
      }
    }

    const extensionCollections = this.allExtensions.filter(
      (ext) => ext.isEditorExtensionCollection,
    ) as ExtensionInstance<EditorExtensionCollectionType>[]

    if (extensionCollections.length > 0) {
      const errors = validateExtensionsHandlesInCollection(extensionCollections, this.allExtensions)
      if (errors) {
        throw new AbortError('Invalid editor extension collection configuration', errors.join('\n\n'))
      }
    }

    await Promise.all(this.allExtensions.map((ext) => ext.preDeployValidation()))
  }

  extensionsForType(specification: {identifier: string; externalIdentifier: string}): ExtensionInstance[] {
    return this.allExtensions.filter(
      (extension) => extension.type === specification.identifier || extension.type === specification.externalIdentifier,
    )
  }

  updateExtensionUUIDS(uuids: {[key: string]: string}) {
    this.allExtensions.forEach((extension) => {
      extension.devUUID = uuids[extension.localIdentifier] ?? extension.devUUID
    })
  }

  appIsLaunchable() {
    const frontendConfig = this.webs.find((web) => isWebType(web, WebType.Frontend))
    const backendConfig = this.webs.find((web) => isWebType(web, WebType.Backend))

    return Boolean(frontendConfig ?? backendConfig)
  }

  get appIsEmbedded(): boolean {
    return this.configuration.embedded
  }

  creationDefaultOptions(): CreateAppOptions {
    return {
      isLaunchable: this.appIsLaunchable(),
      scopesArray: getAppScopesArray(this.configuration),
      name: this.name,
      isEmbedded: this.appIsEmbedded,
      directory: this.directory,
    }
  }

  removeExtension(extensionUid: string) {
    this.realExtensions = this.realExtensions.filter((ext) => ext.uid !== extensionUid)
  }

  async generateExtensionTypes() {
    const typeDefinitionsByFile = new Map<string, Set<string>>()
    await Promise.all(
      this.allExtensions.map((extension) => extension.contributeToSharedTypeFile(typeDefinitionsByFile)),
    )
    typeDefinitionsByFile.forEach((types, typeFilePath) => {
      const exists = fileExistsSync(typeFilePath)
      // No types to add, remove the file if it exists
      if (types.size === 0) {
        if (exists) {
          removeFileSync(typeFilePath)
        }
        return
      }

      const originalContent = exists ? readFileSync(typeFilePath).toString() : ''
      // We need this top-level import to work around the TS restriction of not allowing  declaring modules with relative paths.
      // This is needed to enable file-specific global type declarations.
      const typeContent = [`import '@shopify/ui-extensions';\n`, ...Array.from(types)].join('\n')
      if (originalContent === typeContent) {
        return
      }
      writeFileSync(typeFilePath, typeContent)
    })
  }

  get includeConfigOnDeploy() {
    return this.configuration.build?.include_config_on_deploy
  }

  private patchAppConfiguration(devApplicationURLs: ApplicationURLs) {
    this.devApplicationURLs = devApplicationURLs
    this.configuration.application_url = devApplicationURLs.applicationUrl
    if (devApplicationURLs.appProxy) {
      this.configuration.app_proxy = {
        url: devApplicationURLs.appProxy.proxyUrl,
        subpath: devApplicationURLs.appProxy.proxySubPath,
        prefix: devApplicationURLs.appProxy.proxySubPathPrefix,
      }
    }
    if (this.configuration.auth?.redirect_urls) {
      this.configuration.auth.redirect_urls = devApplicationURLs.redirectUrlWhitelist
    }
  }

  private validateEventsLegacyFlowCompatibility(): void {
    if (this.configuration.access_scopes?.use_legacy_install_flow !== true) return

    const hasEventSubscriptions = this.extensionsForType({
      identifier: EventsSpecIdentifier,
      externalIdentifier: EventsSpecIdentifier,
    }).some((extension) => {
      const subscription = getPathValue(extension.configuration, 'events.subscription')
      return Array.isArray(subscription)
        ? subscription.length > 0
        : typeof subscription === 'object' && subscription !== null
    })

    if (hasEventSubscriptions) {
      throw new AbortError(
        'Events subscriptions are not supported when use_legacy_install_flow is enabled.',
        `Migrate to Shopify-managed installation before using Events subscriptions.
Scopes in your TOML configuration are not managed by Shopify while 'use_legacy_install_flow = true'.

Learn more: https://shopify.dev/docs/apps/build/authentication-authorization/app-installation`,
      )
    }
  }

  /**
   * Validates that app-specific webhooks are not used with legacy install flow.
   * This incompatibility exists because app-specific webhooks require declarative
   * scopes in the Partner Dashboard, which aren't synced when using legacy flow.
   * @throws When app-specific webhooks are used with legacy install flow
   */
  private validateWebhookLegacyFlowCompatibility(): void {
    const hasAppSpecificWebhooks =
      this.configuration.webhooks?.subscriptions?.some(
        (subscription: WebhookSubscription) => subscription.topics && subscription.topics.length > 0,
      ) ?? false
    const usesLegacyInstallFlow = this.configuration.access_scopes?.use_legacy_install_flow === true

    if (hasAppSpecificWebhooks && usesLegacyInstallFlow) {
      throw new AbortError(
        'App-specific webhook subscriptions are not supported when use_legacy_install_flow is enabled.',
        `To use app-specific webhooks, you need to:
1. Remove 'use_legacy_install_flow = true' from your configuration
2. Run 'shopify app deploy' to sync your scopes with the Developer Dashboard

Alternatively, continue using shop-specific webhooks with the legacy install flow.

Learn more: https://shopify.dev/docs/apps/build/authentication-authorization/app-installation`,
      )
    }
  }
}

export function validateFunctionExtensionsWithUiHandle(
  functionExtensionsWithUiHandle: ExtensionInstance<FunctionConfigType>[],
  allExtensions: ExtensionInstance[],
): string[] | undefined {
  const errors: string[] = []

  functionExtensionsWithUiHandle.forEach((extension) => {
    const uiHandle = extension.configuration.ui!.handle!

    const matchingExtension = findExtensionByHandle(allExtensions, uiHandle)
    if (!matchingExtension) {
      errors.push(`[${extension.name}] - Local app must contain a ui_extension with handle '${uiHandle}'`)
    } else if (matchingExtension.type !== 'ui_extension') {
      errors.push(
        `[${extension.name}] - Local app must contain one extension of type 'ui_extension' and handle '${uiHandle}'`,
      )
    }
  })

  return errors.length > 0 ? errors : undefined
}

type UIExtensionType = zod.infer<typeof UIExtensionSchema>

export function validateExtensionsHandlesInCollection(
  editorExtensionCollections: ExtensionInstance<EditorExtensionCollectionType>[],
  allExtensions: ExtensionInstance[],
): string[] | undefined {
  const errors: string[] = []

  const allowableTypesForExtensionInCollection = ['ui_extension']
  editorExtensionCollections.forEach((collection) => {
    collection.configuration.inCollection.forEach((extension) => {
      const matchingExtension = findExtensionByHandle(allExtensions, extension.handle)

      if (!matchingExtension) {
        errors.push(
          `[${collection.handle}] editor extension collection: Add extension with handle '${extension.handle}' to local app. Local app must include extension with handle '${extension.handle}'.`,
        )
      } else if (!allowableTypesForExtensionInCollection.includes(matchingExtension.specification.identifier)) {
        errors.push(
          `[${collection.handle}] editor extension collection: Remove extension of type '${matchingExtension.specification.identifier}' from this collection. This extension type is not supported in collections.`,
        )
      } else if (matchingExtension.specification.identifier === 'ui_extension') {
        const uiExtension = matchingExtension as ExtensionInstance<UIExtensionType>
        uiExtension.configuration.extension_points.forEach((extensionPoint) => {
          if (extensionPoint.target.startsWith('admin.')) {
            errors.push(
              `[${collection.handle}] editor extension collection: Remove extension '${matchingExtension.configuration.handle}' with target '${extensionPoint.target}' from this collection. This extension target is not supported in collections.`,
            )
          }
        })
      }
    })
  })

  return errors.length > 0 ? errors : undefined
}

function findExtensionByHandle(allExtensions: ExtensionInstance[], handle: string): ExtensionInstance | undefined {
  return allExtensions.find((ext) => ext.handle === handle)
}

type RendererVersionResult = {name: string; version: string} | undefined | 'not_found'

/**
 * Given a UI extension, it returns the version of the renderer package.
 * Looks for `/node_modules/@shopify/{renderer-package-name}/package.json` to find the real version used.
 * @param extension - UI extension whose renderer version will be obtained.
 * @returns The version if the dependency exists.
 */
export async function getUIExtensionRendererVersion(extension: ExtensionInstance): Promise<RendererVersionResult> {
  // Look for the vanilla JS version of the dependency (the react one depends on it, will always be present)
  const rendererDependency = extension.dependency
  if (!rendererDependency) return undefined
  return getDependencyVersion(rendererDependency, extension.directory)
}

export async function getDependencyVersion(dependency: string, directory: string): Promise<RendererVersionResult> {
  // Split the dependency name to avoid using "/" in windows. Only look for non react dependencies.
  const dependencyName = dependency.replace('-react', '').split('/')
  const pattern = joinPath('node_modules', dependencyName[0]!, dependencyName[1]!, 'package.json')

  let packagePath = await findPathUp(pattern, {
    cwd: directory,
    type: 'file',
    allowSymlinks: true,
  })
  if (!packagePath) return 'not_found'
  packagePath = await fileRealPath(packagePath)

  // Load the package.json and extract the version
  const packageContent = await readAndParsePackageJson(packagePath)
  if (!packageContent.version) return 'not_found'
  return {name: dependency, version: packageContent.version}
}
