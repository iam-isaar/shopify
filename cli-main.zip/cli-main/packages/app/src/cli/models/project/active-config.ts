import {Project} from './project.js'
import {resolveDotEnv, resolveHiddenConfig} from './config-selection.js'
import {AppHiddenConfig} from '../app/app.js'
import {getAppConfigurationFileName} from '../app/config-file-naming.js'
import {getCachedAppInfo} from '../../services/local-storage.js'
import use from '../../services/app/config/use.js'
import {TomlFile} from '@shopify/cli-kit/node/toml/toml-file'
import {DotEnvFile} from '@shopify/cli-kit/node/dot-env'
import {fileExistsSync} from '@shopify/cli-kit/node/fs'
import {joinPath} from '@shopify/cli-kit/node/path'
import {AbortError} from '@shopify/cli-kit/node/error'
import {outputContent, outputToken} from '@shopify/cli-kit/node/output'

/** @public */
export type ConfigSource = 'flag' | 'cached' | 'default'

/**
 * The selected app configuration — one specific TOML from the project's
 * potentially many app config files, plus config-specific derived state.
 *
 * A sibling to Project, not a child. Project is the environment;
 * ActiveConfig is a selection decision applied to that environment.
 *
 * path and fileName are derivable from file.path — use the accessors
 * if you need them rather than storing redundant data.
 * @public
 */
export interface ActiveConfig {
  /** The selected app TOML file (from project.appConfigFiles) */
  file: TomlFile
  /** How the selection was made */
  source: ConfigSource
  /** Whether the config has a non-empty client_id */
  isLinked: boolean
  /** Config-specific dotenv (.env.staging or .env) */
  dotenv?: DotEnvFile
  /** Hidden config entry for this config's client_id */
  hiddenConfig: AppHiddenConfig
}

/**
 * Select the active app configuration from a project.
 *
 * Resolution priority:
 * 1. userProvidedConfigName (from --config flag)
 * 2. clientId (from --client-id flag)
 * 3. Cached selection (from `app config use`)
 * 4. Default (shopify.app.toml)
 *
 * If the cached config file no longer exists on disk, prompts the user
 * to select a new one via `app config use`.
 *
 * Derives config-specific state: dotenv and hidden config for the selected
 * config's client_id.
 * @public
 */
export async function selectActiveConfig(
  project: Project,
  userProvidedConfigName?: string,
  options?: {clientId?: string; skipPrompts?: boolean},
): Promise<ActiveConfig> {
  let configName = userProvidedConfigName
  const clientIdConfig = options?.clientId ? project.appConfigByClientId(options.clientId) : undefined

  // Check cache for previously selected config
  const cachedConfigName = getCachedAppInfo(project.directory)?.configFile
  const cachedConfigPath = cachedConfigName ? joinPath(project.directory, cachedConfigName) : null
  const cacheIsStale = Boolean(!configName && cachedConfigPath && !fileExistsSync(cachedConfigPath))

  // Handle stale cache: cached config file no longer exists
  if (cacheIsStale && !options?.skipPrompts) {
    const warningContent = {
      headline: `Couldn't find ${cachedConfigName}`,
      body: [
        "If you have multiple config files, select a new one. If you only have one config file, it's been selected as your default.",
      ],
    }
    configName = await use({directory: project.directory, warningContent, shouldRenderSuccess: false})
  }

  if (!configName && clientIdConfig) {
    return buildActiveConfig(project, clientIdConfig, 'flag')
  }

  if (!configName && options?.clientId) {
    throw new AbortError(
      "The specified client ID couldn't be found in any TOML file, or the matching TOML file is malformed.",
    )
  }

  // Don't fall back to stale cached name — it points to a non-existent file
  const resolvedConfigName = configName ?? (cacheIsStale ? undefined : cachedConfigName)

  // Determine source after resolution so it reflects the actual selection path
  let source: ConfigSource
  if (userProvidedConfigName) {
    source = 'flag'
  } else if (resolvedConfigName) {
    source = 'cached'
  } else {
    source = 'default'
  }

  // Resolve the config file name and look it up in the project's pre-loaded files
  const configurationFileName = getAppConfigurationFileName(resolvedConfigName)
  const file = project.appConfigByName(configurationFileName)
  if (!file) {
    throw new AbortError(
      outputContent`Couldn't find ${configurationFileName} in ${outputToken.path(project.directory)}.`,
    )
  }

  return buildActiveConfig(project, file, source)
}

async function buildActiveConfig(project: Project, file: TomlFile, source: ConfigSource): Promise<ActiveConfig> {
  const clientId = typeof file.content.client_id === 'string' ? file.content.client_id : undefined
  const isLinked = Boolean(clientId) && clientId !== ''
  const dotenv = resolveDotEnv(project, file.path)
  const hiddenConfig = await resolveHiddenConfig(project, clientId)

  return {
    file,
    source,
    isLinked,
    dotenv,
    hiddenConfig,
  }
}
