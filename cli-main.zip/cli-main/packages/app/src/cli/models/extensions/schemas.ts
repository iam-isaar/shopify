import {zod} from '@shopify/cli-kit/node/schema'

export const MAX_EXTENSION_HANDLE_LENGTH = 50
export const MAX_UID_LENGTH = 250

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type ZodSchemaType<T> = zod.ZodType<T, any, any>

export const MetafieldSchema = zod.object({
  namespace: zod.string(),
  key: zod.string(),
  owner_type: zod.string().optional(),
})

const CollectBuyerConsentCapabilitySchema = zod.object({
  sms_marketing: zod.boolean().optional(),
  customer_privacy: zod.boolean().optional(),
})

const IframeCapabilitySchema = zod.object({
  sources: zod.array(zod.string()).optional(),
})

const CapabilitiesSchema = zod.object({
  network_access: zod.boolean().optional(),
  block_progress: zod.boolean().optional(),
  api_access: zod.boolean().optional(),
  collect_buyer_consent: CollectBuyerConsentCapabilitySchema.optional(),
  iframe: IframeCapabilitySchema.optional(),
  bundle_size_exception: zod.boolean().optional(),
})

const SupportedFeaturesSchema = zod.object({
  runs_offline: zod.boolean().optional(),
})

export const ExtensionsArraySchema = zod.object({
  type: zod.string().optional(),
  extensions: zod.array(zod.any()).optional(),
})

const TargetInterceptSchema = zod.object({
  event: zod.string(),
  blocking: zod.boolean().default(false),
  applies_to: zod.array(zod.string()).optional(),
})

const TargetCapabilitiesSchema = zod.object({
  allow_direct_linking: zod.boolean().optional(),
  intercepts: zod.array(TargetInterceptSchema).optional(),
})

const ShouldRenderSchema = zod.object({
  module: zod.string(),
})

const NewExtensionPointSchema = zod.object({
  target: zod.string(),
  module: zod.string(),
  should_render: ShouldRenderSchema.optional(),
  tools: zod.string().optional(),
  instructions: zod.string().optional(),
  intents: zod
    .array(
      zod.object({
        type: zod.string(),
        action: zod.string(),
        schema: zod.string(),
        name: zod.string().optional(),
        description: zod.string().optional(),
      }),
    )
    .optional(),
  metafields: zod.array(MetafieldSchema).optional(),
  default_placement: zod.string().optional(),
  urls: zod
    .object({
      edit: zod.string().optional(),
    })
    .optional(),
  capabilities: TargetCapabilitiesSchema.optional(),
  preloads: zod
    .object({
      chat: zod.string().optional(),
    })
    .optional(),
  assets: zod.string().optional(),
})

export const NewExtensionPointsSchema = zod.array(NewExtensionPointSchema)
const ApiVersionSchema = zod.string()

export type ApiVersionSchemaType = zod.infer<typeof ApiVersionSchema>

export const FieldSchema = zod.object({
  key: zod.string().optional(),
  name: zod.string().optional(),
  description: zod.string().optional(),
  required: zod.boolean().optional(),
  default_value: zod.any().optional(),
  type: zod.string(),
  validations: zod.array(zod.any()).optional(),
  marketingActivityCreateUrl: zod.string().optional(),
  marketingActivityDeleteUrl: zod.string().optional(),
})

const SettingsSchema = zod.object({
  fields: zod.array(FieldSchema).optional(),
})

const HandleSchema = zod
  .string()
  .trim()
  .nonempty("Handle can't be empty")
  .max(MAX_EXTENSION_HANDLE_LENGTH, `Handle can't exceed ${MAX_EXTENSION_HANDLE_LENGTH} characters`)
  .regex(/^[a-zA-Z0-9-]*$/, 'Handle can only contain alphanumeric characters and hyphens')
  .refine((handle) => !handle.startsWith('-') && !handle.endsWith('-'), "Handle can't start or end with a hyphen")

const UIDSchema = zod
  .string()
  .trim()
  .nonempty("UID can't be empty")
  .max(MAX_UID_LENGTH, `UID can't exceed ${MAX_UID_LENGTH} characters`)
  .regex(/^[a-zA-Z0-9-${}.()_`]*$/, 'UID can only contain alphanumeric characters and hyphens')
  .refine((uid) => !uid.startsWith('-') && !uid.endsWith('-'), "UID can't start or end with a hyphen")

export const BaseSchema = zod.object({
  name: zod.string().optional(),
  type: zod.string().optional(),
  handle: HandleSchema.optional(),
  uid: UIDSchema.optional(),
  description: zod.string().optional(),
  api_version: ApiVersionSchema.optional(),
  extension_points: zod.any().optional(),
  capabilities: CapabilitiesSchema.optional(),
  supported_features: SupportedFeaturesSchema.optional(),
  settings: SettingsSchema.optional(),
})

export const BaseSchemaWithHandle = BaseSchema.extend({
  handle: HandleSchema,
})

export const BaseSchemaWithoutHandle = BaseSchema.omit({
  handle: true,
})

export const UnifiedSchema = zod.object({
  api_version: ApiVersionSchema.optional(),
  description: zod.string().optional(),
  extensions: zod.array(zod.any()),
  settings: SettingsSchema.optional(),
})

export type NewExtensionPointSchemaType = zod.infer<typeof NewExtensionPointSchema>

// Base config type that all config schemas must extend.
export type BaseConfigType = zod.infer<typeof BaseSchema>
