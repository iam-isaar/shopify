import {SingleWebhookSubscriptionType} from './specifications/app_config_webhook_schemas/webhooks_schema.js'
import {DEFAULT_DEV_SESSION_UPDATE_MESSAGE, ExtensionInstance} from './extension-instance.js'
import {
  ExtensionSpecification,
  createConfigExtensionSpecification,
  createContractBasedModuleSpecification,
  createExtensionSpecification,
} from './specification.js'
import {loadLocalExtensionsSpecifications} from './load-specifications.js'
import {BaseConfigType, BaseSchema, MAX_EXTENSION_HANDLE_LENGTH} from './schemas.js'
import {FunctionConfigType} from './specifications/function.js'
import {
  testApp,
  testAppConfigExtensions,
  testFunctionExtension,
  testTaxCalculationExtension,
  testThemeExtensions,
  testPaymentExtensions,
  testUIExtension,
  testFlowActionExtension,
  testDeveloperPlatformClient,
  testSingleWebhookSubscriptionExtension,
  placeholderAppConfiguration,
} from '../app/app.test-data.js'
import {ExtensionBuildOptions} from '../../services/build/extension.js'
import {ClientSteps} from '../../services/build/client-steps.js'
import {DeveloperPlatformClient} from '../../utilities/developer-platform-client.js'
import {joinPath} from '@shopify/cli-kit/node/path'
import {describe, expect, test, vi} from 'vitest'
import {inTemporaryDirectory, readFile, mkdir, writeFile, fileExistsSync} from '@shopify/cli-kit/node/fs'
import {slugify} from '@shopify/cli-kit/common/string'
import {hashString, nonRandomUUID} from '@shopify/cli-kit/node/crypto'
import {extractImportPathsRecursively} from '@shopify/cli-kit/node/import-extractor'
import {Writable} from 'stream'

const developerPlatformClient: DeveloperPlatformClient = testDeveloperPlatformClient()

vi.mock('@shopify/cli-kit/node/import-extractor')
vi.mock('../../services/build/extension.js', async () => {
  const actual = await vi.importActual('../../services/build/extension.js')
  return {
    ...actual,
    buildUIExtension: vi.fn(),
    buildFunctionExtension: vi.fn(),
  }
})

function functionConfiguration(): FunctionConfigType {
  return {
    name: 'foo',
    type: 'function',
    api_version: '2023-07',
    configuration_ui: true,
    build: {
      wasm_opt: true,
    },
  }
}

describe('keepBuiltSourcemapsLocally', async () => {
  test('moves the appropriate source map files to the expected directory for sourcemap generating extensions', async () => {
    await inTemporaryDirectory(async (bundleDirectory: string) => {
      await inTemporaryDirectory(async (outputPath: string) => {
        const extensionInstance = await testUIExtension({
          type: 'ui_extension',
          handle: 'scriptToMove',
          directory: outputPath,
          uid: 'uid1',
        })
        const someDirPath = joinPath(bundleDirectory, 'uid1')
        const otherDirPath = joinPath(bundleDirectory, 'otherUID')

        await mkdir(someDirPath)
        await writeFile(joinPath(someDirPath, 'scriptToMove.js'), 'abc')
        await writeFile(joinPath(someDirPath, 'scriptToMove.js.map'), 'abc map')

        await mkdir(otherDirPath)
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js'), 'abc')
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js.map'), 'abc map')

        await extensionInstance.keepBuiltSourcemapsLocally(bundleDirectory)

        expect(fileExistsSync(joinPath(outputPath, 'uid1', 'scriptToMove.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'uid1', 'scriptToMove.js.map'))).toBe(true)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js.map'))).toBe(false)
      })
    })
  })

  test('does not move files if no handle matching sourcemap files found within the given path', async () => {
    await inTemporaryDirectory(async (bundleDirectory: string) => {
      await inTemporaryDirectory(async (outputPath: string) => {
        const extensionInstance = await testUIExtension({
          type: 'ui_extension',
          handle: 'scriptToMove',
          directory: outputPath,
          uid: 'uid1',
        })
        const bundleInputPath = joinPath(bundleDirectory, extensionInstance.uid)
        const someDirPath = joinPath(bundleDirectory, 'wrongUID')
        const otherDirPath = joinPath(bundleDirectory, 'otherUID')

        await mkdir(someDirPath)
        await writeFile(joinPath(someDirPath, 'scriptToMove.js'), 'abc')
        await writeFile(joinPath(someDirPath, 'scriptToMove.js.map'), 'abc map')

        await mkdir(otherDirPath)
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js'), 'abc')
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js.map'), 'abc map')

        await extensionInstance.keepBuiltSourcemapsLocally(bundleInputPath)

        expect(fileExistsSync(joinPath(outputPath, 'wrongUID', 'scriptToMove.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'wrongUID', 'scriptToMove.js.map'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js.map'))).toBe(false)
      })
    })
  })

  test('does nothing for non-sourcemap generating extensions', async () => {
    await inTemporaryDirectory(async (bundleDirectory: string) => {
      await inTemporaryDirectory(async (outputPath: string) => {
        const extensionInstance = await testUIExtension({
          type: 'web_pixel_extension',
          handle: 'scriptToMove',
          directory: outputPath,
          uid: 'uid1',
        })
        const someDirPath = joinPath(bundleDirectory, 'uid1')
        const otherDirPath = joinPath(bundleDirectory, 'otherUID')

        await mkdir(someDirPath)
        await writeFile(joinPath(someDirPath, 'scriptToMove.js'), 'abc')
        await writeFile(joinPath(someDirPath, 'scriptToMove.js.map'), 'abc map')

        await mkdir(otherDirPath)
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js'), 'abc')
        await writeFile(joinPath(otherDirPath, 'scriptToIgnore.js.map'), 'abc map')

        await extensionInstance.keepBuiltSourcemapsLocally(bundleDirectory)

        expect(fileExistsSync(joinPath(outputPath, 'uid1', 'scriptToMove.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'uid1', 'scriptToMove.js.map'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js'))).toBe(false)
        expect(fileExistsSync(joinPath(outputPath, 'otherUID', 'scriptToIgnore.js.map'))).toBe(false)
      })
    })
  })
})

describe('build', async () => {
  test('creates a valid JS file for tax calculation extensions', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const extensionInstance = await testTaxCalculationExtension(tmpDir)
      const options: ExtensionBuildOptions = {
        stdout: new Writable({
          write(chunk, enc, cb) {
            cb()
          },
        }),
        stderr: new Writable({
          write(chunk, enc, cb) {
            cb()
          },
        }),
        app: testApp(),
        environment: 'production',
      }

      const outputFilePath = joinPath(tmpDir, `dist/${extensionInstance.outputFileName}`)

      // When
      await extensionInstance.build(options)

      // Then
      const outputFileContent = await readFile(outputFilePath)
      expect(outputFileContent).toEqual('(()=>{})();')
    })
  })
})

describe('deployConfig', async () => {
  test('returns deployConfig when defined', async () => {
    const extensionInstance = await testThemeExtensions()

    const got = await extensionInstance.deployConfig({
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toMatchObject({theme_extension: {files: {}}})
  })

  test('passes app configuration context to deployConfig', async () => {
    const extensionInstance = await testThemeExtensions()
    const originalDeployConfig = extensionInstance.specification.deployConfig
    const deployConfig = vi.fn().mockResolvedValue({theme_extension: {files: {}}})
    extensionInstance.specification.deployConfig = deployConfig

    try {
      await extensionInstance.deployConfig({
        apiKey: 'apiKey',
        appConfiguration: placeholderAppConfiguration,
      })

      expect(deployConfig).toHaveBeenCalledWith(
        extensionInstance.configuration,
        extensionInstance.directory,
        'apiKey',
        undefined,
        {appConfiguration: placeholderAppConfiguration},
      )
    } finally {
      extensionInstance.specification.deployConfig = originalDeployConfig
    }
  })

  test('returns transformed config when defined', async () => {
    const extensionInstance = await testAppConfigExtensions()

    const got = await extensionInstance.deployConfig({
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toMatchObject({embedded: true})
  })

  test('returns undefined when the transformed config is empty', async () => {
    const extensionInstance = await testAppConfigExtensions(true)

    const got = await extensionInstance.deployConfig({
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toBeUndefined()
  })
})

describe('bundleConfig', async () => {
  test('returns the uuid from appModuleUuids', async () => {
    const extensionInstance = await testThemeExtensions()

    const got = await extensionInstance.bundleConfig({
      appModuleUuids: {'theme-extension-name': 'theme-uuid'},
      developerPlatformClient,
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toEqual(
      expect.objectContaining({
        uuid: 'theme-uuid',
        context: '',
      }),
    )
  })

  test('returns the target in context for a payments app', async () => {
    const extensionInstance = await testPaymentExtensions()

    const got = await extensionInstance.bundleConfig({
      appModuleUuids: {'payment-extension-name': 'payment-uuid'},
      developerPlatformClient,
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toEqual(
      expect.objectContaining({
        uuid: 'payment-uuid',
        context: 'payments.offsite.render',
      }),
    )
  })

  test('returns the uuid for a non-uuid-managed extension', async () => {
    const extensionInstance = await testAppConfigExtensions()

    const got = await extensionInstance.bundleConfig({
      appModuleUuids: {point_of_sale: 'uuid'},
      developerPlatformClient,
      apiKey: 'apiKey',
      appConfiguration: placeholderAppConfiguration,
    })

    expect(got).toEqual(
      expect.objectContaining({
        uuid: 'uuid',
      }),
    )
  })
})

describe('contextValue', async () => {
  test('returns the target value in context for a payments extension', async () => {
    const extensionInstance = await testPaymentExtensions()

    const got = extensionInstance.contextValue

    expect(got).toEqual('payments.offsite.render')
  })

  test('returns an empty string for an extension without targets', async () => {
    const extensionInstance = await testAppConfigExtensions()

    const got = extensionInstance.contextValue

    expect(got).toEqual('')
  })

  test('returns an empty string for an extension with multiple targets', async () => {
    const extensionInstance = await testUIExtension()

    const got = extensionInstance.contextValue

    expect(got).toEqual('')
  })

  test('uses the specification target when one is resolved', () => {
    const specification = createConfigExtensionSpecification({
      identifier: 'custom',
      schema: BaseSchema,
      transformConfig: {},
      getTarget: (config) => `target-${config.name}`,
    })

    const instance = new ExtensionInstance({
      specification,
      configuration: {name: 'example'},
      configurationPath: '/app/shopify.app.toml',
      directory: '/app',
    })

    expect(instance.contextValue).toBe('target-example')
  })

  test('falls back to the single targeting entry when the specification returns no target', () => {
    const specification = createConfigExtensionSpecification({
      identifier: 'custom',
      schema: BaseSchema,
      transformConfig: {},
      getTarget: () => undefined,
    })

    const instance = new ExtensionInstance({
      specification,
      configuration: {targeting: [{target: 'admin.product.item.action'}]} as BaseConfigType,
      configurationPath: '/app/shopify.app.toml',
      directory: '/app',
    })

    expect(instance.contextValue).toBe('admin.product.item.action')
  })
})

describe('isFlow', async () => {
  test('returns true for a flow extension', async () => {
    const extensionInstance = await testFlowActionExtension()

    const got = extensionInstance.isFlow

    expect(got).toBe(true)
  })

  test('returns false for a non-flow extension', async () => {
    const extensionInstance = await testAppConfigExtensions()

    const got = extensionInstance.isFlow

    expect(got).toBe(false)
  })
})

describe('specification identity', () => {
  test.each(['single', 'uuid', 'dynamic'] as const)(
    'uses the specification identity before the %s strategy',
    (uidStrategy) => {
      const specification = createConfigExtensionSpecification({
        identifier: 'custom',
        schema: BaseSchema,
        uidStrategy,
        transformConfig: {},
        getIdentity: (config) => ({handle: `custom-${config.name}`, uid: `uid-${config.name}`}),
      })

      const instance = new ExtensionInstance({
        specification,
        configuration: {name: 'example'},
        configurationPath: '/app/shopify.app.toml',
        directory: '/app',
      })

      expect(instance.handle).toBe('custom-example')
      expect(instance.localIdentifier).toBe('custom-example')
      expect(instance.uid).toBe('uid-example')
      expect(instance.devUUID).toBe('dev-uid-example')
    },
  )

  test('uses the declared strategy when the specification returns no identity', () => {
    const specification = createConfigExtensionSpecification({
      identifier: 'custom',
      schema: BaseSchema,
      transformConfig: {},
      getIdentity: () => undefined,
    })

    const instance = new ExtensionInstance({
      specification,
      configuration: {},
      configurationPath: '/app/shopify.app.toml',
      directory: '/app',
    })

    expect(instance.handle).toBe('custom')
    expect(instance.uid).toBe('custom')
  })
})

describe('buildHandle', async () => {
  test('extensions handle is either its handle or name when specification uidStrategy is uuid', async () => {
    // Given
    const extensionInstance = await testUIExtension()

    const result = extensionInstance.configuration.handle ?? slugify(extensionInstance.configuration.name ?? '')
    // Then
    expect(extensionInstance.handle).toBe(result)
  })

  test('extensions handle is its identifier when specification uidStrategy is single', async () => {
    // Given
    const extensionInstance = await testAppConfigExtensions()

    // Then
    expect(extensionInstance.handle).toBe(extensionInstance.specification.identifier)
  })

  test('extensions handle is a hashString when specification uidStrategy is dynamic and it is a webhook subscription extension', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension()

    // When
    const subscription = extensionInstance.configuration as unknown as SingleWebhookSubscriptionType
    let result = ''
    if (subscription) {
      result = hashString(subscription.topic + subscription.uri + subscription.filter).substring(
        0,
        MAX_EXTENSION_HANDLE_LENGTH,
      )
    }

    // Then
    expect(extensionInstance.handle).toBe(result)
  })
})

describe('buildUIDFromStrategy', async () => {
  test('returns specification identifier when strategy is single', async () => {
    // Given
    const extensionInstance = await testAppConfigExtensions()

    // Then
    expect(extensionInstance.uid).toBe(extensionInstance.specification.identifier)
  })

  test('returns configuration uid when strategy is uuid and uid exists', async () => {
    // Given
    const extensionInstance = await testUIExtension({
      name: 'test-extension',
      type: 'ui_extension',
      uid: 'test-uid',
    })

    // Then
    expect(extensionInstance.uid).toBe('test-uid')
  })

  test('returns non-random UUID based on handle when strategy is uuid and no uid exists', async () => {
    // Given
    const extensionInstance = await testThemeExtensions()

    // Then
    expect(extensionInstance.uid).toBe(nonRandomUUID(extensionInstance.handle))
  })

  test('returns a custom string when strategy is dynamic and it is a webhook subscription extension without filters', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension()
    // Then
    expect(extensionInstance.uid).toBe('orders/delete::::https://my-app.com/webhooks')
  })

  test('returns a custom string when strategy is dynamic and it is a webhook subscription extension with filters', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension({
      config: {
        topic: 'orders/delete',
        uri: 'https://my-app.com/webhooks',
        filter: '123',
      },
    })
    // Then
    expect(extensionInstance.uid).toBe('orders/delete::123::https://my-app.com/webhooks')
  })

  test('resolves a relative webhook subscription uri against the application url, like the server does', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension({
      config: {topic: 'orders/create', uri: '/webhooks/orders'},
    })

    // When
    extensionInstance.resolveUIDWithApplicationUrl('https://my-app.com/')

    // Then
    expect(extensionInstance.uid).toBe('orders/create::::https://my-app.com/webhooks/orders')
  })

  test('keeps an absolute webhook subscription uri when resolving against the application url', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension({
      config: {topic: 'orders/create', uri: 'https://other.com/webhooks/orders'},
    })

    // When
    extensionInstance.resolveUIDWithApplicationUrl('https://my-app.com')

    // Then
    expect(extensionInstance.uid).toBe('orders/create::::https://other.com/webhooks/orders')
  })

  test('cuts only the webhook subscription uri to 250 characters, like the server does', async () => {
    // Given
    const longPath = `/webhooks/${'a'.repeat(300)}`
    const extensionInstance = await testSingleWebhookSubscriptionExtension({
      config: {topic: 'orders/create', uri: longPath, filter: 'id:1'},
    })

    // When
    extensionInstance.resolveUIDWithApplicationUrl('https://my-app.com')

    // Then
    expect(extensionInstance.uid).toBe(`orders/create::id:1::${`https://my-app.com${longPath}`.substring(0, 250)}`)
  })

  test('uses the dev application url for webhook subscription uids when app dev urls are patched', async () => {
    // Given
    const extensionInstance = await testSingleWebhookSubscriptionExtension({
      config: {topic: 'orders/create', uri: '/webhooks/orders'},
    })
    extensionInstance.resolveUIDWithApplicationUrl('https://my-app.com')

    // When
    extensionInstance.patchWithAppDevURLs({
      applicationUrl: 'https://tunnel.trycloudflare.com',
      redirectUrlWhitelist: [],
    })

    // Then
    expect(extensionInstance.uid).toBe('orders/create::::https://tunnel.trycloudflare.com/webhooks/orders')
  })

  test('does not change the uid of other extensions when resolving against the application url', async () => {
    // Given
    const extensionInstance = await testAppConfigExtensions()

    // When
    extensionInstance.resolveUIDWithApplicationUrl('https://my-app.com')

    // Then
    expect(extensionInstance.uid).toBe(extensionInstance.specification.identifier)
  })
})

describe('outputPath for function extensions', async () => {
  test('uses default path when build is undefined', async () => {
    // Given
    const config = {
      name: 'foo',
      type: 'function',
      api_version: '2023-07',
      configuration_ui: true,
      // build is intentionally omitted to test undefined case
    } as FunctionConfigType

    const extensionInstance = await testFunctionExtension({
      config,
      dir: 'test-function',
    })

    // Then
    expect(extensionInstance.outputPath).toBe(joinPath('test-function', 'dist', 'index.wasm'))
  })

  test('uses default path when build.path is undefined', async () => {
    // Given
    const config = functionConfiguration()
    config.build = {
      wasm_opt: true,
      // path is not defined
    }

    const extensionInstance = await testFunctionExtension({
      config,
      dir: 'test-function',
    })

    // Then
    expect(extensionInstance.outputPath).toBe(joinPath('test-function', 'dist', 'index.wasm'))
  })

  test('uses default path when build.path is defined (custom path is only applied during build)', async () => {
    // Given
    const config = functionConfiguration()
    config.build = {
      wasm_opt: true,
      path: 'custom/output.wasm',
    }

    const extensionInstance = await testFunctionExtension({
      config,
      dir: 'test-function',
    })

    // Then - outputPath always defaults to dist/index.wasm; build.path is applied by buildFunctionExtension
    expect(extensionInstance.outputPath).toBe(joinPath('test-function', 'dist', 'index.wasm'))
  })
})

describe('devSessionWatchConfig', () => {
  test('returns undefined for extension experience (watch everything)', async () => {
    const extensionInstance = await testUIExtension({type: 'ui_extension'})
    expect(extensionInstance.devSessionWatchConfig).toBeUndefined()
  })

  test('returns empty paths for configuration experience (watch nothing)', async () => {
    const extensionInstance = await testAppConfigExtensions()
    expect(extensionInstance.devSessionWatchConfig).toEqual({paths: []})
  })

  test('delegates to specification devSessionWatchConfig when defined', async () => {
    const config = functionConfiguration()
    config.build = {
      watch: 'src/**/*.rs',
      wasm_opt: true,
    }
    const extensionInstance = await testFunctionExtension({config, dir: '/tmp/my-function'})
    const watchConfig = extensionInstance.devSessionWatchConfig
    expect(watchConfig).toBeDefined()
    expect(watchConfig!.paths).toContain(joinPath('/tmp/my-function', 'src/**/*.rs'))
  })

  test('returns undefined for function extension without build.watch', async () => {
    const config = functionConfiguration()
    const extensionInstance = await testFunctionExtension({config})
    expect(extensionInstance.devSessionWatchConfig).toBeUndefined()
  })
})

describe('watchedFiles', async () => {
  test('returns files based on devSessionWatchPaths when defined', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const config = functionConfiguration()
      config.build = {
        watch: 'src/**/*.js',
        wasm_opt: true,
      }
      const extensionInstance = await testFunctionExtension({
        config,
        dir: tmpDir,
      })

      // Create some test files
      const srcDir = joinPath(tmpDir, 'src')
      await mkdir(srcDir)
      await writeFile(joinPath(srcDir, 'index.js'), 'console.log("test")')
      await writeFile(joinPath(srcDir, 'helper.js'), 'export const helper = () => {}')

      // Mock import extraction to return only the starting files (no external imports)
      const indexFile = joinPath(srcDir, 'index.js')
      vi.mocked(extractImportPathsRecursively).mockImplementation((filePath) => [filePath])

      // When
      const watchedFiles = extensionInstance.watchedFiles()

      // Then
      expect(watchedFiles).toHaveLength(2)
      expect(watchedFiles).toContain(joinPath(srcDir, 'index.js'))
      expect(watchedFiles).toContain(joinPath(srcDir, 'helper.js'))

      // Clean up
      vi.mocked(extractImportPathsRecursively).mockReset()
    })
  })

  test('respects custom ignore paths from devSessionWatchConfig', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given - create an extension with a spec that defines custom ignore paths
      const config = functionConfiguration()
      config.build = {
        watch: '**/*',
        wasm_opt: true,
      }
      const extensionInstance = await testFunctionExtension({
        config,
        dir: tmpDir,
      })

      // Override devSessionWatchConfig to include ignore paths
      vi.spyOn(extensionInstance, 'devSessionWatchConfig', 'get').mockReturnValue({
        paths: [joinPath(tmpDir, '**/*')],
        ignore: ['**/ignored-dir/**'],
      })

      // Create files - one in a normal dir, one in the ignored dir
      const srcDir = joinPath(tmpDir, 'src')
      const ignoredDir = joinPath(tmpDir, 'ignored-dir')
      await mkdir(srcDir)
      await mkdir(ignoredDir)
      await writeFile(joinPath(srcDir, 'index.js'), 'code')
      await writeFile(joinPath(ignoredDir, 'should-be-ignored.js'), 'ignored')

      // When
      const watchedFiles = extensionInstance.watchedFiles()

      // Then
      expect(watchedFiles).toContain(joinPath(srcDir, 'index.js'))
      expect(watchedFiles).not.toContain(joinPath(ignoredDir, 'should-be-ignored.js'))
    })
  })

  test('returns empty watched files for configuration extensions', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const extensionInstance = await testAppConfigExtensions(false, tmpDir)

      // Create files that should not be watched
      await writeFile(joinPath(tmpDir, 'some-file.ts'), 'code')

      // When
      const watchedFiles = extensionInstance.watchedFiles()

      // Then - configuration extensions default to empty paths, so no files watched
      expect(watchedFiles).toHaveLength(0)
    })
  })

  test('returns all files when devSessionWatchPaths is undefined', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const extensionInstance = await testUIExtension({directory: tmpDir})

      // Create some test files
      const srcDir = joinPath(tmpDir, 'src')
      await mkdir(srcDir)
      await writeFile(joinPath(srcDir, 'index.ts'), 'console.log("test")')
      await writeFile(joinPath(tmpDir, 'config.json'), '{}')

      // Mock import extraction to return only the starting files (no external imports)
      vi.mocked(extractImportPathsRecursively).mockImplementation((filePath) => [filePath])

      // When
      const watchedFiles = extensionInstance.watchedFiles()

      // Then
      expect(watchedFiles).toContain(joinPath(srcDir, 'index.ts'))
      expect(watchedFiles).toContain(joinPath(tmpDir, 'config.json'))

      // Clean up
      vi.mocked(extractImportPathsRecursively).mockReset()
    })
  })

  test('includes imported files from outside extension directory', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const extensionInstance = await testUIExtension({
        directory: tmpDir,
        entrySourceFilePath: joinPath(tmpDir, 'src', 'index.ts'),
      })

      // Create test file
      const srcDir = joinPath(tmpDir, 'src')
      await mkdir(srcDir)
      await writeFile(joinPath(srcDir, 'index.ts'), 'import "../../../shared/utils"')

      // Mock import extraction to return external import
      const externalFile = joinPath(tmpDir, '..', '..', 'shared', 'utils.ts')
      const entryFile = joinPath(srcDir, 'index.ts')
      vi.mocked(extractImportPathsRecursively).mockReturnValue([entryFile, externalFile])

      // When
      const watchedFiles = extensionInstance.watchedFiles()

      // Then
      expect(watchedFiles).toContain(joinPath(srcDir, 'index.ts'))
      expect(watchedFiles).toContain(externalFile)

      // Clean up
      vi.mocked(extractImportPathsRecursively).mockReset()
    })
  })
})

describe('rescanImports', async () => {
  test('clears cached import paths and rescans', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      const extensionInstance = await testUIExtension({
        directory: tmpDir,
        entrySourceFilePath: joinPath(tmpDir, 'src', 'index.ts'),
      })

      // Create test file
      const srcDir = joinPath(tmpDir, 'src')
      await mkdir(srcDir)
      await writeFile(joinPath(srcDir, 'index.ts'), 'import "./local"')

      // Reset mock to ensure clean state
      vi.mocked(extractImportPathsRecursively).mockReset()

      // First scan with one set of imports
      vi.mocked(extractImportPathsRecursively).mockReturnValue(['./local'])
      // This will populate cachedImportPaths
      extensionInstance.watchedFiles()

      // Update the mock to return different imports
      vi.mocked(extractImportPathsRecursively).mockReturnValue(['./local', '../external'])

      // When
      const newImports = await extensionInstance.rescanImports()

      // Then
      expect(extractImportPathsRecursively).toHaveBeenCalledTimes(2)
      // Note: we can't directly test the result since resolvePath would fail in test

      // Clean up
      vi.mocked(extractImportPathsRecursively).mockReset()
    })
  })
})

describe('SHOPIFY_CLI_DISABLE_IMPORT_SCANNING', () => {
  test('skips import scanning when env var is set', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const extensionInstance = await testUIExtension({
        directory: tmpDir,
        entrySourceFilePath: joinPath(tmpDir, 'src', 'index.ts'),
      })

      const srcDir = joinPath(tmpDir, 'src')
      await mkdir(srcDir)
      await writeFile(joinPath(srcDir, 'index.ts'), 'import "../shared"')

      vi.mocked(extractImportPathsRecursively).mockReset()
      vi.mocked(extractImportPathsRecursively).mockReturnValue(['/some/external/file.ts'])

      process.env.SHOPIFY_CLI_DISABLE_IMPORT_SCANNING = '1'
      try {
        const watched = extensionInstance.watchedFiles()
        expect(extractImportPathsRecursively).not.toHaveBeenCalled()
        expect(watched.some((file) => file.includes('external'))).toBe(false)
      } finally {
        delete process.env.SHOPIFY_CLI_DISABLE_IMPORT_SCANNING
        vi.mocked(extractImportPathsRecursively).mockReset()
      }
    })
  })
})

describe('getDevSessionUpdateMessages', () => {
  const deployStep: ClientSteps = [
    {lifecycle: 'deploy', steps: [{id: 'build-theme', name: 'Build Theme', type: 'build_theme'}]},
  ]

  function instanceFor(specification: ExtensionSpecification): ExtensionInstance {
    return new ExtensionInstance({
      configuration: {name: 'test extension', type: specification.identifier} as BaseConfigType,
      configurationPath: '',
      directory: '/tmp/test-extension',
      specification,
    })
  }

  function specWithNoLocalDevOutput(identifier = 'no_local_dev_output') {
    return createExtensionSpecification({identifier, schema: BaseSchema, appModuleFeatures: () => []})
  }

  test('returns the default message for a module with no local dev output on the first dev session', async () => {
    const extensionInstance = instanceFor(specWithNoLocalDevOutput())

    const got = await extensionInstance.getDevSessionUpdateMessages({status: 'created'})

    expect(got).toEqual([DEFAULT_DEV_SESSION_UPDATE_MESSAGE])
  })

  test('returns nothing for a module with no local dev output on subsequent updates', async () => {
    const extensionInstance = instanceFor(specWithNoLocalDevOutput())

    const got = await extensionInstance.getDevSessionUpdateMessages({status: 'updated'})

    expect(got).toBeUndefined()
  })

  test('returns nothing when the module contributes features', async () => {
    const extensionInstance = instanceFor(
      createExtensionSpecification({
        identifier: 'has_features',
        schema: BaseSchema,
        appModuleFeatures: () => ['localization'],
      }),
    )

    expect(extensionInstance.hasNoLocalDevOutput).toBe(false)
    await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toBeUndefined()
  })

  test('returns nothing when the module has deploy steps', async () => {
    const extensionInstance = instanceFor(
      createExtensionSpecification({
        identifier: 'has_deploy_steps',
        schema: BaseSchema,
        appModuleFeatures: () => [],
        clientSteps: deployStep,
      }),
    )

    expect(extensionInstance.hasNoLocalDevOutput).toBe(false)
    await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toBeUndefined()
  })

  test('returns nothing when the module produces build output', async () => {
    const extensionInstance = instanceFor(
      createExtensionSpecification({
        identifier: 'has_build_output',
        schema: BaseSchema,
        appModuleFeatures: () => [],
        getOutputRelativePath: () => 'dist/main.js',
      }),
    )

    expect(extensionInstance.hasNoLocalDevOutput).toBe(false)
    await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toBeUndefined()
  })

  test('returns nothing for app config modules, which are summarised together instead', async () => {
    const extensionInstance = instanceFor(
      createConfigExtensionSpecification({
        identifier: 'app_config_without_messages',
        schema: BaseSchema,
        transformConfig: {},
      }),
    )

    expect(extensionInstance.isAppConfigExtension).toBe(true)
    expect(extensionInstance.hasNoLocalDevOutput).toBe(true)
    await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toBeUndefined()
  })

  test('evaluates the app config exclusion lazily, so a remotely-rewritten experience is respected', async () => {
    const specification = specWithNoLocalDevOutput()
    const extensionInstance = instanceFor({...specification, experience: 'configuration'})

    await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toBeUndefined()
  })

  describe('per-spec override', () => {
    const override = async () => ['Custom message']

    test('wins over the default through createExtensionSpecification', async () => {
      const extensionInstance = instanceFor(
        createExtensionSpecification({
          identifier: 'override_via_extension_spec',
          schema: BaseSchema,
          appModuleFeatures: () => [],
          getDevSessionUpdateMessages: override,
        }),
      )

      await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toEqual([
        'Custom message',
      ])
    })

    test('wins over the default through createConfigExtensionSpecification', async () => {
      const extensionInstance = instanceFor(
        createConfigExtensionSpecification({
          identifier: 'override_via_config_spec',
          schema: BaseSchema,
          transformConfig: {},
          getDevSessionUpdateMessages: override,
        }),
      )

      await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toEqual([
        'Custom message',
      ])
    })

    test('wins over the default when spread onto a contract based module specification', async () => {
      const specification = createContractBasedModuleSpecification({
        identifier: 'override_via_contract_based_spec',
        experience: 'extension',
        uidStrategy: 'single',
        appModuleFeatures: () => [],
      })
      const extensionInstance = instanceFor({...specification, getDevSessionUpdateMessages: override})

      await expect(extensionInstance.getDevSessionUpdateMessages({status: 'created'})).resolves.toEqual([
        'Custom message',
      ])
    })

    test('is used even on subsequent updates, where the default stays quiet', async () => {
      const extensionInstance = instanceFor(
        createExtensionSpecification({
          identifier: 'override_on_update',
          schema: BaseSchema,
          appModuleFeatures: () => [],
          getDevSessionUpdateMessages: override,
        }),
      )

      await expect(extensionInstance.getDevSessionUpdateMessages({status: 'updated'})).resolves.toEqual([
        'Custom message',
      ])
    })

    test('receives the dev session context', async () => {
      const getDevSessionUpdateMessages = vi.fn().mockResolvedValue([])
      const extensionInstance = instanceFor(
        createExtensionSpecification({
          identifier: 'override_receiving_context',
          schema: BaseSchema,
          appModuleFeatures: () => [],
          getDevSessionUpdateMessages,
        }),
      )

      await extensionInstance.getDevSessionUpdateMessages({status: 'created'})

      expect(getDevSessionUpdateMessages).toHaveBeenCalledWith(extensionInstance.configuration, {status: 'created'})
    })
  })

  describe('local specifications matching the default', () => {
    test('only modules with no local dev output receive the default message', async () => {
      const specifications = await loadLocalExtensionsSpecifications()

      const matching = specifications
        .filter((specification) => {
          const extensionInstance = instanceFor(specification)
          return !extensionInstance.isAppConfigExtension && extensionInstance.hasNoLocalDevOutput
        })
        .map((specification) => specification.identifier)
        .sort()

      expect(matching).toEqual([
        'editor_extension_collection',
        'flow_action',
        'flow_trigger',
        'flow_trigger_lifecycle_callback',
        'payments_extension',
      ])
    })
  })
})
