import {
  CustomOnsitePaymentsAppExtensionConfigType,
  CustomOnsitePaymentsAppExtensionSchema,
  customOnsitePaymentsAppExtensionDeployConfig,
  MAX_CHECKOUT_PAYMENT_METHOD_FIELDS,
} from './custom_onsite_payments_app_extension_schema.js'
import {buildCheckoutPaymentMethodFields} from './payments_app_extension_test_helper.js'
import {describe, expect, test} from 'vitest'
import {zod} from '@shopify/cli-kit/node/schema'

const config: CustomOnsitePaymentsAppExtensionConfigType = {
  name: 'CustomOnsite extension',
  type: 'payments_extension',
  targeting: [{target: 'payments.custom-onsite.render'}],
  payment_session_url: 'http://foo.bar',
  refund_session_url: 'http://foo.bar',
  capture_session_url: 'http://foo.bar',
  void_session_url: 'http://foo.bar',
  confirmation_callback_url: 'http://foo.bar',
  update_payment_session_url: 'http://foo.bar',
  merchant_label: 'some-label',
  supported_countries: ['CA'],
  supported_payment_methods: ['visa'],
  supported_buyer_contexts: [{currency: 'EUR', countries: ['DE', 'FR']}],
  supports_oversell_protection: true,
  supports_3ds: true,
  supports_installments: true,
  supports_deferred_payments: true,
  test_mode_available: true,
  multiple_capture: true,
  api_version: '2022-07',
  checkout_payment_method_fields: [],
  modal_payment_method_fields: [],
  description: 'Custom onsite extension',
  ui_extension_handle: 'sample-ui-extension',
  input: {
    metafield_identifiers: {
      namespace: 'namespace',
      key: 'key',
    },
  },
}

describe('CustomOnsitePaymentsAppExtensionSchema', () => {
  test('validates a configuration with valid fields', async () => {
    // When
    const {success} = CustomOnsitePaymentsAppExtensionSchema.safeParse(config)

    // Then
    expect(success).toBe(true)
  })

  test('returns an error if no target is provided', async () => {
    // When/Then
    expect(() =>
      CustomOnsitePaymentsAppExtensionSchema.parse({
        ...config,
        targeting: [{...config.targeting[0]!, target: null}],
      }),
    ).toThrowError(
      new zod.ZodError([
        {
          received: null,
          code: zod.ZodIssueCode.invalid_literal,
          expected: 'payments.custom-onsite.render',
          path: ['targeting', 0, 'target'],
          message: 'Invalid literal value, expected "payments.custom-onsite.render"',
        },
      ]),
    )
  })

  test('returns an error if buyer_label_translations has invalid format', async () => {
    // When/Then
    expect(() =>
      CustomOnsitePaymentsAppExtensionSchema.parse({
        ...config,
        buyer_label_translations: [{label: 'Translation without locale key'}],
      }),
    ).toThrowError(
      new zod.ZodError([
        {
          code: zod.ZodIssueCode.invalid_type,
          expected: 'string',
          received: 'undefined',
          path: ['buyer_label_translations', 0, 'locale'],
          message: 'Required',
        },
      ]),
    )
  })

  test('returns an error if checkout_payment_method_fields has too many fields', async () => {
    // When/Then
    expect(() =>
      CustomOnsitePaymentsAppExtensionSchema.parse({
        ...config,
        checkout_payment_method_fields: buildCheckoutPaymentMethodFields(MAX_CHECKOUT_PAYMENT_METHOD_FIELDS + 1),
      }),
    ).toThrowError(
      new zod.ZodError([
        {
          code: zod.ZodIssueCode.too_big,
          maximum: MAX_CHECKOUT_PAYMENT_METHOD_FIELDS,
          type: 'array',
          inclusive: true,
          exact: false,
          message: `The extension can't have more than ${MAX_CHECKOUT_PAYMENT_METHOD_FIELDS} checkout_payment_method_fields`,
          path: ['checkout_payment_method_fields'],
        },
      ]),
    )
  })

  test('parses successfully when optional fields are omitted', async () => {
    // Given
    const configWithoutOptionalFields = {...config}
    delete configWithoutOptionalFields.supports_installments
    delete configWithoutOptionalFields.supports_deferred_payments
    delete configWithoutOptionalFields.supports_3ds

    // When
    const result = CustomOnsitePaymentsAppExtensionSchema.safeParse(configWithoutOptionalFields)

    // Then
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data).not.toHaveProperty('supports_installments')
      expect(result.data).not.toHaveProperty('supports_deferred_payments')
      expect(result.data).not.toHaveProperty('supports_3ds')
    }
  })

  test('validates a configuration with valid start_verification_session_url', async () => {
    // Given
    const configWithVerificationUrl = {
      ...config,
      start_verification_session_url: 'https://example.com/verify',
    }

    // When
    const {success} = CustomOnsitePaymentsAppExtensionSchema.safeParse(configWithVerificationUrl)

    // Then
    expect(success).toBe(true)
  })

  test('validates a configuration without start_verification_session_url', async () => {
    // Given
    const configWithoutVerificationUrl = {
      ...config,
      start_verification_session_url: undefined,
    }

    // When
    const {success} = CustomOnsitePaymentsAppExtensionSchema.safeParse(configWithoutVerificationUrl)

    // Then
    expect(success).toBe(true)
  })

  test('returns an error if start_verification_session_url is not a valid URL', async () => {
    // When/Then
    expect(() =>
      CustomOnsitePaymentsAppExtensionSchema.parse({
        ...config,
        start_verification_session_url: 'not-a-valid-url',
      }),
    ).toThrowError(
      new zod.ZodError([
        {
          validation: 'url',
          code: zod.ZodIssueCode.invalid_string,
          message: 'Invalid url',
          path: ['start_verification_session_url'],
        },
      ]),
    )
  })

  test('returns an error if start_verification_session_url is an empty string', async () => {
    // When/Then
    expect(() =>
      CustomOnsitePaymentsAppExtensionSchema.parse({
        ...config,
        start_verification_session_url: '',
      }),
    ).toThrowError(
      new zod.ZodError([
        {
          validation: 'url',
          code: zod.ZodIssueCode.invalid_string,
          message: 'Invalid url',
          path: ['start_verification_session_url'],
        },
      ]),
    )
  })
})

describe('customOnsitePaymentsAppExtensionDeployConfig', () => {
  test('maps deploy configuration from extension configuration', async () => {
    // When
    const result = await customOnsitePaymentsAppExtensionDeployConfig(config)

    // Then
    expect(result).toMatchObject({
      api_version: config.api_version,
      start_payment_session_url: config.payment_session_url,
      start_refund_session_url: config.refund_session_url,
      start_capture_session_url: config.capture_session_url,
      start_void_session_url: config.void_session_url,
      confirmation_callback_url: config.confirmation_callback_url,
      update_payment_session_url: config.update_payment_session_url,
      merchant_label: config.merchant_label,
      supports_oversell_protection: config.supports_oversell_protection,
      supports_3ds: config.supports_3ds,
      supports_installments: config.supports_installments,
      supports_deferred_payments: config.supports_deferred_payments,
      supported_countries: config.supported_countries,
      supported_payment_methods: config.supported_payment_methods,
      supported_buyer_contexts: config.supported_buyer_contexts,
      test_mode_available: config.test_mode_available,
      multiple_capture: config.multiple_capture,
      default_buyer_label: config.buyer_label,
      buyer_label_to_locale: config.buyer_label_translations,
      checkout_payment_method_fields: config.checkout_payment_method_fields,
      modal_payment_method_fields: config.modal_payment_method_fields,
      ui_extension_handle: config.ui_extension_handle,
    })
  })

  test('maps start_verification_session_url when provided in extension configuration', async () => {
    // Given
    const configWithVerificationUrl = {
      ...config,
      start_verification_session_url: 'https://example.com/verify',
    }

    // When
    const result = await customOnsitePaymentsAppExtensionDeployConfig(configWithVerificationUrl)

    // Then
    expect(result).toMatchObject({
      start_verification_session_url: 'https://example.com/verify',
    })
  })

  test('does not include start_verification_session_url when not provided in extension configuration', async () => {
    // Given
    const configWithoutVerificationUrl = {
      ...config,
      start_verification_session_url: undefined,
    }

    // When
    const result = await customOnsitePaymentsAppExtensionDeployConfig(configWithoutVerificationUrl)

    // Then
    expect(result).toMatchObject({
      start_verification_session_url: undefined,
    })
  })
})
