import {FunctionConfigType, FunctionExtensionSchema} from './function.js'
import {placeholderAppConfiguration, testFunctionExtension} from '../../app/app.test-data.js'
import {ExtensionInstance} from '../extension-instance.js'
import {inTemporaryDirectory, mkdir, touchFile, writeFile} from '@shopify/cli-kit/node/fs'
import {joinPath} from '@shopify/cli-kit/node/path'
import {AbortError} from '@shopify/cli-kit/node/error'
import {beforeEach, describe, expect, test} from 'vitest'
import {getPathValue} from '@shopify/cli-kit/common/object'
import {zod} from '@shopify/cli-kit/node/schema'

describe('functionConfiguration', () => {
  let extension: ExtensionInstance<FunctionConfigType>
  const apiKey = 'app-key'
  const inputQuery = 'query { f }'

  const config = {
    name: 'function',
    type: 'function',
    metafields: [],
    description: 'my function',
    build: {
      command: 'make build',
      path: 'dist/index.wasm',
      wasm_opt: true,
    },
    ui: {
      paths: {
        create: '/create',
        details: '/details/:id',
      },
      enable_create: true,
      handle: 'linked-ext-handle',
    },
    configuration_ui: false,
    api_version: '2022-07',
    input: {
      variables: {
        namespace: 'namespace',
        key: 'key',
      },
    },
  }

  beforeEach(async () => {
    extension = await testFunctionExtension({
      dir: '/function',
      config: {...config},
    })
  })

  test('returns a snake_case object with all possible fields', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      await writeFile(extension.inputQueryPath, inputQuery)

      // When
      const got = await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })

      // Then
      expect(got).toEqual({
        title: extension.configuration.name,
        description: extension.configuration.description,
        app_key: apiKey,
        api_type: undefined,
        api_version: extension.configuration.api_version,
        ui: {
          app_bridge: {
            details_path: extension.configuration.ui!.paths!.details,
            create_path: extension.configuration.ui!.paths!.create,
          },
          ui_extension_handle: extension.configuration.ui!.handle,
        },
        input_query: inputQuery,
        input_query_variables: {
          single_json_metafield: {
            namespace: 'namespace',
            key: 'key',
          },
        },
        enable_creation_ui: true,
        localization: {},
        targets: undefined,
        module_id: expect.any(String),
      })
    })
  })

  test('returns a snake_case object with only required fields', async () => {
    await inTemporaryDirectory(async (_tmpDir) => {
      // Given
      extension.configuration.input = undefined
      extension.configuration.ui = undefined

      // When
      const got = await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })

      // Then
      expect(got).toEqual({
        title: extension.configuration.name,
        description: extension.configuration.description,
        app_key: apiKey,
        api_type: undefined,
        api_version: extension.configuration.api_version,
        module_id: expect.any(String),
        enable_creation_ui: true,
        input_query: undefined,
        input_query_variables: undefined,
        ui: undefined,
        localization: {},
        targets: undefined,
      })
    })
  })

  test('parses targeting array', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      const inputQuery = 'query { f }'
      const inputQueryFileName = 'target1.graphql'
      extension.configuration.targeting = [
        {target: 'some.api.target1', input_query: inputQueryFileName},
        {target: 'some.api.target2', export: 'run_target2'},
      ]
      await writeFile(joinPath(extension.directory, inputQueryFileName), inputQuery)

      // When
      const got = await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })

      // Then
      expect(getPathValue(got!, 'targets')).toEqual([
        {handle: 'some.api.target1', input_query: inputQuery},
        {handle: 'some.api.target2', export: 'run_target2'},
      ])
    })
  })

  test('maps target-level input variables to the deploy payload', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      extension.configuration.input = undefined
      extension.configuration.targeting = [
        {target: 'some.api.target1', input_variables: {namespace: 'target-namespace', key: 'target-key'}},
        {target: 'some.api.target2', export: 'run_target2'},
      ]

      // When
      const got = await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })

      // Then
      expect(getPathValue(got!, 'targets')).toEqual([
        {
          handle: 'some.api.target1',
          input_query_variables: {
            single_json_metafield: {namespace: 'target-namespace', key: 'target-key'},
          },
        },
        {handle: 'some.api.target2', export: 'run_target2'},
      ])
      expect(getPathValue(got!, 'input_query_variables')).toBeUndefined()
    })
  })

  test('aborts when an target input query file is missing', async () => {
    // Given
    extension.configuration.targeting = [{target: 'some.api.target1', input_query: 'this-is-not-a-file.graphql'}]

    // When & Then
    await expect(() =>
      extension.deployConfig({apiKey, appConfiguration: placeholderAppConfiguration}),
    ).rejects.toThrowError(AbortError)
  })

  describe('with legacy type', async () => {
    beforeEach(async () => {
      extension = await testFunctionExtension({
        config: {
          ...config,
          type: 'order_discounts',
          targeting: undefined,
        },
      })
    })

    test('returns a snake_case object with all possible fields', async () => {
      await inTemporaryDirectory(async (tmpDir) => {
        // Given
        const inputQuery = 'inputQuery'
        extension.directory = tmpDir
        await touchFile(extension.inputQueryPath)
        await writeFile(extension.inputQueryPath, inputQuery)

        // When
        const got = await extension.deployConfig({
          apiKey,
          appConfiguration: placeholderAppConfiguration,
        })

        // Then
        expect(got).toEqual({
          title: extension.configuration.name,
          description: extension.configuration.description,
          app_key: apiKey,
          api_type: 'order_discounts',
          api_version: extension.configuration.api_version,
          ui: {
            app_bridge: {
              details_path: extension.configuration.ui!.paths!.details,
              create_path: extension.configuration.ui!.paths!.create,
            },
            ui_extension_handle: extension.configuration.ui!.handle,
          },
          input_query: inputQuery,
          input_query_variables: {
            single_json_metafield: {
              namespace: 'namespace',
              key: 'key',
            },
          },
          enable_creation_ui: true,
          module_id: expect.any(String),
          localization: {},
          targets: undefined,
        })
      })
    })

    test('returns a snake_case object with only required fields', async () => {
      await inTemporaryDirectory(async (_tmpDir) => {
        // Given
        extension.configuration.input = undefined
        extension.configuration.ui = undefined

        // When
        const got = await extension.deployConfig({
          apiKey,
          appConfiguration: placeholderAppConfiguration,
        })

        // Then
        expect(got).toEqual({
          title: extension.configuration.name,
          description: extension.configuration.description,
          app_key: apiKey,
          api_type: 'order_discounts',
          api_version: extension.configuration.api_version,
          module_id: expect.any(String),
          enable_creation_ui: true,
          input_query: undefined,
          input_query_variables: undefined,
          ui: undefined,
          localization: {},
          targets: undefined,
        })
      })
    })
  })

  test('parses locales', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      const enLocale = {
        extension: {
          title: 'English Title',
          description: 'English Description',
        },
      }

      const localesDir = joinPath(extension.directory, 'locales')
      await mkdir(localesDir)
      await writeFile(joinPath(localesDir, 'en.default.json'), JSON.stringify(enLocale))

      // When
      const got = await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })

      // Then
      const expectedLocalization = {
        default_locale: 'en',
        translations: {
          en: 'eyJleHRlbnNpb24iOnsidGl0bGUiOiJFbmdsaXNoIFRpdGxlIiwiZGVzY3JpcHRpb24iOiJFbmdsaXNoIERlc2NyaXB0aW9uIn19',
        },
      }

      expect(getPathValue(got!, 'localization')).toEqual(expectedLocalization)
    })
  })

  test("parses ui.handle when it's an empty string", async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      extension.configuration.ui!.handle = ''

      // When
      const got = (await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })) as unknown as {ui: {ui_extension_handle: string}}

      // Then
      expect(got.ui?.ui_extension_handle).toStrictEqual('')
    })
  })

  test("parses ui.handle when it's undefined", async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      // Given
      extension.directory = tmpDir
      extension.configuration.ui = undefined

      // When
      const got = (await extension.deployConfig({
        apiKey,
        appConfiguration: placeholderAppConfiguration,
      })) as unknown as {ui: {ui_extension_handle: string}}

      // Then
      expect(got.ui?.ui_extension_handle).toBeUndefined()
    })
  })

  test('accepts configuration with typegen_command in build section', async () => {
    // Given
    const configWithTypegen = {
      name: 'function',
      type: 'function',
      metafields: [],
      description: 'my function',
      build: {
        command: 'zig build -Doptimize=ReleaseSmall',
        path: 'dist/index.wasm',
        wasm_opt: true,
        typegen_command: 'npx shopify-function-codegen --schema schema.graphql',
      },
      configuration_ui: false,
      api_version: '2022-07',
    }

    // When
    const extension = await testFunctionExtension({
      dir: '/function',
      config: configWithTypegen as FunctionConfigType,
    })

    // Then
    expect(extension.configuration.build?.typegen_command).toBe('npx shopify-function-codegen --schema schema.graphql')
    expect(extension.typegenCommand).toBe('npx shopify-function-codegen --schema schema.graphql')
  })

  test('accepts configuration without build section', async () => {
    // Given
    const configWithoutBuild = {
      name: 'function',
      type: 'function',
      metafields: [],
      description: 'my function',
      // build section is omitted
      configuration_ui: false,
      api_version: '2022-07',
    }

    // When
    const extension = await testFunctionExtension({
      dir: '/function',
      config: configWithoutBuild as FunctionConfigType,
    })

    // Then
    expect(extension.configuration.build).toBeUndefined()
    expect(extension.outputPath).toBe(joinPath('/function', 'dist', 'index.wasm'))
  })
})

describe('input variables placement', () => {
  const baseConfig = {name: 'function', type: 'function', api_version: '2022-07'}
  const extensionVariables = {namespace: 'namespace', key: 'key'}
  const targetVariables = {namespace: 'target-namespace', key: 'target-key'}

  const parseIssues = (config: object): zod.ZodIssue[] => {
    const result = FunctionExtensionSchema.safeParse(config)
    return result.success ? [] : result.error.issues
  }

  test('rejects a target declaring input variables when the extension declares them too', () => {
    // Given
    const config = {
      ...baseConfig,
      input: {variables: extensionVariables},
      targeting: [{target: 'some.api.target1', input_variables: targetVariables}],
    }

    // When
    const got = parseIssues(config)

    // Then
    expect(got).toEqual([
      expect.objectContaining({
        path: ['input', 'variables'],
        message:
          'Input variables must be defined either at the extension level or on a target, not both. ' +
          'Remove `input.variables` from your extension configuration. ' +
          'Declare `input_variables` on each target that needs them instead.',
      }),
    ])
  })

  test('reports the conflict once however many targets declare input variables', () => {
    // Given
    const config = {
      ...baseConfig,
      input: {variables: extensionVariables},
      targeting: [
        {target: 'some.api.target1', input_variables: targetVariables},
        {target: 'some.api.target2', export: 'run_target2'},
        {target: 'some.api.target3', input_variables: targetVariables},
      ],
    }

    // When
    const got = parseIssues(config)

    // Then
    expect(got.map((issue) => issue.path)).toEqual([['input', 'variables']])
  })

  test('accepts input variables declared only on targets', () => {
    // Given
    const config = {
      ...baseConfig,
      targeting: [
        {target: 'some.api.target1', input_variables: targetVariables},
        {target: 'some.api.target2', export: 'run_target2'},
      ],
    }

    // When
    const got = parseIssues(config)

    // Then
    expect(got).toEqual([])
  })

  test('accepts extension-level input variables when no target declares them', () => {
    // Given
    const config = {
      ...baseConfig,
      input: {variables: extensionVariables},
      targeting: [{target: 'some.api.target1', input_query: 'target1.graphql'}],
    }

    // When
    const got = parseIssues(config)

    // Then
    expect(got).toEqual([])
  })
})
