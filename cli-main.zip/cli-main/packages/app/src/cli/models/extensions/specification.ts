import {ZodSchemaType, BaseConfigType, BaseSchema} from './schemas.js'
import {ExtensionInstance} from './extension-instance.js'
import {patchAppRelativeUrls} from './specifications/validation/app_relative_urls.js'
import {blocks} from '../../constants.js'
import {ClientSteps} from '../../services/build/client-steps.js'

import {Flag} from '../../utilities/developer-platform-client.js'
import {AppConfiguration} from '../app/app.js'
import {loadLocalesConfig} from '../../utilities/extensions/locales-configuration.js'
import {ApplicationURLs} from '../../services/dev/urls.js'
import {Result} from '@shopify/cli-kit/node/result'
import {capitalize} from '@shopify/cli-kit/common/string'
import {ParseConfigurationResult, zod} from '@shopify/cli-kit/node/schema'
import {getPathValue, setPathValue} from '@shopify/cli-kit/common/object'
import {JsonMapType} from '@shopify/cli-kit/node/toml'

export type ExtensionFeature =
  | 'ui_preview'
  | 'function'
  | 'theme'
  | 'cart_url'
  | 'esbuild'
  | 'single_js_entry_path'
  | 'localization'
  | 'generates_source_maps'

export type TransformationConfig = Record<string, string>

/**
 * Options for converting platform content to the local format.
 *
 * `handle` is the module handle. Some modules keep it outside their config, so the config alone can't restore it.
 */
export interface RemoteToLocalTransformOptions {
  flags?: Flag[]
  handle?: string
}

export interface CustomTransformationConfig {
  forward?: (obj: object, appConfiguration: AppConfiguration, options?: {flags?: Flag[]}) => object
  reverse?: (obj: object, options?: RemoteToLocalTransformOptions) => object
}

type ExtensionExperience = 'extension' | 'configuration'

export function isAppConfigSpecification(spec: {experience: string}): boolean {
  return spec.experience === 'configuration'
}
type UidStrategy = 'single' | 'dynamic' | 'uuid'

export enum AssetIdentifier {
  ShouldRender = 'should_render',
  Main = 'main',
  Tools = 'tools',
  Instructions = 'instructions',
  Intents = 'intents',
}

export interface Asset {
  identifier: AssetIdentifier
  outputFileName: string
  content: string
}

export interface BuildAsset {
  filepath: string
  module: string
  static?: boolean
}

interface ExtensionDeployConfigContext {
  appConfiguration: AppConfiguration
}

export type DevSessionUpdateStatus = 'created' | 'updated'

export interface DevSessionUpdateContext {
  status: DevSessionUpdateStatus
}

/**
 * Extension specification with all the needed properties and methods to load an extension.
 */
export interface ExtensionSpecification<TConfiguration extends BaseConfigType = BaseConfigType> {
  identifier: string
  externalIdentifier: string
  externalName: string
  group?: string
  additionalIdentifiers: string[]
  partnersWebIdentifier: string
  surface: string
  registrationLimit: number
  experience: ExtensionExperience
  clientSteps?: ClientSteps
  dependency?: string
  graphQLType?: string
  getOutputRelativePath?: (extension: ExtensionInstance<TConfiguration>) => string
  getBundleExtensionStdinContent?: (config: TConfiguration) => {main: string; assets?: Asset[]}
  deployConfig?: (
    config: TConfiguration,
    directory: string,
    apiKey: string,
    moduleId?: string,
    context?: ExtensionDeployConfigContext,
  ) => Promise<Record<string, unknown> | undefined>
  validate?: (config: TConfiguration, configPath: string, directory: string) => Promise<Result<unknown, string>>
  preDeployValidation?: (extension: ExtensionInstance<TConfiguration>) => Promise<void>
  buildValidation?: (extension: ExtensionInstance<TConfiguration>, outputPath: string) => Promise<void>
  hasExtensionPointTarget?(config: TConfiguration, target: string): boolean
  appModuleFeatures: (config?: TConfiguration) => ExtensionFeature[]
  getDevSessionUpdateMessages?: (config: TConfiguration, context: DevSessionUpdateContext) => Promise<string[]>
  /** Top-level URL fields to resolve against the app URL. The remote contract must accept relative values. */
  appRelativeUrlFields?: ReadonlyArray<keyof TConfiguration & string>
  patchWithAppDevURLs?: (config: TConfiguration, urls: ApplicationURLs) => void

  /**
   * If required, convert configuration from the format used in the local filesystem to that expected by the platform.
   *
   * @param localContent - Content taken from the local filesystem
   * @returns Transformed configuration to send to the platform in place of the locally provided content
   */
  transformLocalToRemote?: (localContent: object, appConfiguration: AppConfiguration) => object

  /**
   * If required, convert configuration from the platform to the format used locally in the filesystem.
   *
   * @param remoteContent - Platform provided content taken from an instance of this module
   * @param existingAppConfiguration - Existing app configuration on the filesystem that this transformed content may be merged with
   * @param options - Additional options to be used in the transformation
   * @returns Transformed configuration to use in place of the platform provided content
   */
  transformRemoteToLocal?: (remoteContent: object, options?: RemoteToLocalTransformOptions) => object

  /** Split parsed app configuration into module configurations. Defaults to a single module. */
  expandConfig?: (config: TConfiguration, options: {flags: Flag[]}) => object[]

  /** Resolve a module's identity from its configuration, or use the declared UID strategy. */
  getIdentity?: (config: TConfiguration) => {handle: string; uid: string} | undefined

  /** Resolve a module's target from its configuration, or fall back to the single `targeting` entry. */
  getTarget?: (config: TConfiguration) => string | undefined

  uidStrategy: UidStrategy

  /**
   * Have this specification contribute to the schema used to validate app configuration. For specifications that don't
   * form part of app config, they can return the schema unchanged.
   *
   * @param appConfigSchema - The schema used to validate app configuration. This will usually be the output from calling this function for another specification
   * @returns The schema used to validate app configuration, with this specification's schema merged in
   */
  contributeToAppConfigurationSchema: (appConfigSchema: ZodSchemaType<unknown>) => ZodSchemaType<unknown>

  /**
   * Parse some provided configuration into a valid configuration object for this extension.
   */
  parseConfigurationObject: (configurationObject: object) => ParseConfigurationResult<TConfiguration>

  contributeToSharedTypeFile?: (
    extension: ExtensionInstance<TConfiguration>,
    typeDefinitionsByFile: Map<string, Set<string>>,
  ) => Promise<void>

  /**
   * Custom watch configuration for dev sessions.
   * Return a DevSessionWatchConfig with paths to watch and optionally paths to ignore,
   * or undefined to watch all files in the extension directory.
   */
  devSessionWatchConfig?: (extension: ExtensionInstance<TConfiguration>) => DevSessionWatchConfig | undefined
}

export interface DevSessionWatchConfig {
  /** Absolute paths or globs to watch */
  paths: string[]
  /** Glob patterns to ignore. When provided, replaces the default ignore list entirely. */
  ignore?: string[]
}

/**
 * Extension specification, explicitly marked as having taken remote configuration values into account.
 */
export type RemoteAwareExtensionSpecification<TConfiguration extends BaseConfigType = BaseConfigType> =
  ExtensionSpecification<TConfiguration> & {
    loadedRemoteSpecs: true
  }

/**
 * These fields are forbidden when creating a new ExtensionSpec
 * They belong to the ExtensionSpec interface, but the values are obtained from the API
 * and should not be set by us locally
 */
type ForbiddenFields =
  | 'registrationLimit'
  | 'category'
  | 'externalIdentifier'
  | 'externalName'
  | 'name'
  | 'surface'
  | 'contributeToAppConfigurationSchema'
  | 'parseConfigurationObject'

/**
 * Partial ExtensionSpec type used when creating a new ExtensionSpec, the only mandatory field is the identifier
 */
interface CreateExtensionSpecType<TConfiguration extends BaseConfigType = BaseConfigType> extends Partial<
  Omit<ExtensionSpecification<TConfiguration>, ForbiddenFields>
> {
  identifier: string
  appModuleFeatures: (config?: TConfiguration) => ExtensionFeature[]
  schema?: ZodSchemaType<TConfiguration>
}

/**
 * Create a new ui extension spec.
 *
 * Everything but "identifer" is optional.
 * ```ts
 * identifier: string // unique identifier for the extension type
 * externalIdentifier: string // identifier used externally (default: same as "identifier")
 * partnersWebIdentifier: string // identifier used in the partners web UI (default: same as "identifier")
 * surface?: string // surface where the extension is going to be rendered (default: 'unknown')
 * dependency?: {name: string; version: string} // dependency to be added to the extension's package.json
 * graphQLType?: string // GraphQL type of the extension (default: same as "identifier")
 * schema?: ZodSchemaType<TConfiguration> // schema used to validate the extension's configuration (default: BaseUIExtensionSchema)
 * getBundleExtensionStdinContent?: (configuration: TConfiguration) => string // function to generate the content of the stdin file used to bundle the extension
 * validate?: (configuration: TConfiguration, directory: string) => Promise<Result<undefined, Error>> // function to validate the extension's configuration
 * preDeployValidation?: (configuration: TConfiguration) => Promise<void> // function to validate the extension's configuration before deploying it
 * deployConfig?: (configuration: TConfiguration, directory: string) => Promise<{[key: string]: unknown}> // function to generate the extensions configuration payload to be deployed
 * hasExtensionPointTarget?: (configuration: TConfiguration, target: string) => boolean // function to determine if the extension has a given extension point target
 * ```
 */
export function createExtensionSpecification<TConfiguration extends BaseConfigType = BaseConfigType>(
  spec: CreateExtensionSpecType<TConfiguration>,
): ExtensionSpecification<TConfiguration> {
  const defaults = {
    // these two fields are going to be overridden by the extension specification API response,
    // but we need them to have a default value for tests
    externalIdentifier: `${spec.identifier}_external`,
    additionalIdentifiers: [],
    externalName: capitalize(spec.identifier.replace(/_/g, ' ')),
    surface: 'test-surface',
    partnersWebIdentifier: spec.identifier,
    schema: BaseSchema as ZodSchemaType<TConfiguration>,
    registrationLimit: blocks.extensions.defaultRegistrationLimit,
    transform: spec.transformLocalToRemote,
    reverseTransform: spec.transformRemoteToLocal,
    experience: spec.experience ?? 'extension',
    uidStrategy: spec.uidStrategy ?? (spec.experience === 'configuration' ? 'single' : 'uuid'),
    getDevSessionUpdateMessages: spec.getDevSessionUpdateMessages,
    clientSteps: spec.clientSteps,
  }
  const merged = {...defaults, ...spec}

  return {
    ...merged,
    contributeToAppConfigurationSchema: (appConfigSchema: ZodSchemaType<unknown>) => {
      const isConfig = isAppConfigSpecification(merged)
      const hasSchema = merged.schema._def.shape !== undefined
      // This filters out webhook subscription specifications from contributing to the app configuration schema
      const hasSingleUidStrategy = merged.uidStrategy === 'single'

      const canContribute = isConfig && hasSchema && hasSingleUidStrategy
      if (!canContribute) {
        // no change
        return appConfigSchema
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return (appConfigSchema as any).merge(merged.schema)
    },
    parseConfigurationObject: (configurationObject: unknown) => {
      const parseResult = merged.schema.safeParse(configurationObject)
      if (!parseResult.success) {
        return {
          state: 'error',
          data: undefined,
          errors: parseResult.error.errors,
        }
      }
      return {
        state: 'ok',
        data: parseResult.data,
        errors: undefined,
      }
    },
  }
}

/**
 * Create a new app config extension spec. This factory method for creating app config extensions is created for two
 * reasons:
 *   - schema needs to be casted to ZodSchemaType<TConfiguration>
 *   - App config extensions have default transform and reverseTransform functions

 */
export function createConfigExtensionSpecification<TConfiguration extends BaseConfigType = BaseConfigType>(spec: {
  identifier: string
  schema: ZodSchemaType<TConfiguration>
  clientSteps?: ClientSteps
  appModuleFeatures?: (config?: TConfiguration) => ExtensionFeature[]
  transformConfig: TransformationConfig | CustomTransformationConfig
  uidStrategy?: UidStrategy
  expandConfig?: ExtensionSpecification<TConfiguration>['expandConfig']
  getIdentity?: ExtensionSpecification<TConfiguration>['getIdentity']
  getTarget?: ExtensionSpecification<TConfiguration>['getTarget']
  getDevSessionUpdateMessages?: (config: TConfiguration, context: DevSessionUpdateContext) => Promise<string[]>
  patchWithAppDevURLs?: (config: TConfiguration, urls: ApplicationURLs) => void
}): ExtensionSpecification<TConfiguration> {
  const appModuleFeatures = spec.appModuleFeatures ?? (() => [])
  return createExtensionSpecification({
    identifier: spec.identifier,
    // This casting is required because `name` and `type` are mandatory for the existing extension spec configurations,
    // however, app config extensions config content is parsed from the `shopify.app.toml`
    schema: spec.schema,
    appModuleFeatures,
    transformLocalToRemote: resolveAppConfigTransform(spec.transformConfig),
    transformRemoteToLocal: resolveReverseAppConfigTransform(spec.schema, spec.transformConfig),
    experience: 'configuration',
    uidStrategy: spec.uidStrategy ?? 'single',
    expandConfig: spec.expandConfig,
    getIdentity: spec.getIdentity,
    getTarget: spec.getTarget,
    clientSteps: spec.clientSteps,
    getDevSessionUpdateMessages: spec.getDevSessionUpdateMessages,
    patchWithAppDevURLs: spec.patchWithAppDevURLs,
  })
}

export function createContractBasedModuleSpecification<TConfiguration extends BaseConfigType = BaseConfigType>(
  spec: Pick<
    CreateExtensionSpecType<TConfiguration>,
    | 'identifier'
    | 'appModuleFeatures'
    | 'appRelativeUrlFields'
    | 'uidStrategy'
    | 'clientSteps'
    | 'experience'
    | 'transformRemoteToLocal'
    | 'devSessionWatchConfig'
  >,
) {
  const appRelativeUrlFields = spec.appRelativeUrlFields

  return createExtensionSpecification({
    identifier: spec.identifier,
    schema: zod.any({}) as unknown as ZodSchemaType<TConfiguration>,
    appModuleFeatures: spec.appModuleFeatures,
    experience: spec.experience,
    clientSteps: spec.clientSteps,
    uidStrategy: spec.uidStrategy,
    transformRemoteToLocal: spec.transformRemoteToLocal,
    devSessionWatchConfig: spec.devSessionWatchConfig,
    appRelativeUrlFields,
    patchWithAppDevURLs: appRelativeUrlFields?.length
      ? (config, urls) => {
          patchAppRelativeUrls(
            capitalize(spec.identifier.replace(/_/g, ' ')),
            appRelativeUrlFields,
            config,
            urls.applicationUrl,
          )
        }
      : undefined,
    deployConfig: async (config, directory, _apiKey, _moduleId, context) => {
      // configWithoutFirstClassFields returns a fresh object, so patching it in place cannot affect the caller.
      let parsedConfig = configWithoutFirstClassFields(config)
      if (appRelativeUrlFields?.length) {
        const applicationUrl = context?.appConfiguration?.application_url
        const appUrl = typeof applicationUrl === 'string' ? applicationUrl : undefined
        patchAppRelativeUrls(capitalize(spec.identifier.replace(/_/g, ' ')), appRelativeUrlFields, parsedConfig, appUrl)
      }
      if (spec.appModuleFeatures().includes('localization')) {
        const localization = await loadLocalesConfig(directory, spec.identifier)
        parsedConfig = {...parsedConfig, localization}
      }
      return parsedConfig
    },
  })
}

function resolveAppConfigTransform(transformConfig: TransformationConfig | CustomTransformationConfig) {
  if (Object.keys(transformConfig).includes('forward')) {
    return (transformConfig as CustomTransformationConfig).forward!
  } else {
    return (content: object) => appConfigTransform(content, transformConfig)
  }
}

function resolveReverseAppConfigTransform<T>(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  schema: zod.ZodType<T, any, any>,
  transformConfig?: TransformationConfig | CustomTransformationConfig,
) {
  if (!transformConfig)
    return (content: object) => defaultAppConfigReverseTransform(schema, content as Record<string, unknown>)

  if (Object.keys(transformConfig).includes('reverse')) {
    return (transformConfig as CustomTransformationConfig).reverse!
  } else {
    return (content: object) => appConfigTransform(content, transformConfig, true)
  }
}

/**
 * Given an object:
 * ```json
 * { source: { fieldSourceA: 'valueA' } }
 * ```
 *  and a transform config content like this:
 * ```json
 * { 'target.fieldTargetA': 'source.fieldSourceA'}
 * ```
 * the method returns the following object:
 * ```json
 * { source: { fieldTargetA: 'valueA' } }
 * ```
 * The transformation can be applied in both ways depending on the reverse parameter
 *
 * @param content - The objet to be transformed
 * @param config - The transformation config
 * @param reverse - If true, the transformation will be applied in reverse
 *
 * @returns the transformed object
 */

export function appConfigTransform(
  content: object,
  config: TransformationConfig | CustomTransformationConfig,
  reverse = false,
): object {
  const transformedContent = {}

  for (const [mappedPath, objectPath] of Object.entries(config)) {
    const originPath = reverse ? mappedPath : objectPath
    const targetPath = reverse ? objectPath : mappedPath
    const sourceValue = getPathValue(content, originPath)
    if (sourceValue !== undefined) setPathValue(transformedContent, targetPath, sourceValue)
  }

  return transformedContent
}

/**
 * Nest the content inside the first level objects expected by the local schema.
 * ```json
 * {
 *  embedded = true
 * }
 * ```
 * will be nested after applying the proper schema:
 * ```json
 * {
 *   pos: {
 *    embedded = true
 *   }
 * }
 * ```
 * @param content - The objet to be nested
 *
 * @returns The nested object
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function defaultAppConfigReverseTransform<T>(schema: zod.ZodType<T, any, any>, content: Record<string, unknown>) {
  return Object.keys(schema._def.shape()).reduce((result: Record<string, unknown>, key: string) => {
    let innerSchema = schema._def.shape()[key]
    if (innerSchema instanceof zod.ZodOptional) {
      innerSchema = innerSchema._def.innerType
    }
    if (innerSchema instanceof zod.ZodObject) {
      result[key] = defaultAppConfigReverseTransform(innerSchema, content)
    } else {
      if (content[key] !== undefined) result[key] = content[key]

      delete content[key]
    }
    return result
  }, {})
}

/**
 * Remove the first class fields from the config.
 *
 * These are the fields that are not part of the specific extension contract, but are added automatically to all modules tomls.
 * So it must be cleaned before validation or deployment.
 * (this was initially done automatically by zod, but is not supported by JSON Schema & contracts)
 *
 * @param config - The config to remove the first class fields from
 *
 * @returns The config without the first class fields
 */
export function configWithoutFirstClassFields(config: JsonMapType): JsonMapType {
  const {type, handle, uid, path, extensions, ...configWithoutFirstClassFields} = config
  return configWithoutFirstClassFields
}
