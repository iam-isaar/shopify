import {
  createIntentsTypeDefinition,
  createToolsTypeDefinition,
  findExplicitTsConfigFiles,
  findAllImportedFiles,
  getGeneratedTypesHelperImportPath,
} from './type-generation.js'
import * as fs from '@shopify/cli-kit/node/fs'
import {AbortError} from '@shopify/cli-kit/node/error'
import {inTemporaryDirectory, mkdir, writeFile} from '@shopify/cli-kit/node/fs'
import {joinPath, normalizePath} from '@shopify/cli-kit/node/path'
import {describe, expect, test, vi} from 'vitest'

const adminGeneratedTypesHelperImportPath = '@shopify/ui-extensions/admin'

describe('getGeneratedTypesHelperImportPath', () => {
  test('returns the surface package for generated helper types', () => {
    expect(getGeneratedTypesHelperImportPath(['admin.app.intent.render'])).toBe('@shopify/ui-extensions/admin')
    expect(getGeneratedTypesHelperImportPath(['purchase.checkout.block.render'])).toBe(
      '@shopify/ui-extensions/checkout',
    )
    expect(getGeneratedTypesHelperImportPath(['pos.home.tile.render'])).toBe('@shopify/ui-extensions/point-of-sale')
    expect(getGeneratedTypesHelperImportPath(['customer-account.order-status.block.render'])).toBe(
      '@shopify/ui-extensions/customer-account',
    )
  })
})

describe('findAllImportedFiles', () => {
  test('ignores commented-out imports', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const entryPath = joinPath(tmpDir, 'index.ts')
      const commentedPath = joinPath(tmpDir, 'commented.ts')

      await writeFile(
        entryPath,
        `
          // import './commented.ts'
          /*
            import './commented.ts'
          */
        `,
      )
      await writeFile(commentedPath, `export const commented = true`)

      const importedFiles = (await findAllImportedFiles(entryPath)).map((file) => normalizePath(file))

      expect(importedFiles).not.toContain(normalizePath(commentedPath))
    })
  })

  test('does not follow type-only imports and exports', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const entryPath = joinPath(tmpDir, 'index.ts')
      const valuePath = joinPath(tmpDir, 'value.ts')
      const valueNestedPath = joinPath(tmpDir, 'value-nested.ts')
      const mixedValuePath = joinPath(tmpDir, 'mixed-value.ts')
      const mixedExportPath = joinPath(tmpDir, 'mixed-export.ts')
      const typePath = joinPath(tmpDir, 'types.ts')
      const typeNestedPath = joinPath(tmpDir, 'type-nested.ts')
      const exportedTypePath = joinPath(tmpDir, 'exported-types.ts')
      const exportedTypeNestedPath = joinPath(tmpDir, 'exported-type-nested.ts')
      const emptyImportPath = joinPath(tmpDir, 'empty-import.ts')
      const emptyImportNestedPath = joinPath(tmpDir, 'empty-import-nested.ts')
      const emptyExportPath = joinPath(tmpDir, 'empty-export.ts')
      const emptyExportNestedPath = joinPath(tmpDir, 'empty-export-nested.ts')

      await writeFile(
        entryPath,
        `
          import './value.ts'
          import MixedValue, { type MixedType } from './mixed-value.ts'
          import {} from './empty-import.ts'
          import type { TypeOnly } from './types.ts'
          export { mixedValue, type MixedExportType } from './mixed-export.ts'
          export {} from './empty-export.ts'
          export type { ExportedTypeOnly } from './exported-types.ts'
        `,
      )
      await writeFile(valuePath, `import './value-nested.ts'`)
      await writeFile(valueNestedPath, `export const valueNested = true`)
      await writeFile(mixedValuePath, `export default true; export type MixedType = string`)
      await writeFile(mixedExportPath, `export const mixedValue = true; export type MixedExportType = string`)
      await writeFile(typePath, `import './type-nested.ts'; export type TypeOnly = string`)
      await writeFile(typeNestedPath, `export const typeNested = true`)
      await writeFile(exportedTypePath, `import './exported-type-nested.ts'; export type ExportedTypeOnly = string`)
      await writeFile(exportedTypeNestedPath, `export const exportedTypeNested = true`)
      await writeFile(emptyImportPath, `import './empty-import-nested.ts'`)
      await writeFile(emptyImportNestedPath, `export const emptyImportNested = true`)
      await writeFile(emptyExportPath, `import './empty-export-nested.ts'`)
      await writeFile(emptyExportNestedPath, `export const emptyExportNested = true`)

      const importedFiles = (await findAllImportedFiles(entryPath)).map((file) => normalizePath(file))

      expect(importedFiles).toContain(normalizePath(valuePath))
      expect(importedFiles).toContain(normalizePath(valueNestedPath))
      expect(importedFiles).toContain(normalizePath(mixedValuePath))
      expect(importedFiles).toContain(normalizePath(mixedExportPath))
      expect(importedFiles).toContain(normalizePath(emptyImportPath))
      expect(importedFiles).toContain(normalizePath(emptyImportNestedPath))
      expect(importedFiles).toContain(normalizePath(emptyExportPath))
      expect(importedFiles).toContain(normalizePath(emptyExportNestedPath))
      expect(importedFiles).not.toContain(normalizePath(typePath))
      expect(importedFiles).not.toContain(normalizePath(typeNestedPath))
      expect(importedFiles).not.toContain(normalizePath(exportedTypePath))
      expect(importedFiles).not.toContain(normalizePath(exportedTypeNestedPath))
    })
  })

  test('includes imports outside the boundary directory without recursively scanning them', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const extensionDir = joinPath(tmpDir, 'extensions', 'extension')
      const srcDir = joinPath(extensionDir, 'src')
      const sharedDir = joinPath(tmpDir, 'shared')

      await mkdir(extensionDir)
      await mkdir(srcDir)
      await mkdir(sharedDir)

      const entryPath = joinPath(srcDir, 'index.ts')
      const localPath = joinPath(srcDir, 'local.ts')
      const nestedPath = joinPath(srcDir, 'nested.ts')
      const externalPath = joinPath(sharedDir, 'utils.ts')
      const externalNestedPath = joinPath(sharedDir, 'secret.ts')

      await writeFile(
        entryPath,
        `
          import './local.ts'
          import '../../../shared/utils.ts'
        `,
      )
      await writeFile(localPath, `import './nested.ts'`)
      await writeFile(nestedPath, `export const nested = true`)
      await writeFile(externalPath, `import './secret.ts'`)
      await writeFile(externalNestedPath, `export const secret = true`)

      const importedFiles = (await findAllImportedFiles(entryPath, {boundaryDirectory: extensionDir})).map((file) =>
        normalizePath(file),
      )

      expect(importedFiles).toContain(normalizePath(localPath))
      expect(importedFiles).toContain(normalizePath(nestedPath))
      expect(importedFiles).toContain(normalizePath(externalPath))
      expect(importedFiles).not.toContain(normalizePath(externalNestedPath))
    })
  })

  test('recursively scans imports outside the boundary directory when explicitly included by tsconfig', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const extensionDir = joinPath(tmpDir, 'extensions', 'extension')
      const srcDir = joinPath(extensionDir, 'src')
      const sharedDir = joinPath(tmpDir, 'shared')

      await mkdir(extensionDir)
      await mkdir(srcDir)
      await mkdir(sharedDir)

      const entryPath = joinPath(srcDir, 'index.ts')
      const localPath = joinPath(srcDir, 'local.ts')
      const externalPath = joinPath(sharedDir, 'utils.ts')
      const externalNestedPath = joinPath(sharedDir, 'secret.ts')

      await writeFile(
        joinPath(tmpDir, 'tsconfig.json'),
        JSON.stringify({
          include: ['extensions/extension/src/**/*', 'shared/**/*'],
        }),
      )
      await writeFile(
        entryPath,
        `
          import './local.ts'
          import '../../../shared/utils.ts'
        `,
      )
      await writeFile(localPath, `export const local = true`)
      await writeFile(externalPath, `import './secret.ts'`)
      await writeFile(externalNestedPath, `export const secret = true`)

      const allowedFiles = await findExplicitTsConfigFiles(entryPath, extensionDir)
      const importedFiles = (
        await findAllImportedFiles(entryPath, {
          boundaryDirectory: extensionDir,
          allowedFiles,
          alwaysAllowedFiles: new Set([entryPath]),
        })
      ).map((file) => normalizePath(file))

      expect(allowedFiles).toContain(normalizePath(externalPath))
      expect(importedFiles).toContain(normalizePath(localPath))
      expect(importedFiles).toContain(normalizePath(externalPath))
      expect(importedFiles).toContain(normalizePath(externalNestedPath))
    })
  })

  test('only follows files from an explicit tsconfig include list when provided', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const srcDir = joinPath(tmpDir, 'src')
      const excludedDir = joinPath(tmpDir, 'excluded')

      await mkdir(srcDir)
      await mkdir(excludedDir)

      const entryPath = joinPath(srcDir, 'index.ts')
      const includedPath = joinPath(srcDir, 'included.ts')
      const includedNestedPath = joinPath(srcDir, 'included-nested.ts')
      const excludedPath = joinPath(excludedDir, 'excluded.ts')
      const excludedNestedPath = joinPath(excludedDir, 'excluded-nested.ts')

      await writeFile(
        joinPath(tmpDir, 'tsconfig.json'),
        JSON.stringify({
          include: ['src/**/*'],
        }),
      )
      await writeFile(
        entryPath,
        `
          import './included.ts'
          import '../excluded/excluded.ts'
        `,
      )
      await writeFile(includedPath, `import './included-nested.ts'`)
      await writeFile(includedNestedPath, `export const includedNested = true`)
      await writeFile(excludedPath, `import './excluded-nested.ts'`)
      await writeFile(excludedNestedPath, `export const excludedNested = true`)

      const allowedFiles = await findExplicitTsConfigFiles(entryPath, tmpDir)
      const importedFiles = (
        await findAllImportedFiles(entryPath, {
          boundaryDirectory: tmpDir,
          allowedFiles,
          alwaysAllowedFiles: new Set([entryPath]),
        })
      ).map((file) => normalizePath(file))

      expect(importedFiles).toContain(normalizePath(includedPath))
      expect(importedFiles).toContain(normalizePath(includedNestedPath))
      expect(importedFiles).not.toContain(normalizePath(excludedPath))
      expect(importedFiles).not.toContain(normalizePath(excludedNestedPath))
    })
  })

  test('uses explicit tsconfig include inherited from an extended config', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const extensionDir = joinPath(tmpDir, 'extensions', 'extension')
      const srcDir = joinPath(extensionDir, 'src')
      const excludedDir = joinPath(extensionDir, 'excluded')

      await mkdir(extensionDir)
      await mkdir(srcDir)
      await mkdir(excludedDir)

      const entryPath = joinPath(srcDir, 'index.ts')
      const includedPath = joinPath(srcDir, 'included.ts')
      const excludedPath = joinPath(excludedDir, 'excluded.ts')

      await writeFile(
        joinPath(tmpDir, 'tsconfig.base.json'),
        JSON.stringify({
          include: ['extensions/extension/src/**/*'],
        }),
      )
      await writeFile(
        joinPath(extensionDir, 'tsconfig.json'),
        JSON.stringify({
          extends: '../../tsconfig.base.json',
        }),
      )
      await writeFile(
        entryPath,
        `
          import './included.ts'
          import '../excluded/excluded.ts'
        `,
      )
      await writeFile(includedPath, `export const included = true`)
      await writeFile(excludedPath, `export const excluded = true`)

      const allowedFiles = await findExplicitTsConfigFiles(entryPath, extensionDir)
      const importedFiles = (
        await findAllImportedFiles(entryPath, {
          boundaryDirectory: extensionDir,
          allowedFiles,
          alwaysAllowedFiles: new Set([entryPath]),
        })
      ).map((file) => normalizePath(file))

      expect(allowedFiles).toContain(normalizePath(entryPath))
      expect(importedFiles).toContain(normalizePath(includedPath))
      expect(importedFiles).not.toContain(normalizePath(excludedPath))
    })
  })

  test('does not follow declaration files', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const entryPath = joinPath(tmpDir, 'index.ts')
      const declarationPath = joinPath(tmpDir, 'types.d.ts')
      const nestedPath = joinPath(tmpDir, 'nested.ts')

      await writeFile(entryPath, `import './types.d.ts'`)
      await writeFile(declarationPath, `import './nested.ts'`)
      await writeFile(nestedPath, `export const nested = true`)

      const importedFiles = (await findAllImportedFiles(entryPath, {boundaryDirectory: tmpDir})).map((file) =>
        normalizePath(file),
      )

      expect(importedFiles).not.toContain(normalizePath(declarationPath))
      expect(importedFiles).not.toContain(normalizePath(nestedPath))
    })
  })

  test('does not use a tsconfig allowlist when files and include are implicit', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const entryPath = joinPath(tmpDir, 'index.ts')

      await writeFile(joinPath(tmpDir, 'tsconfig.json'), '{}')
      await writeFile(entryPath, `export const entry = true`)

      await expect(findExplicitTsConfigFiles(entryPath, tmpDir)).resolves.toBeUndefined()
    })
  })

  test('uses cached imports when the same file is scanned more than once', async () => {
    await inTemporaryDirectory(async (tmpDir) => {
      const entryPath = joinPath(tmpDir, 'index.ts')
      const localPath = joinPath(tmpDir, 'local.ts')
      const nestedPath = joinPath(tmpDir, 'nested.ts')

      await writeFile(entryPath, `import './local.ts'`)
      await writeFile(localPath, `import './nested.ts'`)
      await writeFile(nestedPath, `export const nested = true`)

      const readFileSync = vi.spyOn(fs, 'readFileSync')
      const importCache = new Map<string, string[]>()

      await findAllImportedFiles(entryPath, {boundaryDirectory: tmpDir, importCache})
      await findAllImportedFiles(entryPath, {boundaryDirectory: tmpDir, importCache})

      const readCountsByPath = new Map<string, number>()
      for (const [path] of readFileSync.mock.calls) {
        readCountsByPath.set(path, (readCountsByPath.get(path) ?? 0) + 1)
      }

      expect(readCountsByPath.get(entryPath)).toBe(1)
      expect(readCountsByPath.get(localPath)).toBe(1)
      expect(readCountsByPath.get(nestedPath)).toBe(1)
    })
  })
})

describe('createIntentsTypeDefinition', () => {
  test('returns empty string when intents array is empty', async () => {
    // When
    const result = await createIntentsTypeDefinition([], {
      generatedTypesHelperImportPath: adminGeneratedTypesHelperImportPath,
    })

    // Then
    expect(result).toBe('')
  })

  test('generates request and response types for a single intent schema', async () => {
    // Given
    const intents = [
      {
        action: 'create',
        type: 'application/email',
        inputSchema: {
          type: 'object',
          properties: {
            recipient: {type: 'string'},
          },
          required: ['recipient'],
        },
        outputSchema: {
          type: 'object',
          properties: {
            success: {type: 'boolean'},
          },
        },
      },
    ]

    // When
    const result = await createIntentsTypeDefinition(intents, {
      generatedTypesHelperImportPath: adminGeneratedTypesHelperImportPath,
    })

    // Then
    expect(result).toBe(`interface CreateApplicationEmailIntentInput {
  recipient: string;
  [k: string]: unknown;
}

type CreateApplicationEmailIntentValue = unknown
interface CreateApplicationEmailIntentOutput {
  success?: boolean;
  [k: string]: unknown;
}

interface CreateApplicationEmailIntentRequest {
  action: "create";
  type: "application/email";
  data: CreateApplicationEmailIntentInput;
  value?: CreateApplicationEmailIntentValue;
}

type ShopifyGeneratedIntentVariants =
  | import('@shopify/ui-extensions/admin').ShopifyGeneratedIntentVariant<CreateApplicationEmailIntentRequest, CreateApplicationEmailIntentOutput>
`)
  })

  test('supports multiple intents with value schemas', async () => {
    // Given
    const intents = [
      {
        action: 'create',
        type: 'application/email',
        inputSchema: {
          type: 'object',
          properties: {
            recipient: {type: 'string'},
          },
        },
      },
      {
        action: 'edit',
        type: 'shopify/Product',
        valueSchema: {
          type: 'string',
        },
        inputSchema: {
          type: 'object',
          properties: {
            title: {type: 'string'},
          },
        },
        outputSchema: {
          type: 'object',
          properties: {
            id: {type: 'string'},
          },
        },
      },
    ]

    // When
    const result = await createIntentsTypeDefinition(intents, {
      generatedTypesHelperImportPath: adminGeneratedTypesHelperImportPath,
    })

    // Then
    expect(result).toContain('interface CreateApplicationEmailIntentRequest')
    expect(result).toContain('type CreateApplicationEmailIntentOutput = unknown')
    expect(result).toContain('interface EditShopifyProductIntentRequest')
    expect(result).toContain('type EditShopifyProductIntentValue = string')
    expect(result).not.toContain('ShopifyGeneratedIntentsApi')
    expect(result).toContain(
      "import('@shopify/ui-extensions/admin').ShopifyGeneratedIntentVariant<EditShopifyProductIntentRequest, EditShopifyProductIntentOutput>",
    )
  })

  test('throws AbortError when intent action/type pairs are duplicated', async () => {
    // Given
    const intents = [
      {
        action: 'create',
        type: 'application/email',
        inputSchema: {type: 'object'},
      },
      {
        action: 'create',
        type: 'application/email',
        inputSchema: {type: 'object'},
      },
    ]

    // When & Then
    await expect(
      createIntentsTypeDefinition(intents, {generatedTypesHelperImportPath: adminGeneratedTypesHelperImportPath}),
    ).rejects.toThrow(
      new AbortError(
        'Intent "create:application/email" is defined multiple times. Intents must be unique within a target.',
      ),
    )
  })
})

describe('createToolsTypeDefinition', () => {
  test('returns empty string when tools array is empty', async () => {
    // When
    const result = await createToolsTypeDefinition([])

    // Then
    expect(result).toBe('')
  })

  test('generates type definitions for a single tool with input and output schemas', async () => {
    // Given
    const tools = [
      {
        name: 'get_product',
        description: 'Gets a product by ID',
        inputSchema: {
          type: 'object',
          properties: {
            productId: {type: 'string'},
          },
          required: ['productId'],
        },
        outputSchema: {
          type: 'object',
          properties: {
            title: {type: 'string'},
            price: {type: 'number'},
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface GetProductInput {
  productId: string;
  [k: string]: unknown;
}

interface GetProductOutput {
  title?: string;
  price?: number;
  [k: string]: unknown;
}

interface ShopifyTools {
  /**
   * Gets a product by ID
   */
  register(name: 'get_product', handler: (input: GetProductInput) => GetProductOutput | Promise<GetProductOutput>): () => void;
}
`)
  })

  test('generates unknown type when outputSchema is not provided', async () => {
    // Given
    const tools = [
      {
        name: 'simple_action',
        description: 'A simple action',
        inputSchema: {
          type: 'object',
          properties: {
            data: {type: 'string'},
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface SimpleActionInput {
  data?: string;
  [k: string]: unknown;
}

type SimpleActionOutput = unknown
interface ShopifyTools {
  /**
   * A simple action
   */
  register(name: 'simple_action', handler: (input: SimpleActionInput) => SimpleActionOutput | Promise<SimpleActionOutput>): () => void;
}
`)
  })

  test('generates type definitions for multiple tools', async () => {
    // Given
    const tools = [
      {
        name: 'tool_one',
        description: 'First tool',
        inputSchema: {
          type: 'object',
          properties: {
            arg1: {type: 'string'},
          },
        },
        outputSchema: {
          type: 'object',
          properties: {
            result1: {type: 'string'},
          },
        },
      },
      {
        name: 'tool_two',
        description: 'Second tool',
        inputSchema: {
          type: 'object',
          properties: {
            arg2: {type: 'number'},
          },
        },
        outputSchema: {
          type: 'object',
          properties: {
            result2: {type: 'boolean'},
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface ToolOneInput {
  arg1?: string;
  [k: string]: unknown;
}

interface ToolOneOutput {
  result1?: string;
  [k: string]: unknown;
}

interface ToolTwoInput {
  arg2?: number;
  [k: string]: unknown;
}

interface ToolTwoOutput {
  result2?: boolean;
  [k: string]: unknown;
}

interface ShopifyTools {
  /**
   * First tool
   */
  register(name: 'tool_one', handler: (input: ToolOneInput) => ToolOneOutput | Promise<ToolOneOutput>): () => void;
  /**
   * Second tool
   */
  register(name: 'tool_two', handler: (input: ToolTwoInput) => ToolTwoOutput | Promise<ToolTwoOutput>): () => void;
}
`)
  })

  test('throws AbortError when tool names are duplicated', async () => {
    // Given
    const tools = [
      {
        name: 'duplicate_tool',
        description: 'First instance',
        inputSchema: {type: 'object'},
      },
      {
        name: 'duplicate_tool',
        description: 'Second instance',
        inputSchema: {type: 'object'},
      },
    ]

    // When & Then
    await expect(createToolsTypeDefinition(tools)).rejects.toThrow(
      new AbortError(
        'Tool name "duplicate_tool" is defined multiple times. Tool names must be unique within a tools file.',
      ),
    )
  })

  test('escapes closing comment markers in descriptions', async () => {
    // Given
    const tools = [
      {
        name: 'tool_with_special_desc',
        description: 'This description contains */ which could break comments',
        inputSchema: {type: 'object'},
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface ToolWithSpecialDescInput {
  [k: string]: unknown;
}

type ToolWithSpecialDescOutput = unknown
interface ShopifyTools {
  /**
   * This description contains *\\/ which could break comments
   */
  register(name: 'tool_with_special_desc', handler: (input: ToolWithSpecialDescInput) => ToolWithSpecialDescOutput | Promise<ToolWithSpecialDescOutput>): () => void;
}
`)
  })

  test('handles multi-line descriptions', async () => {
    // Given
    const tools = [
      {
        name: 'documented_tool',
        description: 'Line one\nLine two\nLine three',
        inputSchema: {type: 'object'},
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface DocumentedToolInput {
  [k: string]: unknown;
}

type DocumentedToolOutput = unknown
interface ShopifyTools {
  /**
   * Line one
   * Line two
   * Line three
   */
  register(name: 'documented_tool', handler: (input: DocumentedToolInput) => DocumentedToolOutput | Promise<DocumentedToolOutput>): () => void;
}
`)
  })

  test('converts multi-segment snake_case tool names to PascalCase type names', async () => {
    // Given
    const tools = [
      {
        name: 'my_snake_case_tool',
        description: 'A tool with snake case name',
        inputSchema: {type: 'object'},
        outputSchema: {type: 'object'},
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface MySnakeCaseToolInput {
  [k: string]: unknown;
}

interface MySnakeCaseToolOutput {
  [k: string]: unknown;
}

interface ShopifyTools {
  /**
   * A tool with snake case name
   */
  register(name: 'my_snake_case_tool', handler: (input: MySnakeCaseToolInput) => MySnakeCaseToolOutput | Promise<MySnakeCaseToolOutput>): () => void;
}
`)
  })

  test('handles complex nested schemas', async () => {
    // Given
    const tools = [
      {
        name: 'complex_tool',
        description: 'A tool with nested schema',
        inputSchema: {
          type: 'object',
          properties: {
            user: {
              type: 'object',
              properties: {
                name: {type: 'string'},
                email: {type: 'string'},
              },
              required: ['name'],
            },
            tags: {
              type: 'array',
              items: {type: 'string'},
            },
          },
          required: ['user'],
        },
        outputSchema: {
          type: 'object',
          properties: {
            success: {type: 'boolean'},
            data: {
              type: 'object',
              properties: {
                id: {type: 'number'},
              },
            },
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface ComplexToolInput {
  user: {
    name: string;
    email?: string;
    [k: string]: unknown;
  };
  tags?: string[];
  [k: string]: unknown;
}

interface ComplexToolOutput {
  success?: boolean;
  data?: {
    id?: number;
    [k: string]: unknown;
  };
  [k: string]: unknown;
}

interface ShopifyTools {
  /**
   * A tool with nested schema
   */
  register(name: 'complex_tool', handler: (input: ComplexToolInput) => ComplexToolOutput | Promise<ComplexToolOutput>): () => void;
}
`)
  })

  test('preserves tool name exactly in register method', async () => {
    // Given
    const tools = [
      {
        name: 'get-product-info',
        description: 'Gets product info',
        inputSchema: {type: 'object'},
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toBe(`interface GetProductInfoInput {
  [k: string]: unknown;
}

type GetProductInfoOutput = unknown
interface ShopifyTools {
  /**
   * Gets product info
   */
  register(name: 'get-product-info', handler: (input: GetProductInfoInput) => GetProductInfoOutput | Promise<GetProductInfoOutput>): () => void;
}
`)
  })

  test('renames types generated from schemas with titles to the requested generated name', async () => {
    // Given
    const tools = [
      {
        name: 'expected_tool',
        description: 'A tool with schema titles',
        inputSchema: {
          title: 'SchemaTitleInput',
          type: 'object',
          properties: {
            id: {type: 'string'},
          },
        },
        outputSchema: {
          title: 'SchemaTitleOutput',
          type: 'object',
          properties: {
            success: {type: 'boolean'},
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).toContain('interface ExpectedToolInput')
    expect(result).toContain('interface ExpectedToolOutput')
    expect(result).not.toContain('interface SchemaTitleInput')
    expect(result).not.toContain('interface SchemaTitleOutput')
  })

  test('does not include export declarations in the output', async () => {
    // Given
    // We need to ensure export declarations are stripped from the output since these types
    // are embedded inside a declare module block.
    const tools = [
      {
        name: 'exportable_tool',
        description: 'A tool that might generate exports',
        inputSchema: {
          type: 'object',
          properties: {
            id: {type: 'string'},
          },
        },
        outputSchema: {
          type: 'object',
          properties: {
            result: {type: 'boolean'},
          },
        },
      },
    ]

    // When
    const result = await createToolsTypeDefinition(tools)

    // Then
    expect(result).not.toMatch(/\bexport\b/)
  })
})
