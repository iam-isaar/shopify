import Build from './commands/app/build.js'
import BulkCancel from './commands/app/bulk/cancel.js'
import BulkStatus from './commands/app/bulk/status.js'
import ConfigLink from './commands/app/config/link.js'
import ConfigUse from './commands/app/config/use.js'
import ConfigPull from './commands/app/config/pull.js'
import DemoWatcher from './commands/app/demo/watcher.js'
import Deploy from './commands/app/deploy.js'
import Dev from './commands/app/dev.js'
import SecurityCheck from './commands/app/security/check.js'
import SecurityClean from './commands/app/security/clean.js'
import SecurityInstructions from './commands/app/security/instructions.js'
import SecurityRecord from './commands/app/security/record.js'
import SecurityReview from './commands/app/security/review.js'
import Logs from './commands/app/logs.js'
import LogsNext from './commands/app/logs-next.js'
import EnvPull from './commands/app/env/pull.js'
import EnvShow from './commands/app/env/show.js'
import BulkExecute from './commands/app/bulk/execute.js'
import Execute from './commands/app/execute.js'
import AppGraphiQL from './commands/app/graphiql.js'
import FunctionBuild from './commands/app/function/build.js'
import FunctionReplay from './commands/app/function/replay.js'
import FunctionRun from './commands/app/function/run.js'
import FetchSchema from './commands/app/function/schema.js'
import FunctionTypegen from './commands/app/function/typegen.js'
import AppGenerateExtension from './commands/app/generate/extension.js'
import ImportExtensions from './commands/app/import-extensions.js'
import ImportDashboardExtensions from './commands/app/import/dashboard-extensions.js'
import AppInfo from './commands/app/info.js'
import Init from './commands/app/init.js'
import ConfigValidate from './commands/app/config/validate.js'
import Release from './commands/app/release.js'
import SubscriptionMigrationsCancel from './commands/app/subscription-migrations/cancel.js'
import SubscriptionMigrationsList from './commands/app/subscription-migrations/list.js'
import SubscriptionMigrationsSchedule from './commands/app/subscription-migrations/schedule.js'
import SubscriptionMigrationsStatus from './commands/app/subscription-migrations/status.js'
import SubscriptionMigrationsUnschedule from './commands/app/subscription-migrations/unschedule.js'
import VersionsList from './commands/app/versions/list.js'
import WebhookTrigger from './commands/app/webhook/trigger.js'
import gatherPublicMetadata from './hooks/public_metadata.js'
import gatherSensitiveMetadata from './hooks/sensitive_metadata.js'
import AppLinkedCommand from './utilities/app-linked-command.js'
import DevClean from './commands/app/dev/clean.js'
import AppUnlinkedCommand from './utilities/app-unlinked-command.js'
import FunctionInfo from './commands/app/function/info.js'
import ImportChannelConfig from './commands/app/import/channel-config.js'
import ImportCustomDataDefinitions from './commands/app/import/custom-data-definitions.js'
import ImportCustomDataDefinitionsDeprecated from './commands/app/import-custom-data-definitions.js'
import OrganizationList from './commands/organization/list.js'
import BaseCommand from '@shopify/cli-kit/node/base-command'

/**
 * App commands should extend AppLinkedCommand or AppUnlinkedCommand.
 * Organization commands extend BaseCommand directly.
 */
export const commands: {[key: string]: typeof AppLinkedCommand | typeof AppUnlinkedCommand | typeof BaseCommand} = {
  'app:build': Build,
  'app:bulk:cancel': BulkCancel,
  'app:bulk:status': BulkStatus,
  'app:deploy': Deploy,
  'app:dev': Dev,
  'app:dev:clean': DevClean,
  'app:security:check': SecurityCheck,
  'app:security:clean': SecurityClean,
  'app:security:instructions': SecurityInstructions,
  'app:security:record': SecurityRecord,
  'app:security:review': SecurityReview,
  'app:logs': Logs,
  'app:logs-next': LogsNext,
  'app:import:channel-config': ImportChannelConfig,
  'app:import:custom-data-definitions': ImportCustomDataDefinitions,
  'app:import:dashboard-extensions': ImportDashboardExtensions,
  // Deprecated paths, kept registered (and hidden) so existing scripts keep working.
  'app:import-custom-data-definitions': ImportCustomDataDefinitionsDeprecated,
  'app:import-extensions': ImportExtensions,
  'app:info': AppInfo,
  'app:init': Init,
  'app:config:validate': ConfigValidate,
  'app:release': Release,
  'app:subscription-migrations:cancel': SubscriptionMigrationsCancel,
  'app:subscription-migrations:list': SubscriptionMigrationsList,
  'app:subscription-migrations:schedule': SubscriptionMigrationsSchedule,
  'app:subscription-migrations:status': SubscriptionMigrationsStatus,
  'app:subscription-migrations:unschedule': SubscriptionMigrationsUnschedule,
  'app:config:link': ConfigLink,
  'app:config:use': ConfigUse,
  'app:config:pull': ConfigPull,
  'app:env:pull': EnvPull,
  'app:env:show': EnvShow,
  'app:execute': Execute,
  'app:graphiql': AppGraphiQL,
  'app:bulk:execute': BulkExecute,
  'app:function:build': FunctionBuild,
  'app:function:replay': FunctionReplay,
  'app:function:run': FunctionRun,
  'app:function:info': FunctionInfo,
  'app:function:schema': FetchSchema,
  'app:function:typegen': FunctionTypegen,
  'app:generate:extension': AppGenerateExtension,
  'app:versions:list': VersionsList,
  'app:webhook:trigger': WebhookTrigger,
  'demo:watcher': DemoWatcher,
  'organization:list': OrganizationList,
}

export const AppSensitiveMetadataHook = gatherSensitiveMetadata
export const AppPublicMetadataHook = gatherPublicMetadata
