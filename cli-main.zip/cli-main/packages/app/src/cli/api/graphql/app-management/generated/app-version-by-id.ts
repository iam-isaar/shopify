/* eslint-disable @typescript-eslint/consistent-type-definitions */
import * as Types from './types.js'
import {JsonMapType} from '@shopify/cli-kit/node/toml'

import {TypedDocumentNode as DocumentNode} from '@graphql-typed-document-node/core'

export type AppVersionByIdQueryVariables = Types.Exact<{
  versionId: Types.Scalars['ID']['input']
}>

export type AppVersionByIdQuery = {
  version: {
    id: string
    metadata: {message?: string | null; versionTag?: string | null}
    appModules: {
      uuid: string
      userIdentifier: string
      handle: string
      config: JsonMapType
      target?: string | null
      specification: {
        identifier: string
        externalIdentifier: string
        name: string
        experience: string
        managementExperience: string
      }
    }[]
  }
}

export type VersionInfoFragment = {
  id: string
  metadata: {message?: string | null; versionTag?: string | null}
  appModules: {
    uuid: string
    userIdentifier: string
    handle: string
    config: JsonMapType
    target?: string | null
    specification: {
      identifier: string
      externalIdentifier: string
      name: string
      experience: string
      managementExperience: string
    }
  }[]
}

export const VersionInfoFragmentDoc = {
  kind: 'Document',
  definitions: [
    {
      kind: 'FragmentDefinition',
      name: {kind: 'Name', value: 'VersionInfo'},
      typeCondition: {kind: 'NamedType', name: {kind: 'Name', value: 'Version'}},
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {kind: 'Field', name: {kind: 'Name', value: 'id'}},
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'metadata'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                {kind: 'Field', name: {kind: 'Name', value: 'message'}},
                {kind: 'Field', name: {kind: 'Name', value: 'versionTag'}},
              ],
            },
          },
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'appModules'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [{kind: 'FragmentSpread', name: {kind: 'Name', value: 'ReleasedAppModule'}}],
            },
          },
        ],
      },
    },
    {
      kind: 'FragmentDefinition',
      name: {kind: 'Name', value: 'ReleasedAppModule'},
      typeCondition: {kind: 'NamedType', name: {kind: 'Name', value: 'AppModule'}},
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {kind: 'Field', name: {kind: 'Name', value: 'uuid'}},
          {kind: 'Field', name: {kind: 'Name', value: 'userIdentifier'}},
          {kind: 'Field', name: {kind: 'Name', value: 'handle'}},
          {kind: 'Field', name: {kind: 'Name', value: 'config'}},
          {kind: 'Field', name: {kind: 'Name', value: 'target'}},
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'specification'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                {kind: 'Field', name: {kind: 'Name', value: 'identifier'}},
                {kind: 'Field', name: {kind: 'Name', value: 'externalIdentifier'}},
                {kind: 'Field', name: {kind: 'Name', value: 'name'}},
                {kind: 'Field', name: {kind: 'Name', value: 'experience'}},
                {kind: 'Field', name: {kind: 'Name', value: 'managementExperience'}},
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<VersionInfoFragment, unknown>
export const AppVersionById = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: {kind: 'Name', value: 'AppVersionById'},
      variableDefinitions: [
        {
          kind: 'VariableDefinition',
          variable: {kind: 'Variable', name: {kind: 'Name', value: 'versionId'}},
          type: {kind: 'NonNullType', type: {kind: 'NamedType', name: {kind: 'Name', value: 'ID'}}},
        },
      ],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'version'},
            arguments: [
              {
                kind: 'Argument',
                name: {kind: 'Name', value: 'id'},
                value: {kind: 'Variable', name: {kind: 'Name', value: 'versionId'}},
              },
            ],
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                {kind: 'FragmentSpread', name: {kind: 'Name', value: 'VersionInfo'}},
                {kind: 'Field', name: {kind: 'Name', value: '__typename'}},
              ],
            },
          },
        ],
      },
    },
    {
      kind: 'FragmentDefinition',
      name: {kind: 'Name', value: 'ReleasedAppModule'},
      typeCondition: {kind: 'NamedType', name: {kind: 'Name', value: 'AppModule'}},
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {kind: 'Field', name: {kind: 'Name', value: 'uuid'}},
          {kind: 'Field', name: {kind: 'Name', value: 'userIdentifier'}},
          {kind: 'Field', name: {kind: 'Name', value: 'handle'}},
          {kind: 'Field', name: {kind: 'Name', value: 'config'}},
          {kind: 'Field', name: {kind: 'Name', value: 'target'}},
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'specification'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                {kind: 'Field', name: {kind: 'Name', value: 'identifier'}},
                {kind: 'Field', name: {kind: 'Name', value: 'externalIdentifier'}},
                {kind: 'Field', name: {kind: 'Name', value: 'name'}},
                {kind: 'Field', name: {kind: 'Name', value: 'experience'}},
                {kind: 'Field', name: {kind: 'Name', value: 'managementExperience'}},
              ],
            },
          },
        ],
      },
    },
    {
      kind: 'FragmentDefinition',
      name: {kind: 'Name', value: 'VersionInfo'},
      typeCondition: {kind: 'NamedType', name: {kind: 'Name', value: 'Version'}},
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {kind: 'Field', name: {kind: 'Name', value: 'id'}},
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'metadata'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                {kind: 'Field', name: {kind: 'Name', value: 'message'}},
                {kind: 'Field', name: {kind: 'Name', value: 'versionTag'}},
              ],
            },
          },
          {
            kind: 'Field',
            name: {kind: 'Name', value: 'appModules'},
            selectionSet: {
              kind: 'SelectionSet',
              selections: [{kind: 'FragmentSpread', name: {kind: 'Name', value: 'ReleasedAppModule'}}],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<AppVersionByIdQuery, AppVersionByIdQueryVariables>
