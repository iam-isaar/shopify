import {buildConfigurationBreakdownMetadata, deployOrReleaseConfirmationPrompt} from './deploy-release.js'
import metadata from '../metadata.js'
import {
  ConfigExtensionIdentifiersBreakdown,
  ExtensionIdentifiersBreakdown,
  buildDashboardBreakdownInfo,
  buildExtensionBreakdownInfo,
} from '../services/context/breakdown-extensions.js'
import {MockInstance, beforeEach, describe, expect, test, vi} from 'vitest'
import * as ui from '@shopify/cli-kit/node/ui'

vi.mock('@shopify/cli-kit/node/context/local')

beforeEach(() => {
  // Mock isTTY to return true so prompts are shown instead of errors in tests
  vi.spyOn(ui, 'isTTY').mockReturnValue(true)
})

describe('deployOrReleaseConfirmationPrompt', () => {
  describe('when release', () => {
    test('and no release no prompt should be displayed and true returned', async () => {
      // Given
      const {extensionIdentifiersBreakdown, configExtensionIdentifiersBreakdown} = buildCompleteBreakdownInfo()
      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt')
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        extensionIdentifiersBreakdown,
        configExtensionIdentifiersBreakdown,
        appTitle,
        release: false,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        confirmed: result,
        configExtensionIdentifiersBreakdown: configExtensionIdentifiersBreakdown!,
      })
      expect(renderConfirmationPromptSpyOn).not.toHaveBeenCalled()
      expect(result).toBe(true)
    })

    test('and no force without any modifications either extension or config should display empty sections', async () => {
      // Given
      const extensionIdentifiersBreakdown = buildEmptyExtensionsBreakdownInfo()
      const configExtensionIdentifiersBreakdown = buildEmptyConfigExtensionsBreakdownInfo()

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        extensionIdentifiersBreakdown,
        configExtensionIdentifiersBreakdown,
        appTitle,
        release: true,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown,
      })
      expect(renderConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Configuration:',
              items: [],
              emptyItemsText: 'No changes',
            },
            {
              header: 'Extensions:',
              items: [],
              emptyItemsText: 'None',
            },
          ],
          dangerPrompt: false,
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force without extensions deleted should display the complete confirmation prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      breakdownInfo.extensionIdentifiersBreakdown.onlyRemote = []

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: true,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown: breakdownInfo.extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown!,
      })
      expect(renderConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Configuration:',
              items: [
                {bullet: '+', item: ['new field name1', {subdued: '(new)'}], color: 'green'},
                {item: ['updating field name1', {subdued: '(updated)'}], color: '#FF8800'},
                'existing field name1',
                {bullet: '-', item: ['deleted field name1', {subdued: '(removed)'}], color: 'red'},
              ],
            },
            {
              header: 'Extensions:',
              items: [
                {bullet: '+', item: ['to create extension (uid: uid-create)', {subdued: '(new)'}], color: 'green'},
                {item: ['to update extension', {subdued: '(updated)'}], color: '#FF8800'},
                'unchanged extension',
                ['from dashboard extension', {subdued: '(from Partner Dashboard)'}],
              ],
            },
          ],
          dangerPrompt: false,
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force with deleted extensions should display the complete danger confirmation prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      breakdownInfo.extensionIdentifiersBreakdown.onlyRemote.push(buildDashboardBreakdownInfo('remote dashboard'))
      breakdownInfo.extensionIdentifiersBreakdown.toCreate.push(buildDashboardBreakdownInfo('to create dashboard'))
      const renderDangerousConfirmationPromptSpyOn = vi
        .spyOn(ui, 'renderDangerousConfirmationPrompt')
        .mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: true,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown: breakdownInfo.extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown!,
      })
      expect(renderDangerousConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Configuration:',
              items: [
                {bullet: '+', item: ['new field name1', {subdued: '(new)'}], color: 'green'},
                {item: ['updating field name1', {subdued: '(updated)'}], color: '#FF8800'},
                'existing field name1',
                {bullet: '-', item: ['deleted field name1', {subdued: '(removed)'}], color: 'red'},
              ],
            },
            {
              header: 'Extensions:',
              helperText: 'Removing extensions can permanently delete app user data',
              items: [
                {bullet: '+', item: ['to create extension (uid: uid-create)', {subdued: '(new)'}], color: 'green'},
                {
                  bullet: '+',
                  item: ['to create dashboard', {subdued: '(new, from Partner Dashboard)'}],
                  color: 'green',
                },
                {item: ['to update extension', {subdued: '(updated)'}], color: '#FF8800'},
                'unchanged extension',
                ['from dashboard extension', {subdued: '(from Partner Dashboard)'}],
                {bullet: '-', item: ['remote extension (uid: uid-remove)', {subdued: '(removed)'}], color: 'red'},
                {bullet: '-', item: ['remote dashboard', {subdued: '(removed, from Partner Dashboard)'}], color: 'red'},
              ],
            },
          ],
          dangerPrompt: true,
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force with deleted extensions and installCount should pass installCount to danger prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      const renderDangerousConfirmationPromptSpyOn = vi
        .spyOn(ui, 'renderDangerousConfirmationPrompt')
        .mockResolvedValue(true)
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: true,
        installCount: 1243,
      })

      // Then
      expect(renderDangerousConfirmationPromptSpyOn).toHaveBeenCalledWith(
        expect.objectContaining({
          warningItem: expect.arrayContaining([{error: '1243'}]),
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force with deleted extensions but installCount 0 should not pass warningItem to danger prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      const renderDangerousConfirmationPromptSpyOn = vi
        .spyOn(ui, 'renderDangerousConfirmationPrompt')
        .mockResolvedValue(true)
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: true,
        installCount: 0,
      })

      // Then
      expect(renderDangerousConfirmationPromptSpyOn).toHaveBeenCalledWith(
        expect.not.objectContaining({
          warningItem: expect.anything(),
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force with deleted extensions but without app title should display the complete confirmation prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = undefined

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        release: true,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown: breakdownInfo.extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown!,
      })
      expect(renderConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Configuration:',
              items: [
                {bullet: '+', item: ['new field name1', {subdued: '(new)'}], color: 'green'},
                {item: ['updating field name1', {subdued: '(updated)'}], color: '#FF8800'},
                'existing field name1',
                {bullet: '-', item: ['deleted field name1', {subdued: '(removed)'}], color: 'red'},
              ],
            },
            {
              header: 'Extensions:',
              items: [
                {bullet: '+', item: ['to create extension (uid: uid-create)', {subdued: '(new)'}], color: 'green'},
                {item: ['to update extension', {subdued: '(updated)'}], color: '#FF8800'},
                'unchanged extension',
                ['from dashboard extension', {subdued: '(from Partner Dashboard)'}],
                {bullet: '-', item: ['remote extension (uid: uid-remove)', {subdued: '(removed)'}], color: 'red'},
              ],
            },
          ],
          dangerPrompt: false,
        }),
      )
      expect(result).toBe(true)
    })

    test('and the configuration extension breakdown is undefined then the config information should not be displayed', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      breakdownInfo.configExtensionIdentifiersBreakdown = undefined

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = undefined

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        release: true,
        showConfig: false,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown: breakdownInfo.extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown!,
      })
      expect(renderConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Extensions:',
              items: [
                {bullet: '+', item: ['to create extension (uid: uid-create)', {subdued: '(new)'}], color: 'green'},
                {item: ['to update extension', {subdued: '(updated)'}], color: '#FF8800'},
                'unchanged extension',
                ['from dashboard extension', {subdued: '(from Partner Dashboard)'}],
                {bullet: '-', item: ['remote extension (uid: uid-remove)', {subdued: '(removed)'}], color: 'red'},
              ],
            },
          ],
          dangerPrompt: false,
        }),
      )
      expect(result).toBe(true)
    })

    test('and no force without config modification should display the no config changes confirmation prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      breakdownInfo.configExtensionIdentifiersBreakdown = buildEmptyConfigExtensionsBreakdownInfo()

      const renderDangerousConfirmationPromptSpyOn = vi
        .spyOn(ui, 'renderDangerousConfirmationPrompt')
        .mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: true,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        extensionIdentifiersBreakdown: breakdownInfo.extensionIdentifiersBreakdown,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown,
      })
      expect(renderDangerousConfirmationPromptSpyOn).toHaveBeenCalledWith(
        renderConfirmationPromptContent({
          appTitle,
          infoTable: [
            {
              header: 'Configuration:',
              items: [],
              emptyItemsText: 'No changes',
            },
            {
              header: 'Extensions:',
              helperText: 'Removing extensions can permanently delete app user data',
              items: [
                {bullet: '+', item: ['to create extension (uid: uid-create)', {subdued: '(new)'}], color: 'green'},
                {item: ['to update extension', {subdued: '(updated)'}], color: '#FF8800'},
                'unchanged extension',
                ['from dashboard extension', {subdued: '(from Partner Dashboard)'}],
                {bullet: '-', item: ['remote extension (uid: uid-remove)', {subdued: '(removed)'}], color: 'red'},
              ],
            },
          ],
          dangerPrompt: true,
        }),
      )
      expect(result).toBe(true)
    })
  })

  describe('when no release', () => {
    test('skips the confirmation prompt', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      const metadataSpyOn = vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      const appTitle = 'app title'

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle,
        release: false,
      })

      // Then
      verifyMetada({
        metadataSpyOn,
        confirmed: result,
        configExtensionIdentifiersBreakdown: breakdownInfo.configExtensionIdentifiersBreakdown!,
      })
      expect(renderConfirmationPromptSpyOn).not.toHaveBeenCalled()
      expect(result).toBe(true)
    })
  })

  describe('allow-updates and allow-deletes flags', () => {
    test('allowUpdates and allowDeletes together should skip prompt and return true', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt')
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle: 'app title',
        release: true,
        allowUpdates: true,
        allowDeletes: true,
      })

      // Then
      expect(renderConfirmationPromptSpyOn).not.toHaveBeenCalled()
      expect(result).toBe(true)
    })

    test('allowUpdates without deletes should skip prompt and return true', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      // Remove all deletions
      breakdownInfo.extensionIdentifiersBreakdown.onlyRemote = []
      breakdownInfo.configExtensionIdentifiersBreakdown!.deletedFieldNames = []

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt')
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle: 'app title',
        release: true,
        allowUpdates: true,
        allowDeletes: false,
      })

      // Then
      expect(renderConfirmationPromptSpyOn).not.toHaveBeenCalled()
      expect(result).toBe(true)
    })

    test('allowUpdates with deletes should show prompt in TTY', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()

      const renderDangerousConfirmationPromptSpyOn = vi
        .spyOn(ui, 'renderDangerousConfirmationPrompt')
        .mockResolvedValue(true)
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(true)

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle: 'app title',
        release: true,
        allowUpdates: true,
        allowDeletes: false,
      })

      // Then
      expect(renderDangerousConfirmationPromptSpyOn).toHaveBeenCalled()
      expect(result).toBe(true)
    })

    test('allowDeletes without updates should skip prompt and return true', async () => {
      // Given
      const breakdownInfo = buildEmptyBreakdownInfo()
      // Add only deletions
      breakdownInfo.extensionIdentifiersBreakdown.onlyRemote = [buildExtensionBreakdownInfo('remote', 'uid')]
      breakdownInfo.configExtensionIdentifiersBreakdown!.deletedFieldNames = ['deleted field']

      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt')
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle: 'app title',
        release: true,
        allowUpdates: false,
        allowDeletes: true,
      })

      // Then
      expect(renderConfirmationPromptSpyOn).not.toHaveBeenCalled()
      expect(result).toBe(true)
    })

    test('non-TTY with deletes and without allowDeletes should throw error', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When/Then
      await expect(
        deployOrReleaseConfirmationPrompt({
          ...breakdownInfo,
          appTitle: 'app title',
          release: true,
          allowUpdates: true,
          allowDeletes: false,
        }),
      ).rejects.toThrow('This deployment includes changes that require confirmation.')
    })

    test('non-TTY with updates and without allowUpdates should throw error', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When/Then
      await expect(
        deployOrReleaseConfirmationPrompt({
          ...breakdownInfo,
          appTitle: 'app title',
          release: true,
          allowUpdates: false,
          allowDeletes: true,
        }),
      ).rejects.toThrow('This deployment includes changes that require confirmation.')
    })

    test('non-TTY with only updates should suggest --allow-updates flag in error', async () => {
      // Given
      const breakdownInfo = buildEmptyBreakdownInfo()
      // Add only updates (no deletes)
      breakdownInfo.extensionIdentifiersBreakdown.toCreate = [buildExtensionBreakdownInfo('new extension', 'uid-new')]
      breakdownInfo.configExtensionIdentifiersBreakdown!.newFieldNames = ['new field']

      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When/Then
      await expect(
        deployOrReleaseConfirmationPrompt({
          ...breakdownInfo,
          appTitle: 'app title',
          release: true,
        }),
      ).rejects.toMatchObject({
        message: 'This deployment includes changes that require confirmation.',
        // tryMessage contains the suggestion with the command token
        tryMessage: expect.arrayContaining([{command: '--allow-updates'}]),
      })
    })

    test('non-TTY with only deletes should suggest --allow-deletes flag in error', async () => {
      // Given
      const breakdownInfo = buildEmptyBreakdownInfo()
      // Add only deletes (no updates)
      breakdownInfo.extensionIdentifiersBreakdown.onlyRemote = [
        buildExtensionBreakdownInfo('remote extension', 'uid-remote'),
      ]

      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When/Then
      await expect(
        deployOrReleaseConfirmationPrompt({
          ...breakdownInfo,
          appTitle: 'app title',
          release: true,
        }),
      ).rejects.toMatchObject({
        message: 'This deployment includes changes that require confirmation.',
        // tryMessage contains the suggestion with the command token
        tryMessage: expect.arrayContaining([{command: '--allow-deletes'}]),
      })
    })

    test('non-TTY with both updates and deletes should suggest both flags in error', async () => {
      // Given
      const breakdownInfo = buildCompleteBreakdownInfo()
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When/Then
      await expect(
        deployOrReleaseConfirmationPrompt({
          ...breakdownInfo,
          appTitle: 'app title',
          release: true,
        }),
      ).rejects.toMatchObject({
        message: 'This deployment includes changes that require confirmation.',
        // tryMessage contains the suggestion with both command flags joined
        tryMessage: expect.arrayContaining([{command: '--allow-updates --allow-deletes'}]),
      })
    })

    test('non-TTY without any changes should not throw error', async () => {
      // Given
      const breakdownInfo = buildEmptyBreakdownInfo()
      const renderConfirmationPromptSpyOn = vi.spyOn(ui, 'renderConfirmationPrompt').mockResolvedValue(true)
      vi.spyOn(metadata, 'addPublicMetadata').mockImplementation(async () => {})
      vi.spyOn(ui, 'isTTY').mockReturnValue(false)

      // When
      const result = await deployOrReleaseConfirmationPrompt({
        ...breakdownInfo,
        appTitle: 'app title',
        release: true,
      })

      // Then - should show the prompt normally since there are no changes requiring confirmation
      expect(renderConfirmationPromptSpyOn).toHaveBeenCalled()
      expect(result).toBe(true)
    })
  })
})

interface RenderConfirmationPromptContentOptions {
  infoTable?: ui.InfoTableSection[]
  appTitle?: string
  message?: string
  dangerPrompt?: boolean
  confirmationMessage?: string
}

function renderConfirmationPromptContent(options: RenderConfirmationPromptContentOptions = {}) {
  const {infoTable, message, dangerPrompt, appTitle, confirmationMessage} = options

  return {
    ...(dangerPrompt ? {} : {cancellationMessage: 'No, cancel'}),
    ...(dangerPrompt ? {} : {confirmationMessage: confirmationMessage ?? 'Yes, release this new version'}),
    ...(dangerPrompt ? {confirmation: appTitle} : {}),
    infoTable,
    message: message ?? `Release a new version${appTitle ? ` of ${appTitle}` : ''}?`,
  }
}

function buildCompleteBreakdownInfo() {
  const emptyBreakdownInfo = buildEmptyBreakdownInfo()

  emptyBreakdownInfo.extensionIdentifiersBreakdown.onlyRemote.push(
    buildExtensionBreakdownInfo('remote extension', 'uid-remove'),
  )
  emptyBreakdownInfo.extensionIdentifiersBreakdown.toCreate.push(
    buildExtensionBreakdownInfo('to create extension', 'uid-create'),
  )
  emptyBreakdownInfo.extensionIdentifiersBreakdown.unchanged.push(
    buildExtensionBreakdownInfo('unchanged extension', undefined),
    buildDashboardBreakdownInfo('from dashboard extension'),
  )

  emptyBreakdownInfo.extensionIdentifiersBreakdown.toUpdate.push(
    buildExtensionBreakdownInfo('to update extension', undefined),
  )

  emptyBreakdownInfo.configExtensionIdentifiersBreakdown!.existingFieldNames.push('existing field name1')
  emptyBreakdownInfo.configExtensionIdentifiersBreakdown!.existingUpdatedFieldNames.push('updating field name1')
  emptyBreakdownInfo.configExtensionIdentifiersBreakdown!.newFieldNames.push('new field name1')
  emptyBreakdownInfo.configExtensionIdentifiersBreakdown!.deletedFieldNames.push('deleted field name1')

  return emptyBreakdownInfo
}

function buildEmptyBreakdownInfo(): {
  extensionIdentifiersBreakdown: ExtensionIdentifiersBreakdown
  configExtensionIdentifiersBreakdown?: ConfigExtensionIdentifiersBreakdown
} {
  return {
    extensionIdentifiersBreakdown: buildEmptyExtensionsBreakdownInfo(),
    configExtensionIdentifiersBreakdown: buildEmptyConfigExtensionsBreakdownInfo(),
  }
}

function buildEmptyExtensionsBreakdownInfo(): ExtensionIdentifiersBreakdown {
  return {
    onlyRemote: [],
    toCreate: [],
    toUpdate: [],
    unchanged: [],
  }
}

function buildEmptyConfigExtensionsBreakdownInfo(): ConfigExtensionIdentifiersBreakdown {
  return {
    existingFieldNames: [],
    existingUpdatedFieldNames: [],
    newFieldNames: [],
    deletedFieldNames: [],
  }
}

function verifyMetada({
  metadataSpyOn,
  extensionIdentifiersBreakdown,
  confirmed,
  configExtensionIdentifiersBreakdown,
}: {
  metadataSpyOn: MockInstance
  extensionIdentifiersBreakdown?: ExtensionIdentifiersBreakdown
  confirmed: boolean
  configExtensionIdentifiersBreakdown: ConfigExtensionIdentifiersBreakdown
}) {
  const configurationBreakdownMetadata = buildConfigurationBreakdownMetadata(configExtensionIdentifiersBreakdown)

  expect(metadataSpyOn).toHaveBeenNthCalledWith(1, expect.any(Function))
  expect(metadataSpyOn.mock.calls[0]![0]()).toEqual(configurationBreakdownMetadata)

  if (!extensionIdentifiersBreakdown) return

  expect(metadataSpyOn).toHaveBeenNthCalledWith(2, expect.any(Function))
  expect(metadataSpyOn.mock.calls[1]![0]()).toEqual({
    cmd_deploy_confirm_new_registrations: extensionIdentifiersBreakdown.toCreate.length,
    cmd_deploy_confirm_updated_registrations: extensionIdentifiersBreakdown.toUpdate.length,
    cmd_deploy_confirm_removed_registrations: extensionIdentifiersBreakdown.onlyRemote.length,
  })
  expect(metadataSpyOn).toHaveBeenNthCalledWith(3, expect.any(Function))
  expect(metadataSpyOn.mock.calls[2]![0]()).toEqual(
    expect.objectContaining({
      cmd_deploy_confirm_cancelled: !confirmed,
    }),
  )
}
