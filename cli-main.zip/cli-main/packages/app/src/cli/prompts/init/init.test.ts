import init, {InitOptions, templateRequiresFlavor, visibleTemplates} from './init.js'
import {describe, expect, vi, test, beforeEach} from 'vitest'
import {renderSelectPrompt} from '@shopify/cli-kit/node/ui'
import {installGlobalCLIPrompt} from '@shopify/cli-kit/node/is-global'

vi.mock('@shopify/cli-kit/node/ui')
vi.mock('@shopify/cli-kit/node/is-global')

const globalCLIResult = {install: true, alreadyInstalled: false}

describe('init', () => {
  beforeEach(() => {
    vi.mocked(installGlobalCLIPrompt).mockResolvedValue(globalCLIResult)
  })

  test('it renders the label for the template options', async () => {
    const answers = {
      template: 'https://github.com/Shopify/shopify-app-template-extension-only',
    }
    const options: InitOptions = {}

    // Given
    vi.mocked(renderSelectPrompt).mockResolvedValueOnce('none')

    // When
    const got = await init(options)

    // Then
    expect(renderSelectPrompt).toHaveBeenCalledWith({
      choices: [
        {label: 'Build a React Router app (recommended)', value: 'reactRouter'},
        {label: 'Build an extension-only app', value: 'none'},
      ],
      message: 'Get started building your app:',
      defaultValue: 'reactRouter',
    })
    expect(got).toEqual({...options, ...answers, templateType: 'none', globalCLIResult})
  })

  describe('visibleTemplates', () => {
    test('omits the deprecated remix template so it is not advertised in --template help text', () => {
      expect(visibleTemplates).not.toContain('remix')
    })

    test('exposes only the templates that are still actively offered', () => {
      expect(visibleTemplates).toEqual(['reactRouter', 'none'])
    })
  })

  test.each<{template: string | undefined; expected: boolean}>([
    {template: 'reactRouter', expected: true},
    {template: 'remix', expected: true},
    {template: 'none', expected: false},
    {template: 'https://github.com/Shopify/custom-template', expected: false},
    {template: undefined, expected: false},
  ])('reports whether template $template requires a flavor', ({template, expected}) => {
    expect(templateRequiresFlavor(template)).toBe(expected)
  })

  test('it renders branches for templates that have them', async () => {
    const answers = {
      template: 'https://github.com/Shopify/shopify-app-template-react-router#javascript-cli',
    }
    const options: InitOptions = {}

    // Given
    vi.mocked(renderSelectPrompt).mockResolvedValueOnce('reactRouter')
    vi.mocked(renderSelectPrompt).mockResolvedValueOnce('javascript-cli')

    // When
    const got = await init(options)

    // Then
    expect(renderSelectPrompt).toHaveBeenCalledWith({
      choices: [
        {label: 'Build a React Router app (recommended)', value: 'reactRouter'},
        {
          label: 'Build an extension-only app',
          value: 'none',
        },
      ],
      message: 'Get started building your app:',
      defaultValue: 'reactRouter',
    })
    expect(renderSelectPrompt).toHaveBeenCalledWith({
      choices: [
        {label: 'JavaScript', value: 'javascript-cli'},
        {label: 'TypeScript', value: 'main-cli'},
      ],
      message: 'For your React Router template, which language do you want?',
    })
    expect(got).toEqual({...options, ...answers, templateType: 'reactRouter', globalCLIResult})
  })
})
