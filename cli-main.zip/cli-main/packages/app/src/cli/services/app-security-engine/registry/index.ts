import {loadChecks, type Check} from '../checks/index.js'
import {RULE_CATALOG, type RuleCatalogEntry} from '../rules/catalog.js'
import {DETERMINISTIC_CHECKS, type DeterministicCheckDefinition} from '../scanners/index.js'
import type {CheckPrecedence} from '../types.js'

export type ImplementationProvenance = 'deterministic' | 'agent'

/** One check the coding agent can run, as the terminal output needs it to say which checks still need the agent. */
export interface AgentCheckCatalogEntry {
  id: string
  /**
   * How a recorded agent result combines with the deterministic one. The results files only record it with an agent
   * result, so a check the agent hasn't run needs the catalog's.
   */
  precedence: CheckPrecedence
}

/** The checks the coding agent can run, with the precedence of each. */
export function getAgentCheckCatalog(): AgentCheckCatalogEntry[] {
  return [...loadChecks().values()].map(({id, precedence}) => ({id, precedence}))
}

export interface RegistryEntry {
  id: string
  version: number
  kind: ImplementationProvenance
  status: 'active' | 'planned' | 'investigate'
  severity: RuleCatalogEntry['severity']
  title: string
  description: string
  points: number
  fix: string
  guide?: string
  requires?: RuleCatalogEntry['requires']
  prompt_hash?: string
}

interface RegistryInvariantInput {
  catalog: ReadonlyArray<RuleCatalogEntry>
  deterministic: ReadonlyArray<DeterministicCheckDefinition>
  /** Derived from `Check` so the invariant input can't drift from the real agent check shape. */
  agent: ReadonlyArray<Pick<Check, 'id' | 'version' | 'prompt_hash' | 'precedence'>>
}

/** Assert identities before they are exposed or executed. */
export function assertRegistryInvariants(input: RegistryInvariantInput): void {
  const catalogIds = new Set<string>()
  for (const entry of input.catalog) {
    if (catalogIds.has(entry.id)) throw new Error(`Duplicate stable product ID: ${entry.id}`)
    catalogIds.add(entry.id)
  }

  const implementationIds = new Set<string>()
  for (const definition of input.deterministic) {
    const key = `deterministic:${definition.id}`
    if (implementationIds.has(key)) throw new Error(`Duplicate deterministic stable ID: ${definition.id}`)
    implementationIds.add(key)
    if (!catalogIds.has(definition.id)) throw new Error(`Orphan deterministic runner: ${definition.id}`)
    if (definition.lifecycle === 'active' && !definition.runner)
      throw new Error(`Active deterministic check has no runner: ${definition.id}`)
    if (definition.lifecycle !== 'active' && definition.runner)
      throw new Error(`A non-active deterministic check can't have a runner: ${definition.id}`)
  }
  for (const check of input.agent) {
    const key = `agent:${check.id}`
    if (implementationIds.has(key)) throw new Error(`Duplicate agent stable ID: ${check.id}`)
    implementationIds.add(key)
    if (!catalogIds.has(check.id)) throw new Error(`Orphan agent implementation: ${check.id}`)
    const deterministic = input.deterministic.find((definition) => definition.id === check.id)
    if (deterministic && deterministic.version !== check.version)
      throw new Error(`Deterministic and agent versions differ for shared product ID: ${check.id}`)
    // Preferring the agent only makes sense when there is a deterministic result to prefer it over.
    if (check.precedence === 'prefer-agent' && !deterministic)
      throw new Error(`prefer-agent check has no deterministic implementation: ${check.id}`)
  }

  const implementedProducts = new Set([
    ...input.deterministic.map((definition) => definition.id),
    ...input.agent.map((check) => check.id),
  ])
  for (const entry of input.catalog) {
    if ((entry.status ?? 'active') === 'active' && !implementedProducts.has(entry.id))
      throw new Error(`Active check has no implementation: ${entry.id}`)
    if ((entry.status === 'planned' || entry.status === 'investigate') && implementedProducts.has(entry.id))
      throw new Error(`Non-active check has an executable implementation: ${entry.id}`)
  }
}

/** The public registry preserves a shared product ID and explicit provenance. */
export function getRegistry(): RegistryEntry[] {
  const checks = [...loadChecks().values()]
  const deterministicChecks = [...DETERMINISTIC_CHECKS.values()]
  assertRegistryInvariants({catalog: RULE_CATALOG, deterministic: deterministicChecks, agent: checks})
  const catalog = new Map(RULE_CATALOG.map((entry) => [entry.id, entry]))
  const deterministic: RegistryEntry[] = deterministicChecks.map((definition) => {
    const entry = catalog.get(definition.id)!
    return registryEntry(entry, {
      version: definition.version,
      kind: 'deterministic',
      status: definition.lifecycle,
    })
  })
  const agent: RegistryEntry[] = checks.map((check) => {
    const entry = catalog.get(check.id)!
    return registryEntry(entry, {
      version: check.version,
      kind: 'agent',
      status: 'active',
      prompt_hash: check.prompt_hash,
    })
  })
  return [...deterministic, ...agent].sort((left, right) =>
    `${left.id}|${left.kind}`.localeCompare(`${right.id}|${right.kind}`),
  )
}

/** The IDs of the checks a results file can settle: the active registry entries, each ID once. */
export function listSettleableCheckIds(): string[] {
  const ids = getRegistry()
    .filter((entry) => entry.status === 'active')
    .map((entry) => entry.id)
  return [...new Set(ids)].sort()
}

/** The sources that can report findings for each check ID: those with an active implementation of the check. */
export function reportingSourcesByCheckId(): Map<string, Set<ImplementationProvenance>> {
  const sources = new Map<string, Set<ImplementationProvenance>>()
  for (const entry of getRegistry()) {
    if (entry.status !== 'active') continue
    sources.set(entry.id, new Set([...(sources.get(entry.id) ?? []), entry.kind]))
  }
  return sources
}

function registryEntry(
  entry: RuleCatalogEntry,
  implementation: Pick<RegistryEntry, 'version' | 'kind' | 'status'> & {prompt_hash?: string},
): RegistryEntry {
  return {
    id: entry.id,
    ...implementation,
    severity: entry.severity,
    title: entry.title,
    description: entry.description,
    points: implementation.status === 'active' ? entry.points : 0,
    fix: entry.fix,
    ...(entry.guide ? {guide: entry.guide} : {}),
    ...(entry.requires ? {requires: entry.requires} : {}),
  }
}
