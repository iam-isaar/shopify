---
id: DEPRECATED_SCRIPT_TAG_SCOPE
version: 3
severity: medium
precedence: prefer-agent
---

# Deprecated Script Tag Scope

Inspect parsed app scopes and JavaScript/TypeScript Admin API operations for deprecated ScriptTag capability. Report `read_script_tags`, `write_script_tags`, or ScriptTag create/update use under this single product ID.
