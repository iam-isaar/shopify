---
id: APP_PROXY_LIQUID_INJECTION
version: 3
severity: high
precedence: prefer-agent
---

# App Proxy Liquid Injection

Trace verified app-proxy request values into active response bodies, including Liquid and HTML response types. Report only a request-controlled value that reaches an active response; static templates and inert JSON are not findings.
