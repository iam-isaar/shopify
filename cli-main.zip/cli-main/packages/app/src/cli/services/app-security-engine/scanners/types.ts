import type {AnalysisMode, CheckExecutionReason, CheckExecutionStatus, Issue} from '../types.js'

export interface AppTomlContent {
  /** Raw parsed TOML object */
  raw: Record<string, unknown>
  /** Path to the file */
  path: string
  /** Exact bytes decoded for parsing and hashing. */
  content?: string
  /** The scopes string, if present. */
  scopes?: string
  /** The TOML key that first declares each scope in `scopes`, as `tomlKey` writes it. */
  scopeKeys: ReadonlyMap<string, string>
  /** API version selected by this configuration. */
  apiVersion?: string
  /** OAuth redirect URLs, at their indexes in `auth.redirect_urls`. */
  redirectUrls: string[]
  /** Webhook subscriptions. */
  webhooks: WebhookSubscription[]
}

export interface WebhookSubscription {
  topics: string[]
  uri: string
  /** The TOML key of `uri`, as `tomlKey` writes it. */
  uriKey: string
}

export interface ExtensionInfo {
  /** Path to shopify.extension.toml */
  path: string
  /** Extension type, e.g. "theme_app_extension" */
  type: string
  /** Exact configuration bytes decoded for parsing and hashing. */
  content?: string
  /** All files in the extension directory */
  files: SourceFile[]
}

export interface SourceFile {
  /** Project-relative path */
  path: string
  /** Absolute path */
  absolutePath: string
  /** File extension */
  ext: string
  /** File contents (read lazily where possible) */
  content?: string
}

/** Explicitly allowlisted dependency-management configuration at the root of the repository that holds the app. */
export interface DependencyAutomationInputs {
  files: SourceFile[]
  /** A specific discovery obstacle, such as an unreadable configuration file. */
  unresolvedReason?: string
}

export interface ManifestFile {
  path: string
  absolutePath: string
  type: 'npm'
  /** Exact manifest bytes decoded for parsing and hashing. */
  content?: string
  /** Parsed dependencies, keyed by name with version specifications as values. */
  dependencies: Record<string, string>
  devDependencies?: Record<string, string>
}

/** One implementation inside a multi-implementation runner. Used to derive the runner result; never written out. */
export interface RunnerImplementationResult {
  id: string
  analysisMode: AnalysisMode
  status: CheckExecutionStatus
  inspectedFiles: string[]
  findings: number
  reason?: CheckExecutionReason
}

export interface RunnerResult {
  issues: Issue[]
  unresolvedReason?: string
  unresolvedReasonCode?: CheckExecutionReason['code']
  inspectedFiles?: string[]
}
