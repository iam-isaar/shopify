---
id: INSECURE_WEBHOOK_URL
version: 3
severity: high
precedence: prefer-agent
---

# Insecure Configured Callback Url

Inspect webhook destinations and OAuth redirect URLs in the selected Shopify app configuration. Relative Shopify paths and valid pubsub/eventbridge webhook destinations are allowed. Report HTTP, malformed, credential-bearing, wildcard-host, wildcard-path, or otherwise unsafe configured callback URLs.
