import {runGit} from '../scanners/git.js'
import {sha256} from '@shopify/cli-kit/node/crypto'
import {basename, dirname} from '@shopify/cli-kit/node/path'
import type {ScanContext, SourceFile} from './types.js'
import type {AppSecurityScope, Issue} from '../types.js'

/**
 * Each secret pattern MUST place the sensitive material in capture group 1
 * (or make the whole match sensitive when `wholeMatch` is set), because
 * redaction uses the pattern's match instead of a separately-maintained regex.
 *
 * Detection patterns are reused by redaction, so a pattern that can produce a
 * finding always redacts the exact same span.
 */
interface SecretPattern {
  regex: RegExp
  name: string
  /** When true the entire match is the secret; otherwise capture group 1 is. */
  wholeMatch?: boolean
  /** When true no part of the input is safe to retain after this pattern matches. */
  redactEntireInput?: boolean
}

// Shopify credentials are recognized by value prefix, never by variable or
// key name — a secret-sounding name with a placeholder value (as in committed
// `.env.example` files) is not evidence of a leak.
// shpat_/shpca_/shppa_/shpss_ bodies are hex; shprt_/shpsb_/shptka_/shpua_
// are alphanumeric. The first seven prefixes are already public via
// shopify.dev docs and published secret-scanning rules (gitleaks, GitHub
// partner patterns); shpua_ marks tokens issued while an app is still in
// development — the most likely to be committed.
const SHOPIFY_TOKEN_PATTERN: SecretPattern = {
  regex: /shp(?:(?:at|ca|pa|ss)_[a-fA-F0-9]{16,}|(?:rt|sb|tka|ua)_[a-zA-Z0-9]{16,})/,
  name: 'Shopify token',
  wholeMatch: true,
}

/**
 * Patterns that can emit COMMITTED_SECRET findings.
 *
 * Keep this list limited to Shopify credentials. The app security scan should
 * not duplicate general-purpose secret scanners for third-party providers.
 */
export const SHOPIFY_SECRET_PATTERNS: SecretPattern[] = [SHOPIFY_TOKEN_PATTERN]

/**
 * Patterns used only to prevent known credentials from being echoed in scanner
 * and agent output. They never produce findings unless they are also listed in
 * SHOPIFY_SECRET_PATTERNS.
 */
const REDACTION_PATTERNS: SecretPattern[] = [
  SHOPIFY_TOKEN_PATTERN,
  // Stripe secret/restricted keys. Publishable `pk_` keys are public by design.
  {
    regex: /(?:sk|rk)_(?:live|test)_[a-zA-Z0-9]{20,}/,
    name: 'Stripe API key',
    wholeMatch: true,
  },
  // AWS access key ID
  {regex: /AKIA[0-9A-Z]{16}/, name: 'AWS access key', wholeMatch: true},
  // AWS secret access key (40 char base64-ish, assignment context to limit noise)
  {
    regex: /aws[_-]?secret[_-]?access[_-]?key\s*[:=]\s*['"]([A-Za-z0-9/+=]{40})['"]/i,
    name: 'AWS secret access key',
  },
  // GitHub tokens
  {
    regex: /gh[pousr]_[A-Za-z0-9]{36,}/,
    name: 'GitHub token',
    wholeMatch: true,
  },
  // Google API key
  {regex: /AIza[0-9A-Za-z_-]{35}/, name: 'Google API key', wholeMatch: true},
  // Slack token
  {
    regex: /xox[baprs]-[0-9A-Za-z-]{10,}/,
    name: 'Slack token',
    wholeMatch: true,
  },
  // Match complete blocks first so arbitrary multiline output never retains key material or its footer.
  {
    regex: /-----BEGIN ((?:(?:RSA|EC|OPENSSH) )?PRIVATE KEY|PGP PRIVATE KEY BLOCK)-----[\s\S]*?-----END \1-----/,
    name: 'private key block',
    wholeMatch: true,
  },
  // Keep a header-only detector for line-oriented repository scanning and malformed/truncated keys.
  {
    regex: /-----BEGIN (?:(?:RSA|EC|OPENSSH) )?PRIVATE KEY-----|-----BEGIN PGP PRIVATE KEY BLOCK-----/,
    name: 'private key',
    wholeMatch: true,
    redactEntireInput: true,
  },
]

/**
 * Redact a line using the pattern that matched it.
 *
 * The redacted span is taken from the matching detection or redaction pattern.
 * Never returns the raw secret.
 */
export function redactMatch(line: string, pattern: SecretPattern): string {
  const match = pattern.regex.exec(line)
  if (!match) return '[REDACTED]'
  if (pattern.redactEntireInput) return '[REDACTED LINE]'

  const secret = pattern.wholeMatch ? match[0] : match[1]
  if (!secret) return '[REDACTED]'

  // Keep a short prefix for identification (e.g. "AKIA…") but never enough to use.
  const keep = Math.min(4, Math.floor(secret.length / 4))
  const hint = keep > 0 ? secret.slice(0, keep) : ''
  const replaced = line.split(secret).join(`${hint}[REDACTED:${secret.length}:${secretFingerprint(secret)}]`)

  // Belt and braces: if the secret somehow survived, drop the line entirely.
  return replaced.includes(secret) ? '[REDACTED LINE]' : replaced
}

/**
 * A short text that differs between two secrets of one type and length, which are the same text once redacted. A
 * suppression entry for one secret then doesn't match another secret that replaces it on the line. Only a secret that a
 * pattern knows gets one: such a secret is long and random, so 32 bits of its hash don't help to find it.
 */
function secretFingerprint(secret: string): string {
  return sha256(secret).toString('hex').slice(0, 8)
}

// Every marker that redaction writes in place of a secret: `[REDACTED]`, `[REDACTED:<length>]`,
// `[REDACTED:<length>:<fingerprint>]` after the short prefix that `redactMatch` keeps, `[REDACTED LINE]` and
// `[REDACTED TEXT]`.
const REDACTION_MARKER = /\[REDACTED(?::\d+(?::[0-9a-f]{8})?| LINE| TEXT)?\]/

/** Whether a text holds a secret that `redactMatch`, `redactText` or `redactLines` redacted. */
export function hasRedactedSecret(text: string): boolean {
  return REDACTION_MARKER.test(text)
}

/** Redact every known secret occurrence from arbitrary scanner or agent text. */
export function redactText(text: string): string {
  let redacted = text
  for (const pattern of REDACTION_PATTERNS) {
    // Patterns deliberately have no global flag. Re-run until all occurrences
    // are removed, with a guard against a future non-progressing pattern.
    for (let count = 0; count < 100; count++) {
      const match = pattern.regex.exec(redacted)
      if (!match) break
      const next = redactMatch(redacted, pattern)
      if (next === redacted) return '[REDACTED TEXT]'
      redacted = next
    }
    // Fail closed when hostile input contains more matches than the work cap.
    if (pattern.regex.test(redacted)) return '[REDACTED TEXT]'
  }
  return redacted
}

/** Names that hold a secret. `auth` is left out, because it is also in names such as `authenticate` and `author`. */
const SECRET_NAME = 'secret|passw(?:or)?d|pwd|token|api[_-]?key|private[_-]?key|credential'

/**
 * A name that holds a secret, then the assignment, but not a comparison or an arrow function. Excerpts redact the value
 * that follows, which no pattern may know.
 */
const SECRET_NAME_ASSIGNMENT_PATTERN = new RegExp(`(?:${SECRET_NAME}|auth)\\w*["']?\\s*(?::=|[:=](?![=>]))\\s*`, 'gi')

const SECRET_NAME_PATTERN = new RegExp(SECRET_NAME, 'i')

/** A name that holds a secret and its value in one string, as in the connection string `Server=db;Password=…;`. */
const SECRET_NAME_INSIDE_STRING_PATTERN = new RegExp(`(?:${SECRET_NAME})\\w*\\s*[:=]`, 'i')

/** Each string literal on a line. One without a closing quote continues to the end of the line. */
const STRING_LITERAL_PATTERN = /(["'`])((?:\\[^\r\n]|(?!\1)[^\\\r\n])*)\1?/g

/**
 * The text of a quoted value, up to its closing quote or, when it continues on the next line, the end of the line. A
 * line can hold a separator that isn't a line feed, such as U+2028, which is part of the value.
 */
const QUOTED_VALUE_PATTERN = /^(["'`])((?:\\[^\r\n]|(?!\1)[^\r\n])*)/

/** An unquoted value, up to the end of the line, however the line ends. */
const UNQUOTED_VALUE_PATTERN = /^([\s\S]*?)\s*$/

/** The password in a URL's user information, as in `postgres://user:password@host`. */
const URL_PASSWORD_PATTERN = /(:\/\/[^\s:/?#@]*:)([^\s/?#]+)@/g

const redactedValue = (value: string) => `[REDACTED:${value.length}]`

/**
 * Where the value assigned after `offset` starts, and its text. In source code, an unquoted value is an expression, such
 * as a variable, so only a quoted value counts there. A value that's empty or already redacted needs nothing.
 */
function assignedValue(line: string, offset: number, sourceCode: boolean): {start: number; text: string} | undefined {
  const rest = line.slice(offset)
  const quoted = QUOTED_VALUE_PATTERN.exec(rest)
  let value: {start: number; text: string} | undefined
  if (quoted) value = {start: offset + 1, text: quoted[2]!}
  else if (!sourceCode) value = {start: offset, text: UNQUOTED_VALUE_PATTERN.exec(rest)![1]!}
  return value && value.text !== '' && !value.text.includes('[REDACTED') ? value : undefined
}

/** A name that holds a secret, then an operator that expects a value after it, ending a line of source code. */
const SECRET_NAME_OPERATOR_AT_END_PATTERN = /(?:=|:|\(|\|\||\?\?)$/

/** The start of a YAML block scalar, whose value is the lines that follow. */
const BLOCK_SCALAR_PATTERN = /^[|>][+-]?\d*$/

/** What a line leaves open for the next one, when it ends before the value of a secret does. */
type OpenValue =
  /** The value starts on the next line that isn't empty. */
  | {kind: 'awaiting'}
  /** A quoted value goes on until its closing quote. */
  | {kind: 'quoted'; quote: string}
  /** A block scalar goes on over the lines that are indented further than `indent`. */
  | {kind: 'block'; indent: number}

interface RedactedLine {
  text: string
  open: OpenValue | undefined
}

const indentOf = (line: string) => line.length - line.trimStart().length

/** What the text after an assignment to a secret name leaves open: nothing when its value ends on its line. */
function openValueAfter(rest: string, sourceCode: boolean, indent: number): OpenValue | undefined {
  if (rest === '') return {kind: 'awaiting'}
  const quoted = QUOTED_VALUE_PATTERN.exec(rest)
  if (quoted) return rest.length === 1 + quoted[2]!.length ? {kind: 'quoted', quote: quoted[1]!} : undefined
  return !sourceCode && BLOCK_SCALAR_PATTERN.test(rest.trimEnd()) ? {kind: 'block', indent} : undefined
}

/** The index of the first `quote` that a backslash doesn't escape, or -1. */
function closingQuoteIndex(line: string, quote: string): number {
  for (let index = 0; index < line.length; index++) {
    if (line[index] === '\\') index++
    else if (line[index] === quote) return index
  }
  return -1
}

/**
 * Redact the secrets that excerpts never quote, though no redaction pattern knows them: URL passwords, and the values
 * assigned to names such as `password`, `api_key` or `apiSecretKey`. Only excerpts are redacted this way, because they
 * quote lines that no one chose. A value can start on the line after its name, or go on over several lines, so each
 * line says what it leaves open, and the next line starts from that.
 */
function redactUnrecognizedSecrets(line: string, sourceCode: boolean, carried: OpenValue | undefined): RedactedLine {
  if (carried?.kind === 'quoted') {
    const closing = closingQuoteIndex(line, carried.quote)
    if (closing === -1) return {text: '[REDACTED LINE]', open: carried}
    const after = redactUnrecognizedSecrets(line.slice(closing + 1), sourceCode, undefined)
    const value = closing === 0 ? '' : redactedValue(line.slice(0, closing))
    return {text: `${value}${carried.quote}${after.text}`, open: after.open}
  }
  if (carried?.kind === 'block' && line.trim() === '') return {text: line, open: carried}
  if (carried?.kind === 'block' && indentOf(line) > carried.indent) return {text: '[REDACTED LINE]', open: carried}
  if (carried?.kind === 'awaiting' && line.trim() === '') return {text: line, open: carried}

  const withoutUrlPasswords = line.replace(
    URL_PASSWORD_PATTERN,
    (_match, prefix: string, password: string) => `${prefix}${redactedValue(password)}@`,
  )
  const indent = indentOf(withoutUrlPasswords)
  const assignments = [
    ...(carried?.kind === 'awaiting' ? [{nameIndex: 0, valueStart: indent}] : []),
    ...[...withoutUrlPasswords.matchAll(SECRET_NAME_ASSIGNMENT_PATTERN)].map((name) => ({
      nameIndex: name.index,
      valueStart: name.index + name[0].length,
    })),
  ]
  let redacted = ''
  let position = 0
  let open: OpenValue | undefined
  for (const {nameIndex, valueStart} of assignments) {
    // A name inside a value that's already redacted is part of that value.
    if (nameIndex < position) continue
    open = openValueAfter(withoutUrlPasswords.slice(valueStart), sourceCode, indent)
    const value = assignedValue(withoutUrlPasswords, valueStart, sourceCode)
    if (value === undefined) continue
    redacted += `${withoutUrlPasswords.slice(position, value.start)}${redactedValue(value.text)}`
    position = value.start + value.text.length
  }
  const withoutAssignedValues = `${redacted}${withoutUrlPasswords.slice(position)}`
  if (!sourceCode) return {text: withoutAssignedValues, open}
  const endsBeforeValue =
    SECRET_NAME_PATTERN.test(withoutAssignedValues) &&
    SECRET_NAME_OPERATOR_AT_END_PATTERN.test(withoutAssignedValues.trimEnd())
  return {
    text: redactStringsNearSecretNames(withoutAssignedValues),
    open: open ?? (endsBeforeValue ? {kind: 'awaiting'} : undefined),
  }
}

/**
 * Redact the strings of a source code line that come after a name that holds a secret, and the strings that hold such a
 * name with its value. The value can be anywhere after the name: behind a type, a comparison, a fallback or a call, as
 * in `const password: string = "…"`, `token === "…"`, `process.env.TOKEN || "…"` and `setPassword("…")`.
 */
function redactStringsNearSecretNames(line: string): string {
  const secretName = SECRET_NAME_PATTERN.exec(line)
  if (!secretName) return line
  const secretNameEnd = secretName.index + secretName[0].length
  return line.replace(STRING_LITERAL_PATTERN, (literal: string, quote: string, value: string, offset: number) => {
    const holdsSecret = offset >= secretNameEnd || SECRET_NAME_INSIDE_STRING_PATTERN.test(value)
    if (!holdsSecret || value === '' || value.includes('[REDACTED')) return literal
    return `${quote}${redactedValue(value)}${literal.slice(1 + value.length)}`
  })
}

/** The index of the last of the ascending `values` that is at most `offset`, or -1 when none is. */
function lastIndexAtOrBefore(values: ReadonlyArray<number>, offset: number): number {
  let low = 0
  let high = values.length - 1
  while (low <= high) {
    const middle = Math.floor((low + high) / 2)
    if (values[middle]! <= offset) low = middle + 1
    else high = middle - 1
  }
  return high
}

/**
 * Redact a text line by line, for excerpts that quote only some of its lines. A secret can span lines, so a line that
 * holds part of a match that spans lines becomes `[REDACTED LINE]`, even when the excerpt leaves out the line where the
 * match starts. So does every line from a private key header without its footer to the end of the text. Each other
 * line is redacted with every pattern, and so are the values that look secret on it: in `sourceCode`, only the strings
 * that follow a name that holds a secret. A value that starts on a line after its name, or goes on over several lines,
 * is redacted there too. A line has no carriage return at its end, so a text with CRLF line endings is redacted as one
 * with LF line endings is.
 */
export function redactLines(text: string, {sourceCode = false}: {sourceCode?: boolean} = {}): string[] {
  const lines = text.split('\n')
  let nextLineStart = 0
  const lineStarts = lines.map((line) => {
    const start = nextLineStart
    nextLineStart += line.length + 1
    return start
  })
  const lineAt = (offset: number) => lastIndexAtOrBefore(lineStarts, offset)
  const matches = REDACTION_PATTERNS.flatMap((pattern) =>
    [...text.matchAll(new RegExp(pattern.regex.source, `${pattern.regex.flags}g`))].map((match) => ({
      pattern,
      start: match.index,
      end: match.index + match[0].length,
    })),
  )
  // A header inside a complete private key block is redacted with the block, which ends at its footer. An offset is
  // inside a match when the furthest end of the matches that start at or before it is after it.
  const spans = matches
    .filter(({pattern}) => !pattern.redactEntireInput)
    .sort((left, right) => left.start - right.start)
  const spanStarts = spans.map(({start}) => start)
  let furthestEnd = 0
  const furthestEnds = spans.map(({end}) => {
    furthestEnd = Math.max(furthestEnd, end)
    return furthestEnd
  })
  const isInsideBlock = (offset: number) => {
    const index = lastIndexAtOrBefore(spanStarts, offset)
    return index >= 0 && furthestEnds[index]! > offset
  }
  const redactedLines = new Set<number>()
  for (const {start, end} of spans) {
    if (!text.slice(start, end).includes('\n')) continue
    const lastLine = lineAt(end - 1)
    for (let line = lineAt(start); line <= lastLine; line++) redactedLines.add(line)
  }
  // Headers are found in order, so the first one outside a block redacts every line that any later one would.
  const firstUnterminatedHeader = matches.find(({pattern, start}) => pattern.redactEntireInput && !isInsideBlock(start))
  const firstLineRedactedToTheEnd = firstUnterminatedHeader ? lineAt(firstUnterminatedHeader.start) : lines.length
  let open: OpenValue | undefined
  return lines.map((line, index) => {
    if (index >= firstLineRedactedToTheEnd || redactedLines.has(index)) {
      open = undefined
      return '[REDACTED LINE]'
    }
    const redacted = redactUnrecognizedSecrets(redactText(line.replace(/\r$/, '')), sourceCode, open)
    open = redacted.open
    return redacted.text
  })
}

/**
 * Redact the scope's typed values. Both result files store the scope this way, so redaction never makes them differ.
 */
export function redactScope(scope: AppSecurityScope): AppSecurityScope {
  return {
    include_dirs: scope.include_dirs.map(redactText),
    excludes: scope.excludes.map(redactText),
    no_git_ignore: scope.no_git_ignore,
  }
}

const NAMED_SECRET_FILE_PATTERN = /(^|\/)(?:\.env\.(?:secrets|keys)|(?:secrets|credentials)\.json)$/

function envFileBasename(path: string): string | undefined {
  const basename = path.slice(path.lastIndexOf('/') + 1)
  if (basename === '.env' || basename.startsWith('.env.')) return basename
  return undefined
}

function isEnvFile(path: string): boolean {
  return envFileBasename(path) !== undefined
}

/** Whether every value in the file is presumed secret: an environment file or a named secret file. */
function isSecretFile(path: string): boolean {
  return isEnvFile(path) || NAMED_SECRET_FILE_PATTERN.test(path)
}

/** Lowercase names of files that hold secrets, which the secret scan doesn't treat as secret files. */
const EXCERPT_BLOCKED_FILE_PATTERN =
  /(^|\/)(?:\.envrc|\.dev\.vars|secrets\.ya?ml|credentials\.ya?ml(?:\.enc)?|[^/]*\.(?:key|pem|p12)|\.npmrc|\.netrc|\.pypirc)$/

/**
 * Whether an excerpt must never quote the file: a secret file, or another file that holds secrets, by its name in any
 * case, since a file system that ignores case reads a file by any case of its name.
 */
export function isExcerptBlockedFile(path: string): boolean {
  const lowercasePath = path.toLowerCase()
  return isSecretFile(lowercasePath) || EXCERPT_BLOCKED_FILE_PATTERN.test(lowercasePath)
}

/** Why a file git reports as untracked and ignored still reached this rule. */
type IgnoredFileScanReason = 'nested-repository' | 'listing-failed' | 'unknown'

// Git that can't start after passing the version check exits 0 with no output, so empty output is unknown.
async function gitTopLevel(cwd: string): Promise<string | undefined> {
  const result = await gitProbe(cwd, ['rev-parse', '--show-toplevel'])
  return result.exitCode === 0 && result.out !== '' ? result.out : undefined
}

/** When git listed ignored paths, a nested repository is confirmed by comparing top levels. */
async function ignoredFileScanReason(
  file: SourceFile,
  gitIgnoreListing: ScanContext['gitIgnoreListing'],
  appTopLevel: () => Promise<string | undefined>,
): Promise<{reason: IgnoredFileScanReason; evidence: string[]}> {
  if (gitIgnoreListing === 'failed') return {reason: 'listing-failed', evidence: []}
  if (gitIgnoreListing === 'not-a-repository') return {reason: 'unknown', evidence: []}

  const fileTopLevel = await gitTopLevel(dirname(file.absolutePath))
  const appRootTopLevel = await appTopLevel()
  const bothKnown = fileTopLevel !== undefined && appRootTopLevel !== undefined
  const nested = bothKnown && fileTopLevel !== appRootTopLevel
  let verdict = 'unknown'
  if (nested) verdict = 'differs'
  else if (bothKnown) verdict = 'same'
  return {
    reason: nested ? 'nested-repository' : 'unknown',
    evidence: [`git rev-parse --show-toplevel → ${verdict} for ${file.path} and the app root`],
  }
}

function committedSecretFileIssue(
  file: SourceFile,
  status: GitFileStatus,
  environmentFile: boolean,
  ignoredScanReason: IgnoredFileScanReason,
): Issue {
  const kind = environmentFile ? 'Environment file with secrets' : 'Secret file'
  const tracked = status.tracked === true
  const untrackedAndNotIgnored = status.tracked === false && status.ignored === false
  const untrackedAndIgnored = status.tracked === false && status.ignored === true

  let title: string
  let message: string
  let fixDescription: string
  if (tracked) {
    title = `${kind} is tracked by git`
    message = `${file.path} IS TRACKED BY GIT (confirmed via git ls-files), so its contents are in the repository history. Rotate every exposed secret and purge the file from history.`
    fixDescription = `git rm --cached ${file.path}, add it to .gitignore, purge it from history, and rotate every exposed secret`
  } else if (untrackedAndNotIgnored) {
    title = `${kind} is not ignored by git`
    message = `${file.path} is untracked but not ignored. If committed, its contents enter repository history.`
    fixDescription = `Add ${file.path} to .gitignore, confirm with 'git check-ignore ${file.path}', and rotate any exposed secrets`
  } else if (ignoredScanReason === 'nested-repository') {
    title = `${kind} is inside a nested git repository`
    message = `${file.path} belongs to a nested git repository (its top level differs from the app's), so this app's ignore rules don't protect it and it was scanned.`
    fixDescription = `Ignore ${file.path} in the nested repository and rotate any exposed secrets`
  } else if (ignoredScanReason === 'listing-failed') {
    title = `${kind} is ignored by git but was scanned`
    message = `${file.path} is ignored by git, but the app security check could not list the ignored files for this app, so it was scanned.`
    fixDescription = `Confirm the repository is healthy with 'git status' and rotate any exposed secrets`
  } else if (untrackedAndIgnored) {
    title = `${kind} is ignored by git but was scanned`
    message = `${file.path} is ignored by git but was still scanned; the app security check couldn't determine why. Confirm the rule ignoring it belongs to the repository that owns this app before treating this as clean.`
    fixDescription = `Confirm with 'git check-ignore -v ${file.path}' that this app's repository ignores it, and rotate any exposed secrets`
  } else {
    title = `${kind} could not be confirmed as ignored`
    message = `${file.path} could not be confirmed as untracked-and-ignored${status.reason ? ` (${status.reason})` : ''}. Confirm it is gitignored before treating this as clean.`
    fixDescription = `Add ${file.path} to .gitignore, confirm with 'git ls-files ${file.path}', and rotate any exposed secrets`
  }

  return {
    id: 'COMMITTED_SECRET',
    pattern_id: `${environmentFile ? 'environment-file' : 'secret-file'}:${tracked ? 'tracked' : 'unconfirmed'}`,
    severity: 'high',
    points: -50,
    title,
    message,
    location: {file: file.path},
    detection_evidence: status.evidence,
    fix: {
      automated: false,
      description: fixDescription,
    },
  }
}

/** Rule 8: COMMITTED_SECRET (-50, high) */
export async function scanCommittedSecrets(
  secretEvidenceFiles: SourceFile[],
  appRoot: string,
  gitIgnoreListing: ScanContext['gitIgnoreListing'],
): Promise<Issue[]> {
  const issues: Issue[] = []

  // Resolved lazily, once: most scans never need it.
  let appTopLevel: Promise<string | undefined> | undefined
  const appRootTopLevel = () => {
    appTopLevel ??= gitTopLevel(appRoot)
    return appTopLevel
  }

  for (const file of secretEvidenceFiles) {
    const content = file.content
    if (content === undefined) continue
    const environmentFile = isEnvFile(file.path)
    const namedSecretFile = NAMED_SECRET_FILE_PATTERN.test(file.path)
    if (!environmentFile && !namedSecretFile) continue

    // Only a recognizable Shopify secret value is evidence. A secret-sounding
    // variable or key name proves nothing (see SHOPIFY_SECRET_PATTERNS).
    const hasEvidence = SHOPIFY_SECRET_PATTERNS.some((pattern) => pattern.regex.test(content))
    const emptyNamedSecret = namedSecretFile && content.trim() === ''
    if (!hasEvidence && !emptyNamedSecret) continue

    // Keep git probes sequential to avoid spawning competing processes for one repository.
    // eslint-disable-next-line no-await-in-loop
    const status = await gitStatusFor(file)
    // Empty named secret files stay fail-closed only when git confirms they are
    // tracked — history may still contain prior secrets. Unknown git plus empty
    // contents is not a provable leak.
    if (!hasEvidence) {
      if (emptyNamedSecret && status.tracked === true) {
        issues.push(committedSecretFileIssue(file, status, environmentFile, 'unknown'))
      }
      continue
    }
    let ignoredScanReason: IgnoredFileScanReason = 'unknown'
    let evidence = status.evidence ?? []
    if (status.tracked === false && status.ignored === true) {
      // With --no-git-ignore the file was scanned only because filtering was off, and Git still protects it.
      if (gitIgnoreListing === 'git-ignore-off') continue
      // eslint-disable-next-line no-await-in-loop
      const scanReason = await ignoredFileScanReason(file, gitIgnoreListing, appRootTopLevel)
      ignoredScanReason = scanReason.reason
      evidence = [...evidence, ...scanReason.evidence]
    }
    issues.push(committedSecretFileIssue(file, {...status, evidence}, environmentFile, ignoredScanReason))
  }

  for (const file of secretEvidenceFiles) {
    if (!file.content || isSecretFile(file.path)) continue

    const lines = file.content.split('\n')
    for (const [index, line] of lines.entries()) {
      for (const pattern of SHOPIFY_SECRET_PATTERNS) {
        // Patterns are non-global so `.test()` has no lastIndex state to leak
        // between iterations. Do not add the /g flag here.
        if (!pattern.regex.test(line)) continue
        issues.push({
          id: 'COMMITTED_SECRET',
          pattern_id: pattern.name,
          severity: 'high',
          points: -50,
          title: `Hardcoded ${pattern.name} detected`,
          message: `A ${pattern.name} pattern was found in repository text. Never hardcode secrets — use environment variables.`,
          location: {file: file.path, line: index + 1},
          snippet: redactMatch(line, pattern),
          fix: {
            automated: false,
            description: 'Move the secret to an environment variable and rotate it immediately',
          },
        })
      }
    }
  }

  return issues
}

/**
 * Ask git directly whether a file is tracked and whether it is ignored.
 *
 * Hand-parsing .gitignore cannot answer either question correctly:
 *   - Presence in .gitignore does NOT imply the file is untracked. A file
 *     committed before being ignored stays tracked, and its secrets stay in
 *     history. That is the most common real-world leak, and the previous
 *     hand-rolled check downgraded exactly that case from high to medium.
 *   - Real gitignore semantics include negation (!pattern), directory scoping,
 *     nested .gitignore files, ** globs and precedence rules. A substring and
 *     trailing-* check gets all of them wrong.
 *
 * `tracked`/`ignored` are tri-state: `undefined` means "could not determine"
 * (not a repo, or a git command failed). Callers MUST treat undefined as unsafe.
 * Missing or unsupported Git aborts the scan instead.
 */
interface GitFileStatus {
  /** true = git tracks it, false = git confirms untracked, undefined = unknown */
  tracked?: boolean
  /** true = git confirms ignored, false = not ignored, undefined = unknown */
  ignored?: boolean
  /** Why the status is unknown, when it is. */
  reason?: string
  /** Commands run and their verdicts, for the trace. */
  evidence?: string[]
}

/** A failed probe is unknown status, not proof the file is safe. */
async function gitProbe(cwd: string, args: string[]): Promise<{exitCode?: number; out: string}> {
  const result = await runGit(cwd, args)
  return {exitCode: result?.exitCode, out: result?.stdout.trim() ?? ''}
}

/** Asks the file's own repository, which may differ from the app's: a scan directory can be another repository. */
export async function gitStatusFor(file: Pick<SourceFile, 'path' | 'absolutePath'>): Promise<GitFileStatus> {
  const run = async (args: string[]) => gitProbe(dirname(file.absolutePath), args)
  const name = basename(file.absolutePath)

  // Is this even a git repo? If not, we cannot confirm anything.
  const inRepo = await run(['rev-parse', '--is-inside-work-tree'])
  if (inRepo.exitCode !== 0 || inRepo.out !== 'true') {
    return {
      tracked: undefined,
      ignored: undefined,
      reason: 'not a git repository, or git unavailable',
      evidence: ['git rev-parse --is-inside-work-tree → not a work tree'],
    }
  }

  const evidence: string[] = []

  // Exit 1 is git's conclusive "no match" result. Any other failure remains
  // unknown instead of being silently interpreted as an untracked file.
  const ls = await run(['ls-files', '--error-unmatch', '--', name])
  let tracked: boolean | undefined
  if (ls.exitCode === 0 && ls.out.length > 0) tracked = true
  else if (ls.exitCode === 1) tracked = false
  let trackedVerdict = 'unknown'
  if (tracked === true) trackedVerdict = 'TRACKED'
  else if (tracked === false) trackedVerdict = 'untracked'
  evidence.push(`git ls-files --error-unmatch ${file.path} → ${trackedVerdict}`)

  // check-ignore likewise defines 0 as ignored and 1 as conclusively not
  // ignored. Exit codes above 1 are command errors and must fail closed.
  const checkIgnore = await run(['check-ignore', '-q', '--', name])
  let ignored: boolean | undefined
  if (checkIgnore.exitCode === 0) ignored = true
  else if (checkIgnore.exitCode === 1) ignored = false
  let ignoredVerdict = 'unknown'
  if (ignored === true) ignoredVerdict = 'ignored'
  else if (ignored === false) ignoredVerdict = 'not ignored'
  evidence.push(`git check-ignore -q ${file.path} → ${ignoredVerdict}`)

  return {
    tracked,
    ignored,
    ...(tracked === undefined || ignored === undefined ? {reason: 'git status command failed'} : {}),
    evidence,
  }
}
