import {FunctionRunLog, ErrorResponse, AppLogData} from './types.js'
import camelcaseKeys from './camelcase-keys.js'
import {DeveloperPlatformClient} from '../../utilities/developer-platform-client.js'
import {AppLogsSubscribeMutationVariables} from '../../api/graphql/app-management/generated/app-logs-subscribe.js'
import {outputDebug, outputWarn} from '@shopify/cli-kit/node/output'
import {AbortError} from '@shopify/cli-kit/node/error'
import {formatLocalDate} from '@shopify/cli-kit/common/string'
import {useConcurrentOutputContext} from '@shopify/cli-kit/node/ui/components'
import {Writable} from 'stream'

export const POLLING_INTERVAL_MS = 450
export const POLLING_ERROR_RETRY_INTERVAL_MS = 5 * 1000
const POLLING_THROTTLE_RETRY_INTERVAL_MS = 60 * 1000
export const MAX_CONSECUTIVE_RESUBSCRIBE_FAILURES = 5
export const ONE_MILLION = 1000000
export const LOG_TYPE_FUNCTION_RUN = 'function_run'
export const LOG_TYPE_FUNCTION_NETWORK_ACCESS = 'function_network_access'
export const LOG_TYPE_RESPONSE_FROM_CACHE = 'function_network_access.response_from_cache'
export const LOG_TYPE_REQUEST_EXECUTION_IN_BACKGROUND = 'function_network_access.request_execution_in_background'
export const LOG_TYPE_REQUEST_EXECUTION = 'function_network_access.request_execution'
export const REQUEST_EXECUTION_IN_BACKGROUND_NO_CACHED_RESPONSE_REASON = 'no_cached_response'
export const REQUEST_EXECUTION_IN_BACKGROUND_CACHE_ABOUT_TO_EXPIRE_REASON = 'cached_response_about_to_expire'

interface FetchAppLogsErrorOptions {
  response: ErrorResponse
  onThrottle: (retryIntervalMs: number) => void
  onUnknownError: (retryIntervalMs: number) => void
  onResubscribe: () => Promise<string>
}

export interface AppLogsOptions {
  jwtToken: string
  cursor?: string
  filters?: {
    status?: string
    source?: string
  }
}

type ResubscribeResult = 'succeeded' | 'failed' | 'not_attempted'

export const handleFetchAppLogsError = async (
  input: FetchAppLogsErrorOptions,
): Promise<{retryIntervalMs: number; nextJwtToken: string | null; resubscribeResult: ResubscribeResult}> => {
  const {errors} = input.response

  let retryIntervalMs = POLLING_INTERVAL_MS
  let nextJwtToken = null
  let resubscribeResult: ResubscribeResult = 'not_attempted'

  if (errors.length > 0) {
    outputDebug(`Errors: ${errors.map((error) => error.message).join(', ')}`)

    if (errors.some((error) => error.status === 401)) {
      try {
        nextJwtToken = await input.onResubscribe()
        resubscribeResult = 'succeeded'
        // eslint-disable-next-line no-catch-all/no-catch-all
      } catch (resubscribeError) {
        outputDebug(`Failed to resubscribe to app logs: ${resubscribeError}`)
        retryIntervalMs = POLLING_THROTTLE_RETRY_INTERVAL_MS
        resubscribeResult = 'failed'
        input.onThrottle(retryIntervalMs)
      }
    } else if (errors.some((error) => error.status === 429)) {
      retryIntervalMs = POLLING_THROTTLE_RETRY_INTERVAL_MS
      input.onThrottle(retryIntervalMs)
    } else {
      retryIntervalMs = POLLING_ERROR_RETRY_INTERVAL_MS
      input.onUnknownError(retryIntervalMs)
    }
  }

  return {retryIntervalMs, nextJwtToken, resubscribeResult}
}

export const toFormattedAppLogJson = ({
  appLog,
  appLogPayload,
  storeName,
  prettyPrint = true,
}: {
  appLog: AppLogData
  appLogPayload: unknown
  prettyPrint: boolean
  storeName: string
}): string => {
  const {cursor: _, ...appLogWithoutCursor} = appLog
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const toSaveData: any = camelcaseKeys({
    ...appLogWithoutCursor,
    payload: appLogPayload,
    localTime: formatLocalDate(appLog.log_timestamp),
    storeName,
  })

  if (appLogPayload instanceof FunctionRunLog) {
    toSaveData.payload.logs = appLogPayload.logs.split('\n').filter(Boolean)

    if (toSaveData.payload.inputQueryVariablesMetafieldValue) {
      toSaveData.payload.inputQueryVariablesMetafieldValue = parseJson(
        toSaveData.payload.inputQueryVariablesMetafieldValue,
      )
    }
  }

  if (prettyPrint) {
    return JSON.stringify(toSaveData, null, 2)
  } else {
    return JSON.stringify(toSaveData)
  }
}

export const subscribeToAppLogs = async (
  developerPlatformClient: DeveloperPlatformClient,
  variables: AppLogsSubscribeMutationVariables,
  organizationId: string,
  stdout?: Writable,
): Promise<string> => {
  // Now try the subscription with the fresh token
  const result = await developerPlatformClient.subscribeToAppLogs(variables, organizationId)

  if (!result.appLogsSubscribe) {
    throw new AbortError('Failed to subscribe to app logs: No response received')
  }

  const {jwtToken, success, errors} = result.appLogsSubscribe

  outputDebug(`Token: ${jwtToken}\n`)
  outputDebug(`API Key: ${variables.apiKey}\n`)

  if (errors && errors.length > 0) {
    const errorOutput = errors.join(', ')
    await useConcurrentOutputContext({stripAnsi: false}, () => {
      outputWarn(`Errors subscribing to app logs: ${errorOutput}`, stdout)
      outputWarn('App log streaming is not available in this session.', stdout)
    })
    throw new AbortError(errorOutput)
  } else {
    if (!jwtToken) {
      throw new AbortError('Failed to subscribe to app logs: No response received')
    }
    const shopIdsArray = Array.isArray(variables.shopIds) ? variables.shopIds : [variables.shopIds]
    outputDebug(`Subscribed to App Events for shop ID(s) ${shopIdsArray.join(', ')}`)
    if (success !== undefined) outputDebug(`Success: ${success}\n`)
  }

  return jwtToken
}

export function prettyPrintJsonIfPossible(json: unknown): string | undefined {
  try {
    if (typeof json === 'string') {
      const jsonObject = JSON.parse(json)
      return JSON.stringify(jsonObject, null, 2)
    } else if (typeof json === 'object' && json !== null) {
      return JSON.stringify(json, null, 2)
    } else {
      return undefined
    }
  } catch (error) {
    throw new Error(`Error parsing JSON: ${error as string}`)
  }
}

const parseJson = (json: string): object | string => {
  try {
    return JSON.parse(json)
    // eslint-disable-next-line no-catch-all/no-catch-all
  } catch (error) {
    return json
  }
}
