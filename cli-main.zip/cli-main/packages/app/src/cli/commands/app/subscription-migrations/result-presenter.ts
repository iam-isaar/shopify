import {encodeMigrationCancellationResult, encodeMigrationSubmissionResult} from './result-codec.js'
import {projectMigrationOperation} from '../../../services/subscription-migrations/result-codec.js'
import {AbortError} from '@shopify/cli-kit/node/error'
import {errorToJson} from '@shopify/cli-kit/node/error/serialization'
import {outputResult} from '@shopify/cli-kit/node/output'
import {renderInfo, renderSuccess, renderWarning} from '@shopify/cli-kit/node/ui'
import type {MigrationOperation} from '../../../models/subscription-migrations.js'
import type {
  MigrationCancellationOutcome,
  MigrationCancellationResult,
  MigrationSubmission,
  MigrationSubmissionResult,
} from '../../../services/subscription-migrations/types.js'

interface SubmissionPresentationOptions {
  json: boolean
  watch: boolean
}

interface CancellationPresentationOptions {
  json: boolean
}

export function presentAcceptedMigrationSubmission(submission: MigrationSubmission): void {
  renderSubmissionSuccess(submission)
}

export function presentMigrationSubmissionResult(
  result: MigrationSubmissionResult,
  options: SubmissionPresentationOptions,
): 0 | 1 {
  if (result.status === 'failed' && result.submission.operations.length === 0) {
    const message = [
      'Subscription migration submission failed.',
      ...(result.failure.type === 'submission' ? result.failure.userErrors.map(({message}) => message) : []),
    ].join('\n')
    const error = new AbortError(message)
    error.details =
      result.failure.type === 'submission'
        ? {
            batchIndex: result.failure.batchIndex,
            userErrors: result.failure.userErrors.map(({message, field}) => ({message, fieldPath: field})),
          }
        : {operationGids: result.failure.operationIds}
    throw error
  }
  if (result.status === 'cancelled') {
    if (options.json) outputResult(encodeMigrationSubmissionResult(result))
    return 0
  }
  if (options.json) {
    outputResult(encodeMigrationSubmissionResult(result))
  } else if (result.status === 'failed') {
    renderSubmissionFailure(result)
  } else if (options.watch) {
    renderInfo({
      headline: 'Subscription migration operations.',
      body: result.submission.operations.map(({operation}) => formatMigrationOperationStatus(operation)),
    })
  } else {
    renderSubmissionSuccess(result.submission)
  }

  return result.status === 'failed' ? 1 : 0
}

export function presentMigrationCancellationResult(
  result: MigrationCancellationResult,
  options: CancellationPresentationOptions,
): 0 | 1 {
  const outcome = result.outcomes[0]
  if (result.outcomes.length === 1 && outcome?.status === 'failed') {
    if ('error' in outcome) throw outcome.error
    const error = new AbortError(outcome.userErrors.map(({message}) => message).join('; '))
    error.details = {
      operationGid: outcome.operationId,
      operation: outcome.operation === null ? null : projectMigrationOperation(outcome.operation),
      userErrors: outcome.userErrors.map(({message, field}) => ({message, fieldPath: field})),
    }
    throw error
  }
  const hasFailures = result.outcomes.some(({status}) => status === 'failed')

  if (options.json) {
    outputResult(encodeMigrationCancellationResult(result))
  } else if (hasFailures) {
    renderWarning({
      headline: 'Some subscription migration operations could not be canceled.',
      body: formatCancellationOutcomes(result.outcomes),
    })
  } else {
    renderSuccess({
      headline: 'Subscription migration operations canceled.',
      body: formatCancellationOutcomes(result.outcomes),
    })
  }

  return hasFailures ? 1 : 0
}

function renderSubmissionSuccess(submission: MigrationSubmission): void {
  const action = submission.action === 'schedule' ? 'scheduled' : 'unscheduled'
  renderSuccess({
    headline: `Subscription migrations ${action}.`,
    body: [
      `Shops: ${submission.total}`,
      'Operation IDs:',
      ...submission.operations.map(({operation}) => operation.id),
      'Save every operation ID. You will need them to check or cancel this submission.',
    ],
  })
}

function renderSubmissionFailure(result: Extract<MigrationSubmissionResult, {status: 'failed'}>): void {
  if (result.failure.type === 'operations') {
    renderWarning({
      headline: 'Some subscription migration operations failed.',
      body: [
        'Failed operation IDs:',
        ...result.failure.operationIds,
        'Terminal operation outcomes:',
        ...result.submission.operations.map(({operation}) => formatMigrationOperationStatus(operation)),
        'Save every operation ID. You will need them to inspect this submission.',
      ],
    })
    return
  }

  const operationIds = result.submission.operations.map(({operation}) => operation.id)
  renderWarning({
    headline:
      operationIds.length === 0
        ? 'Subscription migration submission failed.'
        : 'Some subscription migration operations were accepted before submission failed.',
    body: [
      ...(operationIds.length === 0 ? ['Accepted operation IDs: None.'] : ['Accepted operation IDs:', ...operationIds]),
      `Batch index: ${result.failure.batchIndex}`,
      'Errors:',
      ...result.failure.userErrors.map(({message}) => message),
      ...(operationIds.length === 0
        ? []
        : ['Save every accepted operation ID. You will need them to check or cancel accepted operations.']),
    ],
  })
}

function formatCancellationOutcomes(outcomes: MigrationCancellationOutcome[]): string[] {
  const successes = outcomes.filter(
    (outcome): outcome is Extract<MigrationCancellationOutcome, {status: 'success'}> => outcome.status === 'success',
  )
  const failures = outcomes.filter(
    (outcome): outcome is Extract<MigrationCancellationOutcome, {status: 'failed'}> => outcome.status === 'failed',
  )

  return [
    ...(successes.length === 0
      ? ['Canceled operations: None.']
      : ['Canceled operations:', ...successes.map(({operation}) => formatMigrationOperationStatus(operation))]),
    ...(failures.length === 0
      ? []
      : [
          'Failed operations:',
          ...failures.map((outcome) => {
            const returnedStatus = outcome.operation ? ` (returned status: ${outcome.operation.status})` : ''
            const message =
              'error' in outcome
                ? errorToJson(outcome.error).message
                : outcome.userErrors.map(({message}) => message).join('; ')
            return `${outcome.operationId}: ${message}${returnedStatus}`
          }),
        ]),
  ]
}

function formatMigrationOperationStatus(operation: MigrationOperation): string {
  return `${operation.id}: ${operation.status} (${operation.results.edges.length}/${operation.total} settled)`
}
