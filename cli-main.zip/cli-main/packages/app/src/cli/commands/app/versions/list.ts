import {appFlags} from '../../../flags.js'
import {appVersionsListJsonOutputSchema} from '../../../services/versions-list/types.js'
import {getAppVersions} from '../../../services/versions-list.js'
import {renderAppVersionsListResult} from '../../../services/versions-list/result.js'
import AppLinkedCommand, {AppLinkedCommandOutput} from '../../../utilities/app-linked-command.js'
import {linkedAppContext} from '../../../services/app-context.js'
import {globalFlags, jsonFlag} from '@shopify/cli-kit/node/cli'

export default class VersionsList extends AppLinkedCommand {
  static summary = 'List deployed versions of your app.'

  static descriptionWithMarkdown = `Lists the deployed app versions. An app version is a snapshot of your app extensions.`

  static jsonOutputSchema = appVersionsListJsonOutputSchema

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...appFlags,
    ...jsonFlag,
  }

  public async run(): Promise<AppLinkedCommandOutput> {
    const {flags} = await this.parse(VersionsList)

    const {app, remoteApp, developerPlatformClient, organization} = await linkedAppContext({
      directory: flags.path,
      clientId: flags['client-id'],
      forceRelink: flags.reset,
      userProvidedConfigName: flags.config,
    })

    const result = await getAppVersions(developerPlatformClient, remoteApp)

    await renderAppVersionsListResult(
      {
        app,
        remoteApp,
        organization,
        developerPlatformClient,
        ...result,
      },
      flags.json ? 'json' : 'text',
    )

    return {app}
  }
}
