import {appFlags} from '../../../flags.js'
import AppLinkedCommand, {AppLinkedCommandOutput} from '../../../utilities/app-linked-command.js'
import {prepareAppStoreContext} from '../../../utilities/execute-command-helpers.js'
import {getBulkOperationStatus, listBulkOperations} from '../../../services/bulk-operations/bulk-operation-status.js'
import {bulkOperationStatusJsonOutputSchema} from '../../../services/bulk-operations/types.js'
import {renderBulkOperationStatusResult} from '../../../services/bulk-operations/status-result.js'
import {logBulkOperationStart} from '../../../services/bulk-operations/progress.js'
import {Flags} from '@oclif/core'
import {globalFlags, jsonFlag} from '@shopify/cli-kit/node/cli'
import {normalizeBulkOperationId} from '@shopify/cli-kit/node/api/bulk-operations'
import {normalizeStoreFqdn} from '@shopify/cli-kit/node/context/fqdn'

export default class BulkStatus extends AppLinkedCommand {
  static summary = 'Check the status of bulk operations.'

  static descriptionWithMarkdown = `Check the status of a specific bulk operation by ID, or list all bulk operations belonging to this app on this store in the last 7 days.

  Bulk operations allow you to process large amounts of data asynchronously. Learn more about [bulk query operations](https://shopify.dev/docs/api/usage/bulk-operations/queries) and [bulk mutation operations](https://shopify.dev/docs/api/usage/bulk-operations/imports).

  Use [\`bulk execute\`](https://shopify.dev/docs/api/shopify-cli/app/app-bulk-execute) to start a new bulk operation.`

  static jsonOutputSchema = bulkOperationStatusJsonOutputSchema

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...jsonFlag,
    ...appFlags,
    id: Flags.string({
      description:
        'The bulk operation ID (numeric ID or full GID). If not provided, lists all bulk operations belonging to this app on this store in the last 7 days.',
      env: 'SHOPIFY_FLAG_ID',
    }),
    store: Flags.string({
      char: 's',
      description: 'The store domain. Must be an existing dev store.',
      env: 'SHOPIFY_FLAG_STORE',
      parse: async (input) => normalizeStoreFqdn(input),
    }),
  }

  async run(): Promise<AppLinkedCommandOutput> {
    const {flags} = await this.parse(BulkStatus)

    const {appContextResult, store} = await prepareAppStoreContext(flags)
    const format = flags.json ? 'json' : 'text'
    logBulkOperationStart(
      flags.id ? 'Checking bulk operation status.' : 'Listing bulk operations.',
      {
        organization: appContextResult.organization,
        remoteApp: appContextResult.remoteApp,
        storeFqdn: store.shopDomain,
      },
      format,
    )
    const options = {storeFqdn: store.shopDomain, remoteApp: appContextResult.remoteApp}
    const result = flags.id
      ? await getBulkOperationStatus({...options, operationId: normalizeBulkOperationId(flags.id)})
      : await listBulkOperations(options)
    renderBulkOperationStatusResult(result, format)

    return {app: appContextResult.app}
  }
}
