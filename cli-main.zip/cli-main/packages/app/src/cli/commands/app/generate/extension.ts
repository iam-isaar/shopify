import {appFlags} from '../../../flags.js'
import metadata from '../../../metadata.js'
import generate from '../../../services/generate.js'
import {extensionFlavorValues} from '../../../services/generate/extension.js'
import {appGenerateExtensionJsonOutputSchema} from '../../../services/generate/extension/types.js'
import {renderGenerateExtensionResult} from '../../../services/generate/extension/result.js'
import {checkFolderIsValidApp} from '../../../models/app/loader.js'
import AppLinkedCommand, {AppLinkedCommandOutput} from '../../../utilities/app-linked-command.js'
import {linkedAppContext} from '../../../services/app-context.js'
import {Flags} from '@oclif/core'
import {globalFlags, jsonFlag, requiredIfNonInteractive} from '@shopify/cli-kit/node/cli'

export default class AppGenerateExtension extends AppLinkedCommand {
  static summary = 'Generate a new app Extension.'

  static descriptionWithMarkdown = `Generates a new [app extension](https://shopify.dev/docs/apps/build/app-extensions). For a list of app extensions that you can generate using this command, refer to [Supported extensions](https://shopify.dev/docs/apps/build/app-extensions/list-of-app-extensions).

  Each new app extension is created in a folder under \`extensions/\`. To learn more about the extensions file structure, refer to [App structure](https://shopify.dev/docs/apps/build/cli-for-apps/app-structure) and the documentation for your extension.
  `

  static jsonOutputSchema = appGenerateExtensionJsonOutputSchema

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...appFlags,
    ...jsonFlag,
    template: requiredIfNonInteractive(
      Flags.string({
        char: 't',
        hidden: false,
        description: `Extension template`,
        env: 'SHOPIFY_FLAG_EXTENSION_TEMPLATE',
      }),
    ),
    name: requiredIfNonInteractive(
      Flags.string({
        char: 'n',
        hidden: false,
        description: 'name of your Extension',
        env: 'SHOPIFY_FLAG_NAME',
      }),
    ),
    'clone-url': Flags.string({
      hidden: true,
      char: 'u',
      description:
        'The Git URL to clone the function extensions templates from. Defaults to: https://github.com/Shopify/function-examples',
      env: 'SHOPIFY_FLAG_CLONE_URL',
    }),
    flavor: Flags.string({
      hidden: false,
      description:
        'Choose a starting template for your extension, where applicable. Supported flavors depend on the selected extension template. Required if non interactive when the selected extension template supports multiple flavors.',
      options: [...extensionFlavorValues],
      env: 'SHOPIFY_FLAG_FLAVOR',
    }),
  }

  public async run(): Promise<AppLinkedCommandOutput> {
    const {flags} = await this.parse(AppGenerateExtension)

    await metadata.addPublicMetadata(() => ({
      cmd_scaffold_required_auth: true,
      cmd_scaffold_template_custom: flags['clone-url'] !== undefined,
      cmd_scaffold_type_owner: '@shopify/app',
    }))

    await checkFolderIsValidApp(flags.path)

    const {app, project, specifications, remoteApp, developerPlatformClient} = await linkedAppContext({
      directory: flags.path,
      clientId: flags['client-id'],
      forceRelink: flags.reset,
      userProvidedConfigName: flags.config,
    })

    const result = await generate({
      directory: flags.path,
      reset: flags.reset,
      name: flags.name,
      cloneUrl: flags['clone-url'],
      template: flags.template,
      flavor: flags.flavor,
      app,
      project,
      specifications,
      remoteApp,
      developerPlatformClient,
    })
    renderGenerateExtensionResult(result, flags.json)

    return {app}
  }
}
