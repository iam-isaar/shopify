import FunctionReplay from './replay.js'
import {chooseFunction} from '../../../services/function/common.js'
import {linkedAppContext} from '../../../services/app-context.js'
import {testAppLinked, testFunctionExtension} from '../../../models/app/app.test-data.js'
import {renderReplay} from '../../../services/function/ui.js'
import {selectFunctionRunPrompt} from '../../../prompts/function/replay.js'
import {functionRunJsonOutputSchema} from '../../../services/function/runner/types.js'
import {functionReplayJsonOutputSchema} from '../../../services/function/replay/types.js'
import {watchReplay} from '../../../services/function/replay/watch.js'
import {AppEventWatcher} from '../../../services/dev/app-events/app-event-watcher.js'
import {Config} from '@oclif/core'
import {afterEach, expect, test, vi} from 'vitest'
import {captureOutputWithExitCode, exec, terminalSupportsPrompting} from '@shopify/cli-kit/node/system'
import {inTemporaryDirectory, mkdir, writeFile} from '@shopify/cli-kit/node/fs'
import {joinPath} from '@shopify/cli-kit/node/path'
import {withCapturedStandardStreams} from '@shopify/cli-kit/node/testing/output'
import {runWithCommandEventsForCommand} from '@shopify/cli-kit/node/command-events'
import {isTerminalInteractive} from '@shopify/cli-kit/node/context/local'

vi.mock('../../../services/app-context.js')
vi.mock('@shopify/cli-kit/node/system')
vi.mock('../../../services/function/ui.js')
vi.mock('../../../services/function/replay/watch.js')
vi.mock('../../../prompts/function/replay.js')
vi.mock('../../../services/function/common.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/function/common.js')>()),
  chooseFunction: vi.fn(),
}))
vi.mock('../../../services/function/binaries.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/function/binaries.js')>()),
  downloadBinary: vi.fn(),
}))
vi.mock('@shopify/cli-kit/node/context/local', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@shopify/cli-kit/node/context/local')>()),
  isTerminalInteractive: vi.fn(),
}))

afterEach(() => vi.unstubAllEnvs())

const nativeResult = {
  name: 'function.wasm',
  size: 1,
  memory_usage: 64,
  instructions: 1000,
  logs: '',
  input: {native_key: true},
  output: {operations: []},
  success: true,
}

async function command(argv: string[], directory: string) {
  const app = testAppLinked({directory})
  const extension = await testFunctionExtension({dir: directory})
  vi.mocked(linkedAppContext).mockResolvedValue({app} as Awaited<ReturnType<typeof linkedAppContext>>)
  vi.mocked(chooseFunction).mockResolvedValue(extension)
  await mkdir(app.getLogsDir())
  await writeFile(
    joinPath(app.getLogsDir(), `20240522_150641_827Z_extensions_${extension.handle}_abcdef.json`),
    JSON.stringify({payload: {input: nativeResult.input, export: 'run'}}),
  )
  return new FunctionReplay(argv, await Config.load())
}

test('replays a saved log through native validation and the output writer', async () => {
  await inTemporaryDirectory(async (directory) => {
    vi.mocked(captureOutputWithExitCode).mockResolvedValue({
      stdout: JSON.stringify(nativeResult),
      stderr: 'Runner warning',
      exitCode: 0,
    })
    const instance = await command(['--json', '--no-watch', '--log', 'abcdef'], directory)
    await withCapturedStandardStreams(async ({stdout, stderr}) => {
      await runWithCommandEventsForCommand(instance.argv, () => instance.run())
      expect(JSON.parse(stdout())).toEqual(nativeResult)
      expect(JSON.parse(stderr())).toMatchObject({type: 'diagnostic', message: 'Runner warning'})
    })
    expect(captureOutputWithExitCode).toHaveBeenCalledWith(
      expect.any(String),
      expect.arrayContaining(['--json', '--export', 'run']),
      expect.objectContaining({input: JSON.stringify(nativeResult.input)}),
    )
    expect(renderReplay).not.toHaveBeenCalled()
    expect(selectFunctionRunPrompt).not.toHaveBeenCalled()
  })
})

test('preserves native numeric tokens in finite replay output', async () => {
  await inTemporaryDirectory(async (directory) => {
    const nativeJson = `{"name":"function.wasm","size":1,"memory_usage":64,"instructions":1000,"logs":"",
"input":{"nested":[9007199254740993]},
"output":{"nested":[9007199254740993,0.12345678901234567890123456789]},"success":true}`
    vi.mocked(captureOutputWithExitCode).mockResolvedValue({stdout: nativeJson, stderr: '', exitCode: 0})
    const instance = await command(['--json', '--no-watch', '--log', 'abcdef'], directory)
    await withCapturedStandardStreams(async ({stdout, stderr}) => {
      await runWithCommandEventsForCommand(instance.argv, () => instance.run())
      expect(stdout()).toBe(`${nativeJson}\n`)
      expect(stderr()).toBe('')
    })
  })
})

test.each([{argv: ['--json', '--log', 'abcdef']}, {argv: ['--json', '--watch', '--log', 'abcdef']}])(
  'streams JSON watch mode: $argv',
  async ({argv}) => {
    await inTemporaryDirectory(async (directory) => {
      const instance = await command(argv, directory)
      await instance.run()
      expect(watchReplay).toHaveBeenCalledOnce()
      expect(renderReplay).not.toHaveBeenCalled()
      expect(captureOutputWithExitCode).not.toHaveBeenCalled()
    })
  },
)

test('keeps the default text watch workflow', async () => {
  await inTemporaryDirectory(async (directory) => {
    const instance = await command(['--log', 'abcdef'], directory)
    await instance.run()
    expect(renderReplay).toHaveBeenCalledOnce()
    expect(captureOutputWithExitCode).not.toHaveBeenCalled()
  })
})

test.each([
  {signal: 'SIGINT' as const, exitCode: 130},
  {signal: 'SIGTERM' as const, exitCode: 143},
  {signal: 'SIGQUIT' as const, exitCode: 131},
])(
  'writes watch records and cleans up on $signal through the command and real output writer',
  async ({signal, exitCode}) => {
    await inTemporaryDirectory(async (directory) => {
      const {watchReplay: realWatchReplay} = await vi.importActual<
        typeof import('../../../services/function/replay/watch.js')
      >('../../../services/function/replay/watch.js')
      vi.mocked(watchReplay).mockImplementation(realWatchReplay)
      vi.spyOn(AppEventWatcher.prototype, 'start').mockResolvedValue(undefined)
      const processEvents: NodeJS.EventEmitter = process
      vi.mocked(captureOutputWithExitCode).mockImplementation(async () => {
        setImmediate(() => processEvents.emit('shopify:signal', signal))
        return {stdout: JSON.stringify(nativeResult), stderr: 'Runner warning', exitCode: 0}
      })
      const previousExitCode = process.exitCode
      const instance = await command(['--json', '--no-input', '--log', 'abcdef'], directory)
      try {
        await withCapturedStandardStreams(async ({stdout, stderr}) => {
          await runWithCommandEventsForCommand(instance.argv, () => instance.run())
          expect(
            stdout()
              .trim()
              .split('\n')
              .map((line) => JSON.parse(line)),
          ).toEqual([
            expect.objectContaining({type: 'status', status: 'watching'}),
            expect.objectContaining({type: 'execution', result: nativeResult, exitCode: 0}),
            expect.objectContaining({type: 'status', status: 'cancelled'}),
          ])
          expect(JSON.parse(stderr())).toMatchObject({type: 'diagnostic', message: 'Runner warning'})
          expect(process.exitCode).toBe(exitCode)
        })
      } finally {
        // The signal handler runs inside this test; restore the worker's exit status.
        // eslint-disable-next-line require-atomic-updates
        process.exitCode = previousExitCode
      }
    })
  },
)

test('captures finite text replay and preserves native output', async () => {
  await inTemporaryDirectory(async (directory) => {
    const nativeText = '  Function output:\n{ operations: [] }\n'
    const nativeStderr = 'Runner warning\n'
    vi.mocked(captureOutputWithExitCode).mockImplementation(async (_command, _args, options) => {
      if (options?.stderr && options.stderr !== 'inherit') options.stderr.write(nativeStderr)
      if (options?.stdout && options.stdout !== 'inherit') options.stdout.write(nativeText)
      return {stdout: nativeText, stderr: nativeStderr, exitCode: 0}
    })
    const instance = await command(['--no-watch', '--log', 'abcdef'], directory)
    await withCapturedStandardStreams(async ({stdout, stderr}) => {
      await instance.run()
      expect(stdout()).toBe(nativeText)
      expect(stderr()).toBe(nativeStderr)
    })
    expect(captureOutputWithExitCode).toHaveBeenCalledWith(
      expect.any(String),
      expect.not.arrayContaining(['--json']),
      expect.objectContaining({input: JSON.stringify(nativeResult.input)}),
    )
    expect(exec).not.toHaveBeenCalled()
  })
})

test('rejects a missing saved log without writing a result', async () => {
  await inTemporaryDirectory(async (directory) => {
    const instance = await command(['--json', '--no-watch', '--log', 'missing'], directory)
    await withCapturedStandardStreams(async ({stdout}) => {
      await expect(instance.run()).rejects.toThrow('No log found')
      expect(stdout()).toBe('')
    })
    expect(captureOutputWithExitCode).not.toHaveBeenCalled()
  })
})

test('allows JSON replay to select a log interactively', async () => {
  await inTemporaryDirectory(async (directory) => {
    vi.mocked(isTerminalInteractive).mockReturnValue(true)
    vi.mocked(terminalSupportsPrompting).mockReturnValue(true)
    vi.mocked(selectFunctionRunPrompt).mockImplementation(async (runs) => runs[0])
    vi.mocked(captureOutputWithExitCode).mockResolvedValue({
      stdout: JSON.stringify(nativeResult),
      stderr: '',
      exitCode: 0,
    })
    const instance = await command(['--json', '--no-watch'], directory)
    await runWithCommandEventsForCommand(instance.argv, () => instance.run())
    expect(selectFunctionRunPrompt).toHaveBeenCalledOnce()
  })
})

test('requires --log when --no-input is enabled', async () => {
  vi.stubEnv('SHOPIFY_FLAG_NO_INPUT', '1')
  const instance = new FunctionReplay(['--json', '--no-watch', '--no-input'], await Config.load())
  await expect(instance.run()).rejects.toThrow('log')
  expect(selectFunctionRunPrompt).not.toHaveBeenCalled()
})

test('discovers finite and streaming schemas and preserves synchronous analytics', () => {
  expect(FunctionReplay.jsonOutputSchema).toBe(functionReplayJsonOutputSchema)
  expect(functionReplayJsonOutputSchema.validate(nativeResult)).toEqual(
    functionRunJsonOutputSchema.validate(nativeResult),
  )
  expect(FunctionReplay.descriptionForHelp()).toContain('FunctionRunResult')
  expect(FunctionReplay.requiresSyncAnalytics).toBe(true)
})
