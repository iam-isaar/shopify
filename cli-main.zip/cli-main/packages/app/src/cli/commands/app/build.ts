import {appFlags} from '../../flags.js'
import build from '../../services/build.js'
import {appBuildJsonOutputSchema} from '../../services/build/types.js'
import {presentAppBuildResult} from '../../services/build/presenter.js'
import {localAppContext} from '../../services/app-context.js'
import AppUnlinkedCommand, {AppUnlinkedCommandOutput} from '../../utilities/app-unlinked-command.js'
import {AbortError, AbortSilentError} from '@shopify/cli-kit/node/error'
import {Flags} from '@oclif/core'
import {globalFlags, jsonFlag} from '@shopify/cli-kit/node/cli'
import {addPublicMetadata} from '@shopify/cli-kit/node/metadata'

export default class Build extends AppUnlinkedCommand {
  static summary = 'Build the app, including extensions.'

  static descriptionWithMarkdown = `This command executes the build script specified in the element's TOML file. You can specify a custom script in the file. To learn about configuration files in Shopify apps, refer to [App configuration](https://shopify.dev/docs/apps/tools/cli/configuration).

  If you're building a [theme app extension](https://shopify.dev/docs/apps/online-store/theme-app-extensions), then running the \`build\` command runs [Theme Check](https://shopify.dev/docs/themes/tools/theme-check) against your extension to ensure that it's valid.`

  static jsonOutputSchema = appBuildJsonOutputSchema

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...appFlags,
    ...jsonFlag,
    'skip-dependencies-installation': Flags.boolean({
      hidden: false,
      description: 'Skips the installation of dependencies. Deprecated, use workspaces instead.',
      env: 'SHOPIFY_FLAG_SKIP_DEPENDENCIES_INSTALLATION',
      default: false,
    }),
  }

  async run(): Promise<AppUnlinkedCommandOutput> {
    const {flags} = await this.parse(Build)
    const clientId = flags['client-id']

    await addPublicMetadata(() => ({
      cmd_app_dependency_installation_skipped: flags['skip-dependencies-installation'],
    }))

    const {app, project} = await localAppContext({
      directory: flags.path,
      userProvidedConfigName: flags.config,
    })

    try {
      const result = await build({
        app,
        project,
        skipDependenciesInstallation: flags['skip-dependencies-installation'],
        apiKey: clientId,
      })
      presentAppBuildResult(result, flags.json)
    } catch (error) {
      if (flags.json && error instanceof AbortSilentError) {
        // Builders can stop after reporting diagnostics; JSON still needs a fatal result document.
        throw new AbortError('The app build did not complete. See the build diagnostics for details.')
      }
      throw error
    }

    return {app}
  }
}
