import initPrompt, {
  isPredefinedTemplate,
  templates,
  templateRequiresFlavor,
  visibleTemplates,
} from '../../prompts/init/init.js'
import initService from '../../services/init/init.js'
import {appInitJsonOutputSchema} from '../../services/init/types.js'
import {renderInitResult} from '../../services/init/result.js'
import {defaultDeveloperPlatformClient, DeveloperPlatformClient} from '../../utilities/developer-platform-client.js'
import {appFromIdentifiers, selectOrg} from '../../services/context.js'
import {fetchOrgFromId} from '../../services/dev/fetch.js'
import AppLinkedCommand, {AppLinkedCommandOutput} from '../../utilities/app-linked-command.js'
import {validateFlavorValue, validateTemplateValue} from '../../services/init/validate.js'
import {MinimalOrganizationApp, Organization, OrganizationApp} from '../../models/organization.js'
import {appNamePrompt, createAsNewAppPrompt, selectAppPrompt} from '../../prompts/dev.js'
import {searchForAppsByNameFactory} from '../../services/dev/prompt-helpers.js'
import {isValidName} from '../../models/app/validation/common.js'
import {Flags} from '@oclif/core'
import {globalFlags, jsonFlag, requiredIfNonInteractive} from '@shopify/cli-kit/node/cli'
import {resolvePath, cwd} from '@shopify/cli-kit/node/path'
import {addPublicMetadata} from '@shopify/cli-kit/node/metadata'

import {installGlobalShopifyCLI} from '@shopify/cli-kit/node/is-global'
import {generateRandomNameForSubdirectory} from '@shopify/cli-kit/node/fs'
import {inferPackageManager} from '@shopify/cli-kit/node/node-package-manager'
import {AbortError} from '@shopify/cli-kit/node/error'
import {renderWarning} from '@shopify/cli-kit/node/ui'
import type {NonTTYFlagRequirement} from '@shopify/cli-kit/node/base-command'

export default class Init extends AppLinkedCommand {
  public static get requiresSyncAnalytics(): boolean {
    return true
  }

  static summary?: string | undefined = 'Create a new app project'

  static jsonOutputSchema = appInitJsonOutputSchema

  static description = this.descriptionForHelp()

  static examples = [
    '<%= config.bin %> <%= command.id %> --name my-app --organization-id 123 --template reactRouter --flavor typescript',
    '<%= config.bin %> <%= command.id %> --client-id 123 --template none',
  ]

  static flags = {
    ...globalFlags,
    ...jsonFlag,
    name: Flags.string({
      char: 'n',
      env: 'SHOPIFY_FLAG_NAME',
      hidden: false,
      description:
        'The name for the new app. When provided, skips the app selection prompt and creates a new app with this name. Required in non-interactive environments unless --client-id is provided.',
    }),
    path: Flags.string({
      char: 'p',
      env: 'SHOPIFY_FLAG_PATH',
      parse: async (input) => resolvePath(input),
      default: async () => cwd(),
      hidden: false,
    }),
    template: requiredIfNonInteractive(
      Flags.string({
        description: `The app template. Accepts one of the following:
       - <${visibleTemplates.join('|')}>
       - Any GitHub repo with optional branch and subpath, e.g., https://github.com/Shopify/<repository>/[subpath]#[branch]`,
        env: 'SHOPIFY_FLAG_TEMPLATE',
      }),
    ),
    flavor: Flags.string({
      description:
        'Which flavor of the given template to use. Required in non-interactive environments when the selected template offers multiple flavors.',
      env: 'SHOPIFY_FLAG_TEMPLATE_FLAVOR',
    }),
    'package-manager': Flags.string({
      char: 'd',
      env: 'SHOPIFY_FLAG_PACKAGE_MANAGER',
      hidden: false,
      options: ['npm', 'yarn', 'pnpm', 'bun'],
    }),
    local: Flags.boolean({
      char: 'l',
      env: 'SHOPIFY_FLAG_LOCAL',
      default: false,
      hidden: true,
    }),
    'client-id': Flags.string({
      hidden: false,
      description:
        'The Client ID of your app. Use this to automatically link your new project to an existing app. In non-interactive environments, provide this flag or both --name and --organization-id.',
      env: 'SHOPIFY_FLAG_CLIENT_ID',
      exclusive: ['config'],
    }),
    'organization-id': Flags.string({
      hidden: false,
      description:
        'The organization ID. Your organization ID can be found in your Dev Dashboard URL: https://dev.shopify.com/dashboard/<organization-id>. Required in non-interactive environments unless --client-id is provided.',
      env: 'SHOPIFY_FLAG_ORGANIZATION_ID',
      exclusive: ['client-id'],
    }),
  }

  static nonTTYFlagRequirements(): NonTTYFlagRequirement[] {
    return [
      {flags: ['name', 'client-id']},
      {flags: ['organization-id', 'client-id']},
      {
        flags: ['flavor'],
        when: (flags) => templateRequiresFlavor(flags.template as string | undefined),
      },
    ]
  }

  async run(): Promise<AppLinkedCommandOutput> {
    const {flags} = await this.parse(Init)

    validateTemplateValue(flags.template)
    validateFlavorValue(flags.template, flags.flavor)

    // Validate that --name is not empty/whitespace if provided
    if (flags.name !== undefined && flags.name.trim() === '') {
      throw new AbortError("The --name flag can't be empty", 'Provide a valid app name, for example: --name my-app')
    }

    if (flags.template && isPredefinedTemplate(flags.template)) {
      const deprecation = templates[flags.template].deprecated
      if (deprecation) {
        renderWarning({
          headline: ['The', {userInput: flags.template}, 'app template is deprecated.'],
          body: 'It will be removed in a future major release.',
          nextSteps: [['Use', {command: `--template ${deprecation.replacement}`}, 'or a GitHub template URL instead.']],
        })
      }
    }

    const inferredPackageManager = inferPackageManager(flags['package-manager'])
    const name = flags.name ?? (await getAppName(flags.path))

    // Force user authentication before prompting.
    const developerPlatformClient = defaultDeveloperPlatformClient()
    await developerPlatformClient.session()

    const promptAnswers = await initPrompt({
      template: flags.template,
      flavor: flags.flavor,
    })

    let selectAppResult: SelectAppOrNewAppNameResult
    let appName: string
    if (flags['client-id']) {
      // If a client-id is provided we don't need to prompt the user and can link directly to that app.
      const selectedApp = await appFromIdentifiers({apiKey: flags['client-id']})
      appName = selectedApp.title
      selectAppResult = {result: 'existing', app: selectedApp}
    } else {
      let org: Organization
      if (flags['organization-id']) {
        // If an organization-id is provided, fetch the organization directly
        org = await fetchOrgFromId(flags['organization-id'], developerPlatformClient)
      } else {
        org = await selectOrg()
      }
      const {organization, apps, hasMorePages} = await developerPlatformClient.orgAndApps(org.id)
      selectAppResult = await selectAppOrNewAppName(
        flags.name !== undefined,
        name,
        apps,
        hasMorePages,
        organization,
        developerPlatformClient,
      )
      appName = selectAppResult.result === 'new' ? selectAppResult.name : selectAppResult.app.title
    }

    if (promptAnswers.globalCLIResult.install) {
      await installGlobalShopifyCLI(inferredPackageManager)
    }

    await addPublicMetadata(() => ({
      cmd_create_app_template: promptAnswers.templateType,
      cmd_create_app_template_url: promptAnswers.template,
    }))

    const result = await initService({
      name: appName,
      selectedAppOrNameResult: selectAppResult,
      packageManager: inferredPackageManager,
      template: promptAnswers.template,
      local: flags.local,
      directory: flags.path,
      useGlobalCLI: promptAnswers.globalCLIResult.alreadyInstalled || promptAnswers.globalCLIResult.install,
      developerPlatformClient,
      postCloneActions: {
        removeLockfilesFromGitignore: promptAnswers.templateType !== 'custom',
      },
    })

    renderInitResult(result, flags.json)
    return {app: result.app}
  }
}

async function getAppName(directory: string): Promise<string> {
  for (let i = 0; i < 3; i++) {
    // eslint-disable-next-line no-await-in-loop
    const name = await generateRandomNameForSubdirectory({suffix: 'app', directory})
    if (isValidName(name)) return name
  }
  return ''
}

export type SelectAppOrNewAppNameResult =
  | {
      result: 'new'
      name: string
      org: Organization
    }
  | {
      result: 'existing'
      app: OrganizationApp
    }

/**
 * This method returns either an existing app or a new app name and the data necessary to create it.
 * But doesn't create the app yet, the app creation is deferred and is responsibility of the caller.
 */
async function selectAppOrNewAppName(
  nameProvidedAsFlag: boolean,
  localAppName: string,
  apps: MinimalOrganizationApp[],
  hasMorePages: boolean,
  org: Organization,
  developerPlatformClient: DeveloperPlatformClient,
): Promise<SelectAppOrNewAppNameResult> {
  let createNewApp = apps.length === 0 || nameProvidedAsFlag
  if (!createNewApp) {
    createNewApp = await createAsNewAppPrompt()
  }
  if (createNewApp) {
    const name = nameProvidedAsFlag ? localAppName : await appNamePrompt(localAppName)
    return {result: 'new', name, org}
  } else {
    const app = await selectAppPrompt(searchForAppsByNameFactory(developerPlatformClient, org.id), apps, hasMorePages)
    if (!app) throw new AbortError('Unable to select an app: the selection prompt was interrupted.')

    const fullSelectedApp = await developerPlatformClient.appFromIdentifiers(app.apiKey)
    if (!fullSelectedApp) throw new AbortError(`App with id ${app.id} not found`)
    return {result: 'existing', app: fullSelectedApp}
  }
}
