import SecurityRecord from './record.js'
import SecurityCheck from './check.js'
import {appFlags} from '../../../flags.js'
import {appSecurityArtifactPaths} from '../../../services/app-security-artifacts.js'
import {resolveAppSecuritySelection} from '../../../services/app-security-selection.js'
import {validAppConfiguration} from '../../../services/app-security-selection.test-data.js'
import securityRecord from '../../../services/security-record.js'
import {renderSecurityRecordResult} from '../../../services/security-record/result.js'
import {appSecurityRecordJsonOutputSchema} from '../../../services/security-record/types.js'
import AppLinkedCommand from '../../../utilities/app-linked-command.js'
import BaseCommand from '@shopify/cli-kit/node/base-command'
import {jsonFlag} from '@shopify/cli-kit/node/cli'
import {AbortError} from '@shopify/cli-kit/node/error'
import {fileExists, fileRealPath, inTemporaryDirectory, mkdir, writeFile} from '@shopify/cli-kit/node/fs'
import {cwd, joinPath} from '@shopify/cli-kit/node/path'
import {mockAndCaptureOutput} from '@shopify/cli-kit/node/testing/output'
import {describe, expect, test, vi} from 'vitest'

vi.mock('../../../services/security-record.js')
vi.mock('../../../services/security-record/result.js')
vi.mock('../../../services/app-security-selection.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../services/app-security-selection.js')>()),
  resolveAppSecuritySelection: vi.fn(),
}))

/**
 * Creates an app directory and makes the selection resolver find it, as the real resolver would. The results
 * directory of its `shopify.app` results key exists only when `withResults` is set.
 */
async function createApp(directory: string, {withResults = true} = {}): Promise<string> {
  await writeFile(joinPath(directory, 'shopify.app.toml'), 'client_id = "test"\n')
  const appDirectory = await fileRealPath(directory)
  if (withResults) await mkdir(appSecurityArtifactPaths(appDirectory, 'shopify.app').resultsDirectory)
  vi.mocked(resolveAppSecuritySelection).mockResolvedValue({
    kind: 'config',
    appDirectory,
    appConfigFilePath: joinPath(appDirectory, 'shopify.app.toml'),
  })
  return appDirectory
}

/**
 * Creates an app that the real resolver loads, with a results directory for `resultsKey`, and makes the mocked
 * resolver run the real one with the client ID lookup replaced.
 */
async function createLinkedApp(
  directory: string,
  resultsKey: string,
  lookUpApp: (clientId: string) => Promise<void>,
): Promise<string> {
  const appDirectory = await fileRealPath(directory)
  await writeFile(joinPath(appDirectory, 'shopify.app.toml'), validAppConfiguration('toml-client-id'))
  await mkdir(appSecurityArtifactPaths(appDirectory, resultsKey).resultsDirectory)
  const actual = await vi.importActual<typeof import('../../../services/app-security-selection.js')>(
    '../../../services/app-security-selection.js',
  )
  vi.mocked(resolveAppSecuritySelection).mockImplementation((options) =>
    actual.resolveAppSecuritySelection(options, {
      confirmScanWithoutAppConfig: async () => true,
      pickClientId: async () => 'picked-client-id',
      pickConfigFile: async () => 'shopify.app.toml',
      lookUpApp,
    }),
  )
  return appDirectory
}

function recordedResult(appRoot: string) {
  return {path: appSecurityArtifactPaths(appRoot, 'shopify.app').agentFindingsPath, checks: 2, findings: 3}
}

describe('app security record command', () => {
  test('documents command-specific telemetry and links to usage reporting', () => {
    expect(SecurityRecord.descriptionWithMarkdown).toContain(
      'Reports the number of findings to Shopify as usage telemetry, but not finding details.',
    )
    expect(SecurityRecord.descriptionWithMarkdown).toContain(
      '[usage reporting](https://shopify.dev/docs/api/shopify-cli#usage-reporting)',
    )
    expect(SecurityRecord.descriptionWithMarkdown).not.toContain('SHOPIFY_CLI_NO_ANALYTICS=1')
    expect(SecurityRecord.description).toContain('https://shopify.dev/docs/api/shopify-cli#usage-reporting')
  })

  test('does not require linked app context', () => {
    expect(SecurityRecord.prototype).toBeInstanceOf(BaseCommand)
    expect(SecurityRecord.prototype).not.toBeInstanceOf(AppLinkedCommand)
  })

  test('defines --json and exposes the result schema', () => {
    expect(SecurityRecord.flags.json).toBe(jsonFlag.json)
    expect(SecurityRecord.jsonOutputSchema).toBe(appSecurityRecordJsonOutputSchema)
  })

  test('defines the selection flags as check does', () => {
    expect(SecurityRecord.flags.path).toBe(appFlags.path)
    expect(SecurityRecord.flags.config).toBe(appFlags.config)
    expect(SecurityRecord.flags['client-id']).toBe(appFlags['client-id'])
    expect(SecurityRecord.flags['without-app-config']).toBe(SecurityCheck.flags['without-app-config'])
  })

  test('records for the app in the current directory by default and presents the result', async () => {
    await inTemporaryDirectory(async (directory) => {
      const appRoot = await createApp(directory)
      const result = recordedResult(appRoot)
      vi.mocked(securityRecord).mockResolvedValue(result)
      vi.stubEnv('INIT_CWD', directory)
      const output = mockAndCaptureOutput()
      output.clear()

      try {
        await SecurityRecord.run([], import.meta.url)

        expect(resolveAppSecuritySelection).toHaveBeenCalledWith({
          path: cwd(),
          config: undefined,
          clientId: undefined,
          withoutAppConfig: undefined,
          allowPrompts: false,
          validateClientIdFlag: true,
        })
        const options = {selection: await vi.mocked(resolveAppSecuritySelection).mock.results[0]!.value, path: cwd()}
        expect(securityRecord).toHaveBeenCalledWith(options)
        expect(renderSecurityRecordResult).toHaveBeenCalledWith(result, options, 'text')
        expect(output.info()).toBe('')
      } finally {
        vi.unstubAllEnvs()
        output.clear()
      }
    })
  })

  test.each([['--json'], ['-j']])('presents the result as JSON with %s', async (flag) => {
    await inTemporaryDirectory(async (directory) => {
      const appRoot = await createApp(directory)
      const result = recordedResult(appRoot)
      vi.mocked(securityRecord).mockResolvedValue(result)

      await SecurityRecord.run(['--path', directory, flag], import.meta.url)

      expect(renderSecurityRecordResult).toHaveBeenCalledWith(
        result,
        {selection: expect.objectContaining({appDirectory: appRoot}), path: directory},
        'json',
      )
    })
  })

  test('forwards --config, --client-id and --without-app-config to the resolver without prompting', async () => {
    await inTemporaryDirectory(async (directory) => {
      const appRoot = await createApp(directory)
      await mkdir(appSecurityArtifactPaths(appRoot, 'abc123').resultsDirectory)
      vi.mocked(securityRecord).mockResolvedValue(recordedResult(appRoot))
      const output = mockAndCaptureOutput()
      output.clear()

      try {
        await SecurityRecord.run(
          ['--path', directory, '--without-app-config', '--client-id', 'abc123'],
          import.meta.url,
        )

        expect(resolveAppSecuritySelection).toHaveBeenCalledWith({
          path: directory,
          config: undefined,
          clientId: 'abc123',
          withoutAppConfig: true,
          allowPrompts: false,
          validateClientIdFlag: true,
        })
      } finally {
        output.clear()
      }
    })
  })

  test('aborts with "No results found" before reading stdin when the results directory does not exist', async () => {
    await inTemporaryDirectory(async (directory) => {
      await createApp(directory, {withResults: false})
      const output = mockAndCaptureOutput()
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

      try {
        await expect(SecurityRecord.run(['--path', directory], import.meta.url)).rejects.toThrow(
          'process.exit unexpectedly called with "1"',
        )

        expect(output.error()).toContain('No app security check results for shopify.app in')
        expect(output.error()).toContain('shopify app security check')
        expect(securityRecord).not.toHaveBeenCalled()
      } finally {
        consoleErrorSpy.mockRestore()
        output.clear()
      }
    })
  })

  test('looks up --client-id and records when it is found', async () => {
    await inTemporaryDirectory(async (directory) => {
      const lookUpApp = vi.fn(async (_clientId: string) => {})
      const appRoot = await createLinkedApp(directory, 'flag-client-id', lookUpApp)
      vi.mocked(securityRecord).mockResolvedValue(recordedResult(appRoot))
      const output = mockAndCaptureOutput()

      try {
        await SecurityRecord.run(['--path', directory, '--client-id', 'flag-client-id'], import.meta.url)

        expect(lookUpApp).toHaveBeenCalledWith('flag-client-id')
        expect(securityRecord).toHaveBeenCalledWith({
          selection: expect.objectContaining({clientIdOverride: 'flag-client-id'}),
          path: directory,
        })
      } finally {
        output.clear()
      }
    })
  })

  test('aborts on an unknown --client-id before reading stdin or writing anything', async () => {
    await inTemporaryDirectory(async (directory) => {
      const appRoot = await createLinkedApp(directory, 'unknown-client-id', async () => {
        throw new AbortError('No app with client ID unknown-client-id found')
      })
      const output = mockAndCaptureOutput()
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

      try {
        await expect(
          SecurityRecord.run(['--path', directory, '--client-id', 'unknown-client-id'], import.meta.url),
        ).rejects.toThrow('process.exit unexpectedly called with "1"')

        expect(output.error()).toContain('No app with client ID unknown-client-id found')
        expect(securityRecord).not.toHaveBeenCalled()
        await expect(
          fileExists(appSecurityArtifactPaths(appRoot, 'unknown-client-id').agentFindingsPath),
        ).resolves.toBe(false)
      } finally {
        consoleErrorSpy.mockRestore()
        output.clear()
      }
    })
  })

  test('does not look up the TOML client ID', async () => {
    await inTemporaryDirectory(async (directory) => {
      const lookUpApp = vi.fn(async (_clientId: string) => {})
      const appRoot = await createLinkedApp(directory, 'shopify.app', lookUpApp)
      vi.mocked(securityRecord).mockResolvedValue(recordedResult(appRoot))
      const output = mockAndCaptureOutput()

      try {
        await SecurityRecord.run(['--path', directory], import.meta.url)

        expect(lookUpApp).not.toHaveBeenCalled()
        expect(securityRecord).toHaveBeenCalled()
      } finally {
        output.clear()
      }
    })
  })
})
