import {chooseFunction, functionFlags, getOrGenerateSchemaPath} from '../../../services/function/common.js'
import {captureFunctionRun} from '../../../services/function/runner.js'
import {functionRunJsonOutputSchema} from '../../../services/function/runner/types.js'
import {presentFunctionExecution} from '../../../services/function/runner/result.js'
import {appFlags} from '../../../flags.js'
import AppUnlinkedCommand, {AppUnlinkedCommandOutput} from '../../../utilities/app-unlinked-command.js'
import {localAppContext} from '../../../services/app-context.js'
import {globalFlags, jsonFlag} from '@shopify/cli-kit/node/cli'
import {Flags} from '@oclif/core'
import {renderAutocompletePrompt} from '@shopify/cli-kit/node/ui'
import {terminalSupportsPrompting} from '@shopify/cli-kit/node/system'
import {outputDebug} from '@shopify/cli-kit/node/output'

const DEFAULT_FUNCTION_EXPORT = '_start'

export default class FunctionRun extends AppUnlinkedCommand {
  static jsonOutputSchema = functionRunJsonOutputSchema

  static summary = 'Run a function locally for testing.'

  static descriptionWithMarkdown = `Runs the function from your current directory for [testing purposes](https://shopify.dev/docs/apps/functions/testing-and-debugging). To learn how you can monitor and debug functions when errors occur, refer to [Shopify Functions error handling](https://shopify.dev/docs/api/functions/errors).`

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...appFlags,
    ...functionFlags,
    ...jsonFlag,
    input: Flags.string({
      char: 'i',
      description: 'The input JSON to pass to the function. If omitted, standard input is used.',
      env: 'SHOPIFY_FLAG_INPUT',
    }),
    export: Flags.string({
      char: 'e',
      hidden: false,
      description: 'Name of the WebAssembly export to invoke.',
      env: 'SHOPIFY_FLAG_EXPORT',
    }),
    profile: Flags.boolean({
      description:
        'Generate a WebAssembly performance profile for the function run. The profile can be viewed in Speedscope.',
      env: 'SHOPIFY_FLAG_PROFILE',
    }),
  }

  public async run(): Promise<AppUnlinkedCommandOutput> {
    const {flags} = await this.parse(FunctionRun)

    let functionExport = DEFAULT_FUNCTION_EXPORT

    const {app} = await localAppContext({
      directory: flags.path,
      userProvidedConfigName: flags.config,
    })

    const ourFunction = await chooseFunction(app, flags.path)

    if (flags.export !== undefined) {
      outputDebug(`Using export ${flags.export} from the --export flag.`)
      functionExport = flags.export
    } else if (ourFunction.configuration.targeting !== undefined && ourFunction.configuration.targeting.length > 0) {
      const targeting = ourFunction.configuration.targeting

      if (targeting.length > 1 && !flags['no-input'] && terminalSupportsPrompting()) {
        const targets = targeting.map((target) => ({
          label: target.target,
          value: target.export || DEFAULT_FUNCTION_EXPORT, // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing -- empty export should use default
        }))

        functionExport = await renderAutocompletePrompt({
          message: `Which target would you like to execute?`,
          choices: targets,
        })
      } else {
        functionExport = targeting?.[0]?.export || DEFAULT_FUNCTION_EXPORT // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing -- empty export should use default
        outputDebug(
          `Using export '${functionExport}'. Use the --export flag or an interactive terminal to select a different export.`,
        )
      }
    } else {
      outputDebug(
        `No targeting information found. Using the default export '${functionExport}'. Use the --export flag or an interactive terminal to select a different export.`,
      )
    }

    const inputQueryPath = ourFunction?.configuration.targeting?.[0]?.input_query
    const queryPath = inputQueryPath && `${ourFunction?.directory}/${inputQueryPath}`
    const schemaPath = await getOrGenerateSchemaPath(
      ourFunction,
      flags.path,
      flags['client-id'],
      flags.reset,
      flags.config,
    )

    const options = {
      functionExtension: ourFunction,
      inputPath: flags.input,
      export: functionExport,
      stdin: 'inherit' as const,
      schemaPath,
      queryPath,
      profile: flags.profile,
      json: flags.json,
    }
    const execution = await captureFunctionRun(options)
    presentFunctionExecution(execution)

    return {app}
  }
}
