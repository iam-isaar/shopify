import {appFlags} from '../../flags.js'
import {deploy} from '../../services/deploy.js'
import {appDeployJsonOutputSchema} from '../../services/deploy/types.js'
import {renderAppDeployResult} from '../../services/deploy/result.js'
import {validateVersion} from '../../validations/version-name.js'
import {validateMessage} from '../../validations/message.js'
import metadata from '../../metadata.js'
import AppLinkedCommand, {AppLinkedCommandOutput} from '../../utilities/app-linked-command.js'
import {linkedAppContext} from '../../services/app-context.js'
import {Flags} from '@oclif/core'
import {globalFlags, jsonFlag} from '@shopify/cli-kit/node/cli'
import {addPublicMetadata} from '@shopify/cli-kit/node/metadata'
import type {NonTTYFlagRequirement} from '@shopify/cli-kit/node/base-command'

export default class Deploy extends AppLinkedCommand {
  static summary = 'Deploy your Shopify app.'

  static descriptionWithMarkdown = `[Builds the app](https://shopify.dev/docs/api/shopify-cli/app/app-build), then deploys your app configuration and extensions.

  This command creates an app version, which is a snapshot of your app configuration and all extensions. This version is then released to users.

  This command doesn't deploy your [web app](https://shopify.dev/docs/apps/tools/cli/structure#web-components). You need to [deploy your web app](https://shopify.dev/docs/apps/deployment/web) to your own hosting solution.
  `

  static jsonOutputSchema = appDeployJsonOutputSchema

  static description = this.descriptionForHelp()

  static flags = {
    ...globalFlags,
    ...appFlags,
    ...jsonFlag,
    // Unlike the shared app flag, deploy accepts --client-id together with --config:
    // the configuration selected by --config is deployed to the app identified by --client-id.
    'client-id': Flags.string({
      hidden: false,
      description:
        'The Client ID of your app. Use with --config to deploy that configuration to a different app than the one it is linked to.',
      env: 'SHOPIFY_FLAG_CLIENT_ID',
    }),
    'allow-updates': Flags.boolean({
      hidden: false,
      description:
        'Allows adding and updating extensions and configuration without requiring user confirmation. Recommended option for CI/CD environments. In non-interactive environments, provide this flag, --allow-deletes, or --no-release.',
      env: 'SHOPIFY_FLAG_ALLOW_UPDATES',
    }),
    'allow-deletes': Flags.boolean({
      hidden: false,
      description:
        'Allows removing extensions and configuration without requiring user confirmation. For CI/CD environments, the recommended flag is --allow-updates. In non-interactive environments, provide this flag, --allow-updates, or --no-release.',
      env: 'SHOPIFY_FLAG_ALLOW_DELETES',
    }),
    'no-release': Flags.boolean({
      hidden: false,
      description:
        "Creates a version but doesn't release it - it's not made available to merchants. With this flag, a user confirmation is not required. In non-interactive environments, provide this flag, --allow-updates, or --allow-deletes.",
      env: 'SHOPIFY_FLAG_NO_RELEASE',
      default: false,
      exclusive: ['allow-updates', 'allow-deletes'],
    }),
    'no-build': Flags.boolean({
      description:
        'Use with caution: Skips building any elements of the app that require building. You should ensure your app has been prepared in advance, such as by running `shopify app build` or by caching build artifacts.',
      env: 'SHOPIFY_FLAG_NO_BUILD',
      default: false,
    }),
    message: Flags.string({
      hidden: false,
      description:
        "Optional message that will be associated with this version. This is for internal use only and won't be available externally.",
      env: 'SHOPIFY_FLAG_MESSAGE',
    }),
    version: Flags.string({
      hidden: false,
      description:
        'Optional version tag that will be associated with this app version. If not provided, an auto-generated identifier will be generated for this app version.',
      env: 'SHOPIFY_FLAG_VERSION',
    }),
    'source-control-url': Flags.string({
      hidden: false,
      description: 'URL associated with the new app version.',
      env: 'SHOPIFY_FLAG_SOURCE_CONTROL_URL',
    }),
  }

  static nonTTYFlagRequirements(): NonTTYFlagRequirement[] {
    return [{flags: ['allow-updates', 'allow-deletes', 'no-release']}]
  }

  async run(): Promise<AppLinkedCommandOutput> {
    const {flags} = await this.parse(Deploy)

    await metadata.addPublicMetadata(() => ({
      cmd_deploy_flag_message_used: Boolean(flags.message),
      cmd_deploy_flag_version_used: Boolean(flags.version),
      cmd_deploy_flag_source_url_used: Boolean(flags['source-control-url']),
    }))

    validateVersion(flags.version)
    validateMessage(flags.message)

    const clientId = flags['client-id']

    await addPublicMetadata(() => ({
      cmd_app_reset_used: flags.reset,
    }))

    const {app, project, remoteApp, developerPlatformClient, organization} = await linkedAppContext({
      directory: flags.path,
      clientId,
      forceRelink: flags.reset,
      userProvidedConfigName: flags.config,
    })

    const allowUpdates = flags['no-release'] || flags['allow-updates']
    const allowDeletes = flags['no-release'] || flags['allow-deletes']

    const result = await deploy({
      app,
      project,
      remoteApp,
      organization,
      developerPlatformClient,
      reset: flags.reset,
      allowUpdates,
      allowDeletes,
      noRelease: flags['no-release'],
      message: flags.message,
      version: flags.version,
      commitReference: flags['source-control-url'],
      skipBuild: flags['no-build'],
    })
    await renderAppDeployResult(result, remoteApp, project, flags.json ? 'json' : 'text')
    return {app: result.app}
  }
}
