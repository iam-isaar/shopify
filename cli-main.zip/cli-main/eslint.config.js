import nxPlugin from '@nx/eslint-plugin'
import cliPlugin from '@shopify/eslint-plugin-cli'
import jsdocPlugin from 'eslint-plugin-jsdoc'

// Spread the CLI plugin's base config which includes all necessary plugins
const config = [
  // Base config from @shopify/eslint-plugin-cli (includes shopify, typescript, prettier, etc.)
  ...cliPlugin.configs.config,

  // Global ignores
  {
    ignores: ['**/dist/**', '**/node_modules/**', '**/coverage/**', '**/*.d.ts', '**/*.cjs'],
  },

  // The local ESLint plugin uses CommonJS so its rules can load themselves.
  {
    files: ['packages/eslint-plugin-cli/**/*.js'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'commonjs',
    },
  },

  {
    files: ['packages/eslint-plugin-cli/**/*.test.js'],
    languageOptions: {
      globals: {
        describe: 'readonly',
        expect: 'readonly',
        test: 'readonly',
      },
    },
  },

  // NX module boundaries
  {
    files: ['**/*.ts', '**/*.tsx'],
    plugins: {
      '@nx': nxPlugin,
    },
    rules: {
      '@nx/enforce-module-boundaries': 'error',
    },
  },

  // The theme package has tests that partially mock cli-kit with dynamic imports.
  // Those mocks should not make every static cli-kit import in the package fail.
  {
    files: ['packages/theme/src/**/*.ts'],
    rules: {
      '@nx/enforce-module-boundaries': [
        'error',
        {
          checkDynamicDependenciesExceptions: ['@shopify/cli-kit/**'],
        },
      ],
    },
  },

  // JSDoc rules for public API files
  {
    files: ['**/public/**/*.ts'],
    ignores: [
      '**/*.test.ts',
      '**/public/node/abort.ts',
      '**/public/node/analytics.ts',
      '**/public/node/base-command.ts',
      '**/public/node/cli.ts',
      '**/public/node/dot-env.ts',
      '**/public/node/error-handler.ts',
      '**/public/node/framework.ts',
      '**/public/node/fs.ts',
      '**/public/node/github.ts',
      '**/public/node/hooks/prerun.ts',
      '**/public/node/os.ts',
      '**/public/node/node-package-manager.ts',
      '**/public/node/plugins/tunnel.ts',
      '**/public/node/environments.ts',
      '**/public/node/result.ts',
      '**/public/node/themes/**/*',
    ],
    plugins: {
      jsdoc: jsdocPlugin,
    },
    settings: {
      jsdoc: {
        publicFunctionsOnly: true,
        mode: 'typescript',
      },
    },
    rules: {
      'jsdoc/check-access': 'error',
      'jsdoc/check-alignment': 'error',
      'jsdoc/check-indentation': 'error',
      'jsdoc/check-line-alignment': 'error',
      'jsdoc/check-param-names': 'error',
      'jsdoc/check-property-names': 'error',
      'jsdoc/check-syntax': 'error',
      'jsdoc/check-tag-names': 'error',
      'jsdoc/check-types': 'error',
      'jsdoc/check-values': 'error',
      'jsdoc/empty-tags': 'error',
      'jsdoc/implements-on-classes': 'error',
      'jsdoc/match-description': 'error',
      'jsdoc/multiline-blocks': 'error',
      'jsdoc/no-bad-blocks': 'error',
      'jsdoc/no-defaults': 'error',
      'jsdoc/no-multi-asterisks': 'error',
      'jsdoc/no-types': 'error',
      'jsdoc/no-undefined-types': 'error',
      'jsdoc/require-asterisk-prefix': 'error',
      'jsdoc/require-description': 'error',
      'jsdoc/require-description-complete-sentence': 'error',
      'jsdoc/require-hyphen-before-param-description': 'error',
      'jsdoc/require-jsdoc': ['error', {publicOnly: true}],
      'jsdoc/require-param': 'error',
      'jsdoc/require-param-description': 'error',
      'jsdoc/require-param-name': 'error',
      'jsdoc/require-property': 'error',
      'jsdoc/require-property-description': 'error',
      'jsdoc/require-property-name': 'error',
      'jsdoc/require-property-type': 'error',
      'jsdoc/require-returns': ['error', {publicOnly: true}],
      'jsdoc/require-returns-check': 'error',
      'jsdoc/require-returns-description': 'error',
      'jsdoc/require-throws': 'error',
      'jsdoc/require-yields': 'error',
      'jsdoc/require-yields-check': 'error',
      'jsdoc/tag-lines': ['error', 'any', {startLines: 1}],
      'jsdoc/valid-types': 'error',
    },
  },

  // Test file overrides
  {
    files: ['**/*.test.ts'],
    rules: {
      '@typescript-eslint/no-explicit-any': 'off',
      'no-restricted-syntax': 'off',
    },
  },

  // Public API explicit module boundary types
  {
    files: ['src/public/**/*.ts'],
    ignores: ['**/public/node/themes/**/*'],
    rules: {
      '@typescript-eslint/explicit-module-boundary-types': 'error',
    },
  },

  // React components (rely on plugins already defined in cli config)
  {
    files: ['src/private/node/ui/components/**/*.tsx'],
    settings: {
      react: {
        version: 'detect',
      },
    },
    rules: {
      'react/function-component-definition': [
        'error',
        {
          namedComponents: 'arrow-function',
          unnamedComponents: 'arrow-function',
        },
      ],
      'react/hook-use-state': 2,
      'react/jsx-boolean-value': 2,
      'react/jsx-child-element-spacing': 2,
      'react/jsx-closing-bracket-location': 2,
      'react/jsx-closing-tag-location': 2,
      'react/jsx-curly-brace-presence': 2,
      'react/jsx-curly-spacing': 2,
      'react/jsx-equals-spacing': 2,
      'react/jsx-first-prop-new-line': 2,
      'react/jsx-fragments': 2,
      'react/jsx-handler-names': 2,
      'react/jsx-indent': [2, 2, {checkAttributes: true, indentLogicalExpressions: true}],
      'react/jsx-indent-props': [2, 2],
      'react/jsx-no-leaked-render': 2,
      'react/jsx-no-useless-fragment': 2,
      'react/jsx-pascal-case': 2,
      'react/jsx-props-no-multi-spaces': 2,
      'react/jsx-tag-spacing': 2,
      'react/no-namespace': 2,
      'react/no-object-type-as-default-prop': 2,
      'react/self-closing-comp': 2,
      'react/no-unused-prop-types': 2,
      'import-x/no-default-export': 2,
      'import-x/no-namespace': 2,
      'no-restricted-imports': [
        'error',
        {
          paths: [
            {
              name: 'react',
              importNames: ['FC'],
              message: 'Please use FunctionComponent from react instead.',
            },
          ],
        },
      ],
      '@typescript-eslint/naming-convention': [
        'error',
        {
          selector: 'interface',
          format: ['PascalCase'],
          custom: {
            regex: '^Props',
            match: false,
          },
        },
      ],
    },
  },

  // UI module max params
  {
    files: ['src/public/node/ui.tsx'],
    rules: {
      'max-params': ['error', 1],
    },
  },

  // CLI bin/*.js files - disable rules that don't work for plain JS files
  {
    files: ['packages/cli/bin/*.js'],
    rules: {
      '@shopify/strict-component-boundaries': 'off',
    },
  },

  // The cli package uses a lazy command-loading pattern (command-registry.ts) that
  // dynamically imports libraries at runtime. NX detects these dynamic imports and
  // flags every static import of the same library elsewhere in the package. Since
  // the command files themselves are lazy-loaded, their static imports are fine.
  {
    files: ['packages/cli/src/**/*.ts'],
    rules: {
      '@nx/enforce-module-boundaries': 'off',
    },
  },
]

export default config
