# Agent Instructions

Contribute clear, readable TypeScript that follows repository conventions. Use versions supported by the package engines, lockfile, and workflows, not the latest versions by default.

Match your planning to the complexity of the task. For anything beyond a small or obvious change, outline your intended approach before writing code — which files you'll touch and the shape of the solution — so it can be checked before you commit to an implementation. Keep this to a few sentences or bullets. For trivial changes, skip straight to the implementation.

Give accurate, factual answers. State uncertainty and material trade-offs; do not guess.

Remember the following important mindset when providing code, in the following order:
- Adherence to conventions and patterns in the rest of the codebase
- Simplicity
- Readability
- Testability
- Explicitness
- Beginner-friendly

## Guidelines

Adhere to the following guidelines in your code:
- Follow the user's requirements carefully and to the letter.
- Fully implement all requested functionality
- Leave no TODOs, FIXMEs, placeholders or missing pieces.
- Always consider the experience of a developer who will be reading your code.
- Use comments for durable, non-obvious reasons or invariants, not code narration, old-implementation history, PR explanations, or fragile benchmark figures. Preserve public JSDoc.
- Employ descriptive, human-readable variable and function/const names.
- Prefer writing in a functional style, producing pure functions that do not cause side effects.
- The codebase is strictly linted; follow the existing code style to ensure consistency.
- If the generated code would fail a lint check, refactor the code until it no longer fails the lint check.
- Search hard to find an existing function where possible. These are often in the @shopify/cli-kit library.
- Be sure to reference file names
- Be concise. Minimize any prose other than code.
- If you think there might not be a correct answer, say so. If you do not know the answer, say so instead of guessing.
- In tests, always avoid mocking the filesystem. Use real files and directories, in temporary directories if needed.
- In tests, prefer to have as little shared state between tests as possible. Avoid beforeAll and afterAll.

### PR creation

- This repository is published from Shopify's internal monorepo, and its `main` branch changes only through the mirror's pull requests. Shopify staff make code changes upstream, not in pull requests here. Pull requests into this repository are for the files the mirror doesn't manage (`.github`, `.spin`, `dev.yml`, `TORRENT_WORKFLOW.md`, `AGENTS.md`, `.agents`, `.claude` and `.cursor`) and for `stable/*` patch branches. Outside contributors still open pull requests here.
- Use GitHub stacks for multiple dependant PRs.
- Follow the template from .github/PULL_REQUEST_TEMPLATE.md.
- Write a concise description, explaining the problem and the high-level approach. Include implementation details only when they help reviewers understand a decision or tradeoff. Avoid repeating what is clear from the diff. Example for the WHAT section: "Refresh expired credentials before retrying the requests, so users can continue without signing in again".
- Remove empty sections and hidden comments.
- Do not mark checklist items as completed (except the changelog one if added).
- In "How to manually test your changes?", give useful local reviewer steps or CLI commands, not commands to run tests or other checks. This does not require live-state-changing commands.

## Changesets

Add a changeset only when the change is user-facing and ready to appear in public changelogs and release notes.

Add changesets for visible CLI behavior changes, bug fixes users will notice, public API or schema changes, and new or changed commands, flags, prompts, output, or error behavior.

Keep changeset summaries short: one line maximum.

Do not add changesets for tests, refactors, linting, CI, internal tooling, or generated files with no user-visible impact.

If the change is not ready to be public, do not add a changeset.

## Releases

- Minor and patch releases ship from `stable/X.Y` branches. `main` never publishes a release: its version bump is made upstream, in Shopify's internal monorepo, after npm has the release, and the mirror carries it here. Nightlies still publish from `main`.
- Never merge "Version Packages - main" here. It would put commits on `main` that the mirror didn't make, and the mirror would refuse every later publish.
- Before a minor release, a Dev Experience member creates `stable/X.Y` at a green `main` commit with `git push origin <commit>:refs/heads/stable/X.Y`. Only Dev Experience members can create `stable/*` branches or push to them without a pull request. Force-pushes and deletions stay blocked.
- Every release, minor or patch, is a "Version Packages - stable/X.Y" pull request. `release.yml`'s Version Packages job pushes the version bump to `changeset-release/stable/X.Y`, but GitHub Actions can't open pull requests here, so a Dev Experience member opens it by hand, closes and reopens it so its checks run, and tests its head commit `H` with the Release QA package workflow (`release-qa-package.yml`).
- The release owner merges it once `stable/X.Y`'s head is `H`'s parent, with `gh pr merge <number> -R Shopify/cli --merge --admin --match-head-commit <H>`. Use a merge commit (`--merge`): a squash merge publishes nothing. That merge publishes the versions it changed, and nothing else.
- While a release is open, only its release owner merges into `stable/X.Y`. Anyone else, people and agents alike, asks the release owner first.
- A patch starts with a backport pull request into `stable/X.Y` with the fix and the same changeset file as on `main`. A Dev Experience member merges it with the branch rules' bypass (`gh pr merge <number> -R Shopify/cli --merge --admin`), with no review; then the same Version Packages steps follow.

## Further reading

Read the guides that apply to your task.

### CLI

- [Docs index](docs/README.md): find related guides and the reasons behind past decisions.
- [Architecture](docs/cli/architecture.md): choose the right package for new or moved code.
- [Designing for CLI](docs/cli/designing-for-cli.md): design command outcomes, lifetimes, and long-running workflows.
- [Conventions](docs/cli/conventions.md): follow shared patterns for modules, state, resource cleanup, and file IO.
- [Cross-OS compatibility](docs/cli/cross-os-compatibility.md): avoid OS-specific failures when working with paths, processes, and dependencies.
- [Debugging](docs/cli/debugging.md): investigate failures with the debugger and check diagnostics for credential leaks.
- [ESLint rules](docs/cli/eslint-rules.md): understand local lint rules for command flags and environment variables.
- [FAQ](docs/cli/faq.md): understand the choice of TOML for configuration files.
- [Get started](docs/cli/get-started.md): set up the repository and run the CLI against a local project.
- [Naming conventions](docs/cli/naming-conventions.md): use reserved command names, flags, and short forms consistently.
- [Performance](docs/cli/performance.md): measure performance changes and control startup cost and concurrent work.
- [Testing strategy](docs/cli/testing-strategy.md): write tests that detect regressions and choose the appropriate test suite.
- [Troubleshooting](docs/cli/troubleshooting.md): resolve known Vitest mocking problems.
- [Contributing](CONTRIBUTING.md): check changeset, versioning, and deprecation rules before changing public behavior.
- [JSON output contracts](docs/cli/json-output.md): check result and error contracts before changing `--json` output.
- [CLI pre-submit CI](.agents/skills/cli-pre-submit-ci/SKILL.md): choose local checks and generated-file updates that match your change.

### CLI kit

- [Command guidelines](docs/cli-kit/command-guidelines.md): design commands and flags with consistent structure, defaults, dependencies, accepted values, and help text.
- [Error handling](docs/cli/error_handling.md): choose error types, report failures, and retry only known recoverable conditions.
- [Command reference](packages/cli/README.md): check documented command usage, flags, and examples.

### UI kit

- [Contributing to UI Kit](docs/cli-kit/ui-kit/contributing.md): follow component design and testing patterns when changing UI Kit.
- [Content and UI guidelines](docs/cli-kit/ui-kit/guidelines.md): keep prompts, banners, progress, and logs consistent, and use semantic styling.
- [Using UI Kit](docs/cli-kit/ui-kit/readme.md): use existing prompt and output APIs for consistent terminal UI.
