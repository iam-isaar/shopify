## Debugging

New diagnostics and support artifacts must not expose credentials. Redact before truncation, including parse-failure paths. Inspect relevant stderr, events, files, and artifacts, not only stdout; keep useful nonsecret facts. Existing redaction does not prove that content has no paths or code if that is the disclosure promise. Escalate privacy/compatibility choices instead of silently removing stable legacy fields. See [JSON contracts](json-output.md) and [safe error details](error_handling.md#fatal-errors-in-json-output).

The CLI works well with VS Code's built-in debugger -- feel free to use breakpoints across the constituent packages and Typescript files.

The current recommended practise for testing is to run the "Javascript Debug Terminal" command in VS Code. This launches a terminal where the debugger is automatically attached to any node process. If you there execute `pnpm run shopify` (build and run) or `pnpm run shopify:run` (just run), the CLI will be launched and you can provide any desired arguments for the feature you are testing. As the debugger is automatically attached, any breakpoints you've set will be triggered when they're encountered.
